# Quy tắc R8 cho bản release. Compose và AndroidX đã kèm consumer rules.

# WireGuard: lớp được gọi qua JNI từ thư viện native wireguard-go
-keep class com.wireguard.android.backend.** { *; }
-keep class com.wireguard.crypto.** { *; }
-keep class com.wireguard.config.** { *; }
