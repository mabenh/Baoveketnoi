plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Giai đoạn thử nghiệm: chỉ tiếng Việt. Bật đa ngôn ngữ: đặt pss.multiLanguage=true trong gradle.properties.
val multiLanguage = (project.findProperty("pss.multiLanguage") as String?)?.toBoolean() ?: false

// Ký bản release bằng biến môi trường (GitHub Secrets). Không đặt keystore trong repo.
val signingKeystore: String? = System.getenv("SIGNING_KEYSTORE_PATH")

android {
    namespace = "com.personalsecurity.suite"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.personalsecurity.suite"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0-prototype"

        // Khóa công khai (SPKI, base64) dùng xác minh chữ ký cấu hình từ Provisioning API.
        // Lấy bằng `python -m app.cli show-signing-key`, đặt vào biến môi trường / GitHub Actions.
        val signingKey = System.getenv("CONFIG_SIGNING_PUBLIC_KEY") ?: ""
        buildConfigField("String", "CONFIG_SIGNING_PUBLIC_KEY", "\"$signingKey\"")
        buildConfigField("String", "PROVISIONING_BASE_URL", "\"${System.getenv("PROVISIONING_BASE_URL") ?: ""}\"")

        // Một máy chủ WireGuard duy nhất ở TP.HCM trong giai đoạn thử nghiệm.
        buildConfigField("String", "GATEWAY_ID", "\"VN-HCM-01\"")
        buildConfigField("String", "GATEWAY_REGION", "\"TP. Hồ Chí Minh\"")
        // Host được phép trong Endpoint của cấu hình (để trống = không kiểm tra). Ví dụ: hcm.vpn.example.com
        buildConfigField("String", "GATEWAY_HOST", "\"${System.getenv("GATEWAY_HOST") ?: ""}\"")
        buildConfigField("String", "EXIT_IP_CHECK_URL", "\"${System.getenv("EXIT_IP_CHECK_URL") ?: "https://1.1.1.1/cdn-cgi/trace"}\"")

        buildConfigField("boolean", "MULTI_LANGUAGE", multiLanguage.toString())
        if (!multiLanguage) {
            // Chỉ đóng gói tài nguyên tiếng Việt (mặc định); các bản dịch vẫn giữ trong mã nguồn.
            resourceConfigurations += listOf("vi")
        }
        manifestPlaceholders["localeConfig"] = if (multiLanguage) "@xml/locales_config" else "@xml/locales_config_vi"
    }

    signingConfigs {
        create("release") {
            if (signingKeystore != null) {
                storeFile = file(signingKeystore)
                storePassword = System.getenv("SIGNING_STORE_PASSWORD")
                keyAlias = System.getenv("SIGNING_KEY_ALIAS")
                keyPassword = System.getenv("SIGNING_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (signingKeystore != null) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    compileOptions {
        isCoreLibraryDesugaringEnabled = true
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.navigation:navigation-compose:2.8.5")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    debugImplementation("androidx.compose.ui:ui-tooling")

    // WireGuard userspace tunnel (GoBackend + GoBackend.VpnService, thư viện native wireguard-go)
    implementation("com.wireguard.android:tunnel:1.0.20230706")
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.3")
}
