package com.personalsecurity.suite.ui.screens

import android.view.WindowManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.personalsecurity.suite.BuildConfig
import com.personalsecurity.suite.findActivity
import com.personalsecurity.suite.ui.Body
import com.personalsecurity.suite.ui.Kv
import com.personalsecurity.suite.ui.Note
import com.personalsecurity.suite.ui.Pill
import com.personalsecurity.suite.ui.PrimaryButton
import com.personalsecurity.suite.ui.SCard
import com.personalsecurity.suite.ui.Screen
import com.personalsecurity.suite.ui.SecondaryButton
import com.personalsecurity.suite.ui.SectionLabel
import com.personalsecurity.suite.ui.Tone
import com.personalsecurity.suite.vpn.ConfigStore
import com.personalsecurity.suite.vpn.Provisioning
import kotlinx.coroutines.launch
import com.personalsecurity.suite.vpn.VpnController
import com.personalsecurity.suite.vpn.VpnStatus
import com.personalsecurity.suite.vpn.WireGuardManager
import com.personalsecurity.suite.vpn.summary

private const val MAX_CONFIG_BYTES = 64 * 1024

/** Nhập / xem / xóa cấu hình WireGuard. Không bao giờ hiển thị lại private key sau khi lưu. */
@Composable
fun VpnConfigScreen(back: () -> Unit, go: (String) -> Unit) {
    val ctx = LocalContext.current
    var version by remember { mutableIntStateOf(0) }
    var paste by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<Pair<String, Boolean>?>(null) } // (nội dung, là lỗi?)
    var baseUrl by remember { mutableStateOf(Provisioning.savedBaseUrl(ctx).ifEmpty { BuildConfig.PROVISIONING_BASE_URL }) }
    var token by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    // Màn hình có thể chứa private key: chặn chụp màn hình.
    DisposableEffect(Unit) {
        val w = ctx.findActivity()?.window
        w?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { w?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }

    fun store(text: String) {
        message = try {
            ConfigStore.save(ctx, text)
            paste = ""
            version++
            "Đã lưu cấu hình (mã hóa bằng Android Keystore)." to false
        } catch (e: Exception) {
            "Cấu hình không hợp lệ: ${e.message ?: e.javaClass.simpleName}" to true
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0)
                if (bytes.size > MAX_CONFIG_BYTES) message = "File quá lớn để là cấu hình WireGuard." to true
                else store(String(bytes, Charsets.UTF_8))
            } catch (e: Exception) {
                message = "Không đọc được file." to true
            }
        }
    }

    val cfg = remember(version) { ConfigStore.load(ctx) }
    Screen("Cấu hình WireGuard", onBack = back, demo = false, subtitle = "com.wireguard.android:tunnel · GoBackend") {
        message?.let { (m, isErr) ->
            SCard(bg = if (isErr) Tone.BAD.bg else Tone.OK.bg, border = Color.Transparent) {
                Text(m, color = if (isErr) Tone.BAD.fg else Tone.OK.fg, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        if (cfg == null) {
            SCard {
                Pill("Chưa có cấu hình", Tone.UNKNOWN)
                Body("Nhập file .conf do quản trị VPN gateway cung cấp. Cấu hình được kiểm tra bằng parser của WireGuard rồi mã hóa trước khi lưu.", size = 13)
            }
        } else {
            val sm = cfg.summary()
            SCard(spacing = 2.dp) {
                SectionLabel("Cấu hình hiện tại")
                Kv("Endpoint", sm.endpoint)
                Kv("Khóa công khai peer", sm.peerKey)
                Kv("Địa chỉ tunnel", sm.addresses)
                Kv("DNS", sm.dns)
                Kv("AllowedIPs", sm.allowedIps)
                Kv("Ứng dụng", sm.appsRule)
                Kv("Private key", "Đã mã hóa · không hiển thị")
            }
            SCard(spacing = 2.dp) {
                SectionLabel("Điều kiện để được báo Protected")
                Kv("Toàn bộ IPv4 qua tunnel (0.0.0.0/0)", if (sm.fullIpv4) "✓ Đạt" else "✕ Thiếu", if (sm.fullIpv4) Tone.OK else Tone.BAD)
                Kv("Có DNS trong tunnel", if (sm.dns != "Không có") "✓ Đạt" else "✕ Thiếu", if (sm.dns != "Không có") Tone.OK else Tone.BAD)
                val v6Tone = when {
                    sm.ipv6Routed -> Tone.OK
                    WireGuardManager.underlyingHasIpv6(ctx) -> Tone.BAD
                    else -> Tone.WARN
                }
                Kv(
                    "IPv6",
                    when (v6Tone) { Tone.OK -> "✓ Qua tunnel"; Tone.BAD -> "✕ Mạng có IPv6, cấu hình thiếu ::/0"; else -> "! Không định tuyến (mạng hiện tại không có IPv6)" },
                    v6Tone,
                )
            }
            Row(Modifier.fillMaxWidth()) {
                PrimaryButton("Kết nối bằng cấu hình này", { startVpnFlow(ctx, go) }, Modifier.fillMaxWidth())
            }
            SecondaryButton("Xóa cấu hình", {
                if (VpnController.status.value is VpnStatus.Protected) VpnController.disconnect(ctx)
                ConfigStore.clear(ctx); version++; message = "Đã xóa cấu hình." to false
            }, Modifier.fillMaxWidth())
        }

        SectionLabel("Nhận cấu hình từ máy chủ")
        SCard(spacing = 8.dp) {
            Body("Ứng dụng tự sinh cặp khóa trên máy, chỉ gửi khóa công khai. Cấu hình nhận về phải có chữ ký hợp lệ, đúng nonce và thiết bị này mới được lưu.", size = 13)
            Kv("Khóa xác minh cấu hình", if (Provisioning.hasPinnedKey()) "✓ Đã ghim trong bản build" else "✕ Chưa ghim", if (Provisioning.hasPinnedKey()) Tone.OK else Tone.BAD)
            Kv("Mã thiết bị (ngẫu nhiên)", Provisioning.deviceId(ctx).take(8) + "…")
            OutlinedTextField(
                value = baseUrl, onValueChange = { baseUrl = it },
                label = { Text("Địa chỉ Provisioning API (https://)") },
                singleLine = true, modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = token, onValueChange = { token = it },
                label = { Text("Access token (thử nghiệm)") },
                singleLine = true, visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
            )
            PrimaryButton(
                if (busy) "Đang đăng ký thiết bị…" else "Đăng ký thiết bị và nhận cấu hình",
                {
                    busy = true
                    scope.launch {
                        when (val r = Provisioning.provision(ctx, baseUrl, token)) {
                            is Provisioning.Result.Ok -> {
                                message = "Đã nhận cấu hình ${r.peerId} · ${r.ipv4} · hết hạn ${r.expiresAt}." to false
                                version++
                            }
                            is Provisioning.Result.Error -> message = "${r.message} (${r.code})" to true
                        }
                        token = ""
                        busy = false
                    }
                },
                Modifier.fillMaxWidth(),
                enabled = !busy && baseUrl.isNotBlank() && token.isNotBlank(),
            )
            Note("Bản phát hành sẽ lấy token từ màn đăng nhập (MFA/passkey) thay vì nhập tay. Token không được lưu.")
        }

        SectionLabel(if (cfg == null) "Nhập cấu hình thủ công" else "Thay cấu hình thủ công")
        SecondaryButton("Chọn file .conf", { picker.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth())
        OutlinedTextField(
            value = paste,
            onValueChange = { paste = it },
            label = { Text("Hoặc dán nội dung [Interface] / [Peer]") },
            modifier = Modifier.fillMaxWidth().heightIn(min = 140.dp),
            textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
        )
        PrimaryButton("Kiểm tra và lưu", { store(paste) }, Modifier.fillMaxWidth(), enabled = paste.isNotBlank())
        Note("Cấu hình chứa private key. Chỉ dùng cấu hình từ gateway bạn tin cậy; ứng dụng không gửi cấu hình đi đâu và không ghi log nội dung.")
    }
}
