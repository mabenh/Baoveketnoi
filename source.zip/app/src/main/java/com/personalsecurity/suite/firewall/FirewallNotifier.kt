package com.personalsecurity.suite.firewall

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.personalsecurity.suite.MainActivity
import com.personalsecurity.suite.R

/**
 * Thông báo thường trực của firewall.
 * Android < 14: startForeground() như hướng dẫn VPN chính thức.
 * Android 14+: tài liệu VPN chưa nêu loại foreground service; PoC KHÔNG tự khai báo systemExempted,
 * chỉ đăng thông báo ongoing. Quyết định loại FGS cần chốt cùng Play Console (xem docs/PR-FW01.md).
 */
object FirewallNotifier {
    private const val CH = "firewall_status"
    private const val CH_CRITICAL = "critical_security"
    const val ID = 2001

    private fun channels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Firewall", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_CRITICAL, "Bảo mật khẩn cấp", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun build(ctx: Context, channel: String, title: String, text: String, ongoing: Boolean): Notification {
        channels(ctx)
        val open = PendingIntent.getActivity(
            ctx, 1, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_stat_shield)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(ongoing)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .build()
    }

    private fun canPost(ctx: Context) = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun protected(service: Service) {
        val n = build(service, CH, "Firewall Default-Deny đang bật", "Ứng dụng chưa được cho phép sẽ không có Internet.", true)
        if (Build.VERSION.SDK_INT < 34) {
            runCatching { service.startForeground(ID, n) }
        } else if (canPost(service)) {
            runCatching { NotificationManagerCompat.from(service).notify(ID, n) }
        }
    }

    fun interrupted(ctx: Context) {
        if (!canPost(ctx)) return
        val n = build(ctx, CH_CRITICAL, "Firewall đã ngừng bảo vệ", "Mở ứng dụng để kiểm tra.", false)
        runCatching { NotificationManagerCompat.from(ctx).notify(ID, n) }
    }

    fun clear(service: Service) {
        if (Build.VERSION.SDK_INT >= 24) runCatching { service.stopForeground(Service.STOP_FOREGROUND_REMOVE) }
        NotificationManagerCompat.from(service).cancel(ID)
    }
}
