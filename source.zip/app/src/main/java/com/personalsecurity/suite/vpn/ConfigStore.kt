package com.personalsecurity.suite.vpn

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import com.wireguard.config.Config
import java.io.BufferedReader
import java.io.File
import java.io.StringReader
import java.net.Inet4Address
import java.net.Inet6Address
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Lưu cấu hình WireGuard (có private key) đã mã hóa AES-256-GCM bằng khóa trong Android Keystore.
 * Khóa không rời Keystore; file nằm trong bộ nhớ riêng của app và bị loại khỏi backup.
 * Không bao giờ log nội dung cấu hình.
 */
object ConfigStore {
    private const val ALIAS = "pss_wireguard_config_key"
    private const val FILE = "wg_config.enc"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build(),
        )
        return kg.generateKey()
    }

    /** Kiểm tra cú pháp bằng parser của thư viện WireGuard. Ném lỗi kèm thông điệp nếu không hợp lệ. */
    fun parse(text: String): Config = Config.parse(BufferedReader(StringReader(text)))

    fun save(ctx: Context, text: String) {
        parse(text) // không lưu cấu hình hỏng
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val ct = c.doFinal(text.toByteArray(Charsets.UTF_8))
        val iv = c.iv
        File(ctx.filesDir, FILE).writeBytes(byteArrayOf(iv.size.toByte()) + iv + ct)
    }

    fun loadText(ctx: Context): String? {
        val f = File(ctx.filesDir, FILE)
        if (!f.exists()) return null
        return try {
            val b = f.readBytes()
            val n = b[0].toInt()
            val iv = b.copyOfRange(1, 1 + n)
            val ct = b.copyOfRange(1 + n, b.size)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            String(c.doFinal(ct), Charsets.UTF_8)
        } catch (e: Exception) {
            null // Khóa mất hoặc dữ liệu bị sửa: AEAD thất bại an toàn, coi như chưa có cấu hình.
        }
    }

    fun load(ctx: Context): Config? = loadText(ctx)?.let { runCatching { parse(it) }.getOrNull() }

    fun clear(ctx: Context) {
        File(ctx.filesDir, FILE).delete()
    }

    fun exists(ctx: Context) = File(ctx.filesDir, FILE).exists()
}

/** Giới hạn tunnel cho các package được phép (IncludedApplications). GoBackend áp dụng bằng addAllowedApplication. */
fun restrictToApps(text: String, packages: Set<String>): String {
    val kept = text.lines().filterNot { line ->
        val key = line.substringBefore('=').trim()
        key.equals("IncludedApplications", ignoreCase = true) || key.equals("ExcludedApplications", ignoreCase = true)
    }
    val out = ArrayList<String>(kept.size + 1)
    var inserted = false
    for (line in kept) {
        out += line
        if (!inserted && line.trim().equals("[Interface]", ignoreCase = true)) {
            out += "IncludedApplications = " + packages.sorted().joinToString(", ")
            inserted = true
        }
    }
    return out.joinToString("\n")
}

/** Thông tin hiển thị được — không bao giờ chứa private key. */
data class ConfigSummary(
    val endpoint: String,
    val peerKey: String,
    val addresses: String,
    val dns: String,
    val allowedIps: String,
    val fullIpv4: Boolean,
    val ipv6Routed: Boolean,
    val appsRule: String,
)

fun Config.fullIpv4(): Boolean = peers.any { p -> p.allowedIps.any { it.address is Inet4Address && it.mask == 0 } }

fun Config.ipv6Routed(): Boolean =
    peers.any { p -> p.allowedIps.any { it.address is Inet6Address && it.mask == 0 } } &&
        getInterface().addresses.any { it.address is Inet6Address }

fun Config.endpointText(): String =
    peers.firstOrNull()?.endpoint?.orElse(null)?.let { "${it.host}:${it.port}" } ?: "—"

fun Config.summary(): ConfigSummary {
    val itf = getInterface()
    val peer = peers.firstOrNull()
    val key = peer?.publicKey?.toBase64().orEmpty()
    val apps = when {
        itf.includedApplications.isNotEmpty() -> "Chỉ ${itf.includedApplications.size} app đi qua VPN"
        itf.excludedApplications.isNotEmpty() -> "${itf.excludedApplications.size} app đi ngoài VPN"
        else -> "Mọi ứng dụng"
    }
    return ConfigSummary(
        endpoint = endpointText(),
        peerKey = if (key.length > 12) key.take(6) + "…" + key.takeLast(4) else key,
        addresses = itf.addresses.joinToString { "${it.address.hostAddress}/${it.mask}" },
        dns = itf.dnsServers.joinToString { it.hostAddress ?: "" }.ifEmpty { "Không có" },
        allowedIps = peers.flatMap { it.allowedIps }.joinToString { "${it.address.hostAddress}/${it.mask}" },
        fullIpv4 = fullIpv4(),
        ipv6Routed = ipv6Routed(),
        appsRule = apps,
    )
}
