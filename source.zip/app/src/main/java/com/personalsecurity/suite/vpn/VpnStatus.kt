package com.personalsecurity.suite.vpn

import android.content.Context
import android.net.VpnService
import com.personalsecurity.suite.BuildConfig
import com.personalsecurity.suite.Prefs
import com.personalsecurity.suite.firewall.FirewallController
import com.personalsecurity.suite.firewall.FirewallPolicy
import com.wireguard.android.backend.BackendException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** 8 bước của VPN Connection Lifecycle. Chỉ bước PROTECTED mới được hiển thị là "đang bảo vệ". */
enum class ConnectStep(val title: String, val detail: String) {
    PERMISSION_GRANTED("Permission Granted", "Android cho phép ứng dụng trở thành VPN service hiện hành."),
    START_SERVICE("Load WireGuard Config", "Giải mã cấu hình bằng Android Keystore và kiểm tra DNS, AllowedIPs, IPv6."),
    CONNECT_GATEWAY("Start GoBackend Tunnel", "GoBackend.setState(UP): khởi chạy GoBackend.VpnService."),
    PROTECT_SOCKET("Protect Tunnel Socket", "Đưa socket tới máy chủ ra ngoài tunnel để tránh vòng lặp định tuyến."),
    ESTABLISH_TUN("Establish TUN Interface", "Tạo giao diện mạng ảo, cấu hình IP, DNS và route."),
    PACKET_FORWARDING("Packet Forwarding", "wireguard-go mã hóa / giải mã gói tin giữa TUN và peer."),
    VERIFY("Connection Verification", "Handshake với peer, mạng VPN và DNS trong Android, IP đầu ra, IPv6."),
    PROTECTED("Protected", "Chỉ khi các kiểm tra bắt buộc thành công."),
}

enum class InterruptReason(val label: String) {
    REVOKED("Quyền VPN đã bị thu hồi hoặc một ứng dụng VPN khác vừa được bật."),
    TUNNEL_LOST("Mất kết nối tới VPN gateway."),
    SERVICE_STOPPED("Dịch vụ VPN đã dừng."),
}

sealed class VpnStatus {
    /** Chưa từng xin quyền VPN. */
    data object NotPermitted : VpnStatus()

    /** Người dùng đã từ chối hộp thoại hệ thống. Không tự động hỏi lại. */
    data object PermissionDenied : VpnStatus()

    /** Đã có quyền nhưng chưa kết nối. Không phải trạng thái được bảo vệ. */
    data object Ready : VpnStatus()

    data class Connecting(val step: ConnectStep) : VpnStatus()

    data class Protected(
        val gateway: String,
        val exitIp: String,
        val dns: String,
        val ipv6: String,
        val verifiedAt: Long,
        /** null = mọi ứng dụng đi qua VPN; N = chỉ N ứng dụng được phép (+ chính app) đi qua VPN – danh sách chặn dùng chung. */
        val appFilter: Int? = null,
    ) : VpnStatus()

    data class Failed(val step: ConnectStep, val code: String, val message: String, val at: Long) : VpnStatus()

    data class Interrupted(val reason: InterruptReason, val at: Long) : VpnStatus()
}

class GatewayException(val code: String, override val message: String) : Exception(message)

/**
 * Nguồn trạng thái VPN duy nhất cho UI và thông báo.
 * Quy trình: quyền VpnService → cấu hình → GoBackend.setState(UP) → kiểm tra → Protected.
 */
object VpnController {
    private val _status = MutableStateFlow<VpnStatus>(VpnStatus.NotPermitted)
    val status: StateFlow<VpnStatus> = _status.asStateFlow()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var job: Job? = null

    internal fun update(s: VpnStatus) {
        _status.value = s
    }

    fun hasPermission(ctx: Context): Boolean = VpnService.prepare(ctx) == null

    /** Gọi khi app trở lại foreground: kiểm tra lại quyền và tunnel thay vì tin giá trị cũ. */
    fun refresh(ctx: Context, prefs: Prefs) {
        val granted = hasPermission(ctx)
        when (val cur = _status.value) {
            is VpnStatus.Connecting -> Unit
            is VpnStatus.Protected ->
                if (!granted || !WireGuardManager.isRunning(ctx)) onTunnelDown(ctx)
            is VpnStatus.Failed, is VpnStatus.Interrupted ->
                if (!granted && !(cur is VpnStatus.Interrupted && cur.reason == InterruptReason.REVOKED)) {
                    update(if (prefs.requested("vpn")) VpnStatus.PermissionDenied else VpnStatus.NotPermitted)
                }
            else -> update(
                when {
                    granted -> VpnStatus.Ready
                    prefs.requested("vpn") -> VpnStatus.PermissionDenied
                    else -> VpnStatus.NotPermitted
                },
            )
        }
    }

    fun onPermissionResult(granted: Boolean) {
        if (!granted) update(VpnStatus.PermissionDenied)
    }

    /** Tunnel bị hạ mà người dùng không yêu cầu. */
    internal fun onTunnelDown(ctx: Context) {
        val cur = _status.value
        if (cur !is VpnStatus.Protected && cur !is VpnStatus.Connecting) return
        val reason = if (!hasPermission(ctx)) InterruptReason.REVOKED else InterruptReason.SERVICE_STOPPED
        update(VpnStatus.Interrupted(reason, System.currentTimeMillis()))
        StatusNotifier.interrupted(ctx, reason)
        // VPN khác chiếm quyền (REVOKED) thì không giành lại; còn lại firewall cục bộ tiếp quản danh sách chặn.
        if (reason != InterruptReason.REVOKED) FirewallController.resumeIfEnabled(ctx)
    }

    fun connect(context: Context) {
        val ctx = context.applicationContext
        if (job?.isActive == true) return
        update(VpnStatus.Connecting(ConnectStep.PERMISSION_GRANTED))
        job = scope.launch {
            var step = ConnectStep.PERMISSION_GRANTED
            var tunnelUp = false
            try {
                if (!hasPermission(ctx)) throw GatewayException("VPN_NOT_AUTHORIZED", "Android chưa cấp quyền VPN cho ứng dụng.")
                if (FirewallController.isRunning()) {
                    // Firewall PoC và WireGuard dùng chung một VPN của hệ thống: tắt firewall trước.
                    FirewallController.stop(ctx)
                    delay(800)
                }

                step = ConnectStep.START_SERVICE
                update(VpnStatus.Connecting(step))
                StatusNotifier.connecting(ctx)
                val text = ConfigStore.loadText(ctx)
                    ?: throw GatewayException("GATEWAY_NOT_CONFIGURED", "Chưa có cấu hình WireGuard. Hãy nhập file .conf do quản trị gateway cung cấp.")
                // Danh sách chặn dùng chung: khi đang bật, chỉ app được phép (và chính app này) đi qua tunnel.
                val listOn = FirewallPolicy.enabled(ctx)
                if (listOn) FirewallPolicy.prune(ctx) // package đã gỡ sẽ làm GoBackend báo lỗi
                val allowedApps = FirewallPolicy.allowed(ctx)
                val effective = if (listOn) restrictToApps(text, allowedApps + ctx.packageName) else text
                val cfg = try {
                    ConfigStore.parse(effective)
                } catch (e: Exception) {
                    throw GatewayException("CONFIG_INVALID", "Cấu hình WireGuard không hợp lệ.")
                }
                if (cfg.peers.isEmpty() || cfg.peers.any { !it.endpoint.isPresent }) {
                    throw GatewayException("CONFIG_INVALID", "Cấu hình thiếu [Peer] hoặc Endpoint.")
                }
                val expectedHost = BuildConfig.GATEWAY_HOST
                if (expectedHost.isNotBlank() && cfg.peers.any { !it.endpoint.get().host.equals(expectedHost, ignoreCase = true) }) {
                    throw GatewayException("UNEXPECTED_GATEWAY", "Cấu hình trỏ tới máy chủ khác ${BuildConfig.GATEWAY_ID} ($expectedHost). Đã từ chối.")
                }
                if (!cfg.fullIpv4()) {
                    throw GatewayException("SPLIT_TUNNEL", "AllowedIPs không có 0.0.0.0/0 nên chỉ một phần lưu lượng đi qua VPN; không thể báo Protected.")
                }
                if (cfg.getInterface().dnsServers.isEmpty()) {
                    throw GatewayException("NO_DNS", "Cấu hình không có DNS: truy vấn DNS có thể đi ngoài tunnel.")
                }
                if (!cfg.ipv6Routed() && WireGuardManager.underlyingHasIpv6(ctx)) {
                    throw GatewayException("IPV6_LEAK", "Mạng hiện tại có IPv6 nhưng cấu hình không định tuyến ::/0 qua tunnel.")
                }

                step = ConnectStep.CONNECT_GATEWAY
                update(VpnStatus.Connecting(step))
                try {
                    WireGuardManager.up(ctx, cfg) // GoBackend: protect socket, establish TUN, forwarding
                    tunnelUp = true
                } catch (e: BackendException) {
                    throw GatewayException(e.reason.name, "GoBackend không khởi động được tunnel (${e.reason.name}).")
                }

                step = ConnectStep.VERIFY
                update(VpnStatus.Connecting(step))
                val exitIp = WireGuardManager.fetchExitIp() // tạo lưu lượng để kích hoạt handshake
                var handshake = WireGuardManager.lastHandshakeMillis(ctx, cfg)
                var waited = 0
                while (handshake == 0L && waited < 10_000) {
                    delay(500); waited += 500
                    handshake = WireGuardManager.lastHandshakeMillis(ctx, cfg)
                }
                if (handshake == 0L) throw GatewayException("HANDSHAKE_FAILED", "Không hoàn tất handshake với gateway trong 10 giây (sai khóa, endpoint hoặc bị chặn UDP).")
                val dnsCount = WireGuardManager.vpnNetworkDnsCount(ctx)
                if (dnsCount < 0) throw GatewayException("VPN_NETWORK_MISSING", "Android chưa ghi nhận mạng VPN.")
                if (dnsCount == 0) throw GatewayException("NO_DNS", "Mạng VPN không có DNS.")
                if (exitIp == null) throw GatewayException("EXIT_IP_UNVERIFIED", "Không xác minh được IP đầu ra qua tunnel.")

                update(
                    VpnStatus.Protected(
                        gateway = cfg.endpointText(),
                        exitIp = exitIp,
                        dns = "Qua tunnel ($dnsCount máy chủ)",
                        ipv6 = if (cfg.ipv6Routed()) "Qua tunnel" else "Mạng hiện tại không có IPv6",
                        verifiedAt = System.currentTimeMillis(),
                        appFilter = if (listOn) allowedApps.size else null,
                    ),
                )
                StatusNotifier.protected(ctx)
            } catch (e: CancellationException) {
                throw e // người dùng hủy: disconnect() tự hạ tunnel
            } catch (e: GatewayException) {
                if (tunnelUp) WireGuardManager.down(ctx)
                update(VpnStatus.Failed(step, e.code, e.message, System.currentTimeMillis()))
                StatusNotifier.failed(ctx)
                FirewallController.resumeIfEnabled(ctx) // thay phiên: firewall cục bộ tiếp tục thực thi danh sách
            } catch (e: Exception) {
                if (tunnelUp) WireGuardManager.down(ctx)
                update(VpnStatus.Failed(step, "UNEXPECTED_ERROR", "Lỗi không xác định (${e.javaClass.simpleName}).", System.currentTimeMillis()))
                StatusNotifier.failed(ctx)
                FirewallController.resumeIfEnabled(ctx)
            }
        }
    }

    fun disconnect(context: Context) {
        val ctx = context.applicationContext
        job?.cancel()
        scope.launch {
            WireGuardManager.down(ctx)
            update(if (hasPermission(ctx)) VpnStatus.Ready else VpnStatus.NotPermitted)
            StatusNotifier.clear(ctx)
            FirewallController.resumeIfEnabled(ctx)
        }
    }

    /** Áp lại danh sách chặn cho tunnel đang chạy (hạ rồi dựng lại, không trao lượt cho firewall ở giữa). */
    fun reconnect(context: Context) {
        val ctx = context.applicationContext
        job?.cancel()
        scope.launch {
            WireGuardManager.down(ctx)
            update(VpnStatus.Ready)
            connect(ctx)
        }
    }
}
