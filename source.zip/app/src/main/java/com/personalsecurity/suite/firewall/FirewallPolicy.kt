package com.personalsecurity.suite.firewall

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import androidx.core.graphics.drawable.toBitmap

/**
 * Chính sách Default-Deny, lưu cục bộ (không gửi lên máy chủ).
 * Chỉ lưu danh sách package ĐƯỢC PHÉP; mọi package khác — kể cả app mới cài — mặc định bị chặn.
 */
object FirewallPolicy {
    private const val PREFS = "firewall_policy"
    private const val KEY_ALLOWED = "allowed_packages"

    /** Ngoại lệ hệ thống đã kiểm chứng trong PoC. Danh sách phải có lý do và kết quả kiểm thử (FW-018). */
    val SYSTEM_EXCEPTIONS: Map<String, String> = emptyMap()

    /** Ý định của người dùng: danh sách chặn có đang được bật hay không (độc lập với service nào đang thực thi). */
    fun enabled(ctx: Context): Boolean = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("enabled", false)

    fun setEnabled(ctx: Context, on: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("enabled", on).apply()
    }

    fun allowed(ctx: Context): Set<String> =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getStringSet(KEY_ALLOWED, emptySet())!!.toSet()

    fun setAllowed(ctx: Context, pkg: String, allow: Boolean) {
        val cur = allowed(ctx).toMutableSet()
        if (allow) cur.add(pkg) else cur.remove(pkg)
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putStringSet(KEY_ALLOWED, cur).apply()
    }

    /** Gỡ khỏi allowlist những package đã bị gỡ cài đặt. */
    fun prune(ctx: Context) {
        val pm = ctx.packageManager
        val cur = allowed(ctx)
        val alive = cur.filter { runCatching { pm.getApplicationInfo(it, 0) }.isSuccess }.toSet()
        if (alive.size != cur.size) {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putStringSet(KEY_ALLOWED, alive).apply()
        }
    }
}

data class AppEntry(
    val packageName: String,
    val label: String,
    val uid: Int,
    val isSystem: Boolean,
    val icon: Bitmap?,
    val sharedUidWith: List<String>,
)

/**
 * Danh sách app dùng <queries> (LAUNCHER + vài package hệ thống khai báo trong manifest),
 * không dùng QUERY_ALL_PACKAGES ở giai đoạn PoC.
 */
object AppCatalog {
    fun load(ctx: Context): List<AppEntry> {
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val pkgs = pm.queryIntentActivities(launcher, 0).map { it.activityInfo.packageName }.toMutableSet()
        pkgs += listOf("com.google.android.gms", "com.android.vending")
        pkgs.remove(ctx.packageName) // app của chính firewall luôn được phép (ngoại lệ có lý do: cần mạng để hoạt động)
        val infos = pkgs.mapNotNull { p ->
            runCatching { pm.getApplicationInfo(p, 0) }.getOrNull()
        }
        val byUid = infos.groupBy { it.uid }
        return infos.map { ai ->
            AppEntry(
                packageName = ai.packageName,
                label = pm.getApplicationLabel(ai).toString(),
                uid = ai.uid,
                isSystem = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                icon = runCatching { pm.getApplicationIcon(ai).toBitmap(72, 72) }.getOrNull(),
                sharedUidWith = byUid[ai.uid].orEmpty().map { it.packageName }.filter { it != ai.packageName },
            )
        }.sortedWith(compareBy({ it.isSystem }, { it.label.lowercase() }))
    }

    fun labelForUid(pm: PackageManager, uid: Int): String {
        val pkgs = pm.getPackagesForUid(uid) ?: return "UID $uid"
        val first = pkgs.first()
        val label = runCatching { pm.getApplicationLabel(pm.getApplicationInfo(first, 0)).toString() }.getOrDefault(first)
        return if (pkgs.size > 1) "$label (+${pkgs.size - 1} package cùng UID)" else label
    }
}
