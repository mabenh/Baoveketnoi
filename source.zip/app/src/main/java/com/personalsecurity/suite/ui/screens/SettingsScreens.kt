package com.personalsecurity.suite.ui.screens

import android.Manifest
import android.os.Build
import android.provider.Settings as AndroidSettings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.personalsecurity.suite.BuildConfig
import com.personalsecurity.suite.PState
import com.personalsecurity.suite.Prefs
import com.personalsecurity.suite.R
import com.personalsecurity.suite.bluetoothState
import com.personalsecurity.suite.notificationState
import com.personalsecurity.suite.openAppDetails
import com.personalsecurity.suite.openSettings
import com.personalsecurity.suite.rememberResumeTick
import com.personalsecurity.suite.usageAccessState
import com.personalsecurity.suite.vpnConsentState
import com.personalsecurity.suite.ui.Ink
import com.personalsecurity.suite.ui.ItemRow
import com.personalsecurity.suite.ui.Kv
import com.personalsecurity.suite.ui.Muted
import com.personalsecurity.suite.ui.NavyDeep
import com.personalsecurity.suite.ui.Note
import com.personalsecurity.suite.ui.Pill
import com.personalsecurity.suite.ui.Primary
import com.personalsecurity.suite.ui.RowDivider
import com.personalsecurity.suite.ui.SCard
import com.personalsecurity.suite.ui.Screen
import com.personalsecurity.suite.ui.SecondaryButton
import com.personalsecurity.suite.ui.SectionLabel
import com.personalsecurity.suite.ui.SoftBlue
import com.personalsecurity.suite.ui.ToggleRow
import com.personalsecurity.suite.ui.Tone
import com.personalsecurity.suite.ui.WarnInk

@Composable
fun SettingsScreen(back: () -> Unit, go: (String) -> Unit, demo: Boolean, onDemoChange: (Boolean) -> Unit) {
    val current = currentLangTag()
    val langName = LANGS.firstOrNull { it.tag == current }?.native ?: stringResource(R.string.language_system)
    Screen(stringResource(R.string.settings), onBack = back, demo = false) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(NavyDeep).padding(12.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Image(painterResource(R.drawable.logo), null, Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
            Column {
                Text(stringResource(R.string.app_name), color = Color.White, fontWeight = FontWeight.Bold)
                Text("Phiên bản 0.1.0 · thử nghiệm · máy chủ ${BuildConfig.GATEWAY_REGION}", color = SoftBlue, fontSize = 12.sp)
            }
        }
        SCard(spacing = 0.dp, padding = PaddingValues(16.dp, 2.dp)) {
            if (BuildConfig.MULTI_LANGUAGE) {
                ItemRow(stringResource(R.string.language), langName, onClick = { go("language") })
                RowDivider()
            }
            ItemRow(stringResource(R.string.permissions), "Trạng thái thật của từng quyền", onClick = { go("permissions") })
            RowDivider()
            ItemRow(stringResource(R.string.bg_protection), "Mức A–D, giới hạn pin của hãng", onClick = { go("bg_protection") })
            RowDivider()
            ItemRow(stringResource(R.string.notif_prefs), "Kênh, màn hình khóa, giờ yên lặng", onClick = { go("notif_prefs") })
        }
        SCard(spacing = 0.dp, padding = PaddingValues(16.dp, 2.dp)) {
            ToggleRow(stringResource(R.string.demo_mode), "Bật: hiện dữ liệu minh họa theo thiết kế. Tắt: Tổng quan chỉ hiện trạng thái thật đọc từ Android.", demo, onDemoChange)
        }
        Note("Bản prototype giao diện: chưa có VPN tunnel, tường lửa, engine Wi-Fi/Bluetooth, breach monitor hay kho mật khẩu thật.")
    }
}

@Composable
fun LanguageScreen(back: () -> Unit) {
    Screen(stringResource(R.string.language), onBack = back, demo = false) {
        SCard(spacing = 0.dp, padding = PaddingValues(8.dp, 4.dp)) { LanguageOptions() }
        Note("Từ Android 13 cũng có thể đổi ngôn ngữ riêng cho ứng dụng trong Cài đặt hệ thống. Tiếng Ả Rập hiển thị từ phải sang trái. Hiện mới dịch thanh điều hướng, trạng thái và các màn chung; nội dung chi tiết còn tiếng Việt.")
    }
}

private data class PermRow(val name: String, val purpose: String, val fallback: String, val state: PState, val onClick: () -> Unit)

@Composable
fun PermissionsScreen(back: () -> Unit, go: (String) -> Unit, prefs: Prefs) {
    val ctx = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    val tick = rememberResumeTick()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refresh++ }
    fun request(p: String, state: PState) {
        if (state == PState.NOT_ASKED || state == PState.DENIED) { prefs.markRequested(p); launcher.launch(p) } else openAppDetails(ctx)
    }
    @Suppress("UNUSED_VARIABLE") val key = tick + refresh // đọc lại trạng thái mỗi lần resume / sau khi xin quyền

    val notif = notificationState(ctx, prefs)
    val scan = bluetoothState(ctx, prefs, Manifest.permission.BLUETOOTH_SCAN)
    val connect = bluetoothState(ctx, prefs, Manifest.permission.BLUETOOTH_CONNECT)
    val rows = listOf(
        PermRow("Quyền VPN (VpnService)", "Tạo tunnel, firewall cục bộ, định tuyến", "Từ chối → VPN/firewall hiển thị Unprotected", vpnConsentState(ctx, prefs)) { go("onb_vpn") },
        PermRow("Thông báo", "Cảnh báo và trạng thái bảo vệ", "Từ chối → cảnh báo vẫn lưu trong Security Center", notif) {
            if (Build.VERSION.SDK_INT >= 33) request(Manifest.permission.POST_NOTIFICATIONS, notif) else openAppDetails(ctx)
        },
        PermRow("Quét Bluetooth", "Quét BLE khi bật giám sát thiết bị lân cận", "Từ chối → không quét, hiển thị Limited", scan) {
            if (Build.VERSION.SDK_INT >= 31) request(Manifest.permission.BLUETOOTH_SCAN, scan)
        },
        PermRow("Kết nối Bluetooth", "Đọc thiết bị đã ghép đôi", "Xin khi mở danh sách thiết bị", connect) {
            if (Build.VERSION.SDK_INT >= 31) request(Manifest.permission.BLUETOOTH_CONNECT, connect)
        },
        PermRow("Thiết bị Wi-Fi lân cận", "Một số thao tác Wi-Fi theo API 33+", "Chưa có chức năng cần quyền này", PState.NOT_APPLICABLE) {},
        PermRow("Vị trí chính xác", "Chỉ khi API Wi-Fi bắt buộc", "Chưa xin · sẽ giải thích rõ dữ liệu và phạm vi", PState.NOT_APPLICABLE) {},
        PermRow("Usage Access", "Phân tích mức dùng app (Device Care)", "Chỉ bật được trong Cài đặt Android", usageAccessState(ctx, prefs)) {
            openSettings(ctx, AndroidSettings.ACTION_USAGE_ACCESS_SETTINGS)
        },
        PermRow("Sinh trắc học", "Mở khóa Kho mật khẩu", "Xin khi bạn bật vân tay cho Kho; luôn có mật khẩu chủ", PState.NOT_APPLICABLE) {},
        PermRow("Dịch vụ tự động điền", "Tự điền thông tin đăng nhập", "Bạn tự chọn trong Cài đặt Android · chưa có trong prototype", PState.NOT_APPLICABLE) {},
        PermRow("Trợ năng (Accessibility)", "Không dùng để đọc mật khẩu hay thao tác", "Không yêu cầu trong cấu hình mặc định", PState.NOT_APPLICABLE) {},
    )

    Screen(stringResource(R.string.permissions), onBack = back, demo = false, subtitle = "Kiểm tra lại mỗi khi mở màn hình") {
        Note("Mỗi quyền chỉ được xin ngay trước khi bạn dùng chức năng cần nó. Ứng dụng không tự bật quyền thay bạn.")
        SCard(spacing = 0.dp, padding = PaddingValues(14.dp, 2.dp)) {
            rows.forEachIndexed { i, r ->
                if (i > 0) RowDivider()
                ItemRow(r.name, "${r.purpose}\n${r.fallback}", onClick = r.onClick, trailing = { Pill(r.state.label, r.state.tone) })
            }
        }
        SCard {
            SectionLabel("Trạng thái quyền")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Pill(PState.GRANTED.name, PState.GRANTED.tone); Pill(PState.DENIED.name, PState.DENIED.tone); Pill(PState.REVOKED.name, PState.REVOKED.tone)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Pill(PState.PERMANENTLY_DENIED.name, PState.PERMANENTLY_DENIED.tone); Pill(PState.NOT_APPLICABLE.name, PState.NOT_APPLICABLE.tone)
            }
            Note("Quyền bị thu hồi khi chạy nền → trạng thái “chưa xác minh”, không bao giờ hiển thị Protected.")
        }
    }
}

@Composable
fun BgProtectionScreen(back: () -> Unit) {
    val ctx = LocalContext.current
    var wireless by remember { mutableStateOf(true) }
    Screen(stringResource(R.string.bg_protection), onBack = back) {
        Note("Ứng dụng giám sát theo sự kiện hệ thống và tác vụ nền trong giới hạn Android — không phải giám sát 24/7 tuyệt đối. Doze, tiết kiệm pin, giới hạn của hãng hoặc force-stop có thể làm trễ hay tạm dừng giám sát.")
        SCard(spacing = 0.dp, padding = PaddingValues(16.dp, 2.dp)) {
            ToggleRow("Giám sát Wi-Fi & Bluetooth khi nền", "Theo sự kiện, không quét liên tục", wireless) { wireless = it }
            RowDivider()
            ItemRow("Bảo vệ liên tục", "Chạy cùng VPN · có thông báo thường trực", trailing = { Pill("Đang chạy", Tone.OK) })
        }
        SectionLabel("Trạng thái thực theo từng mức")
        SCard(spacing = 0.dp, padding = PaddingValues(16.dp, 2.dp)) {
            Level("A", "Theo sự kiện hệ thống", "Nhận thay đổi mạng, VPN, quyền khi Android phát sự kiện.",
                if (wireless) "✓ Đang hoạt động" else "Đã tắt", if (wireless) Tone.OK else Tone.NEUTRAL)
            RowDivider()
            Level("B", "Kiểm tra theo lịch", "Đồng bộ breach, IP Trust. Lần cuối 07:12 · lần tới khoảng 13:00 — thời điểm có thể thay đổi.", "✓ Đúng lịch", Tone.OK)
            RowDivider()
            Level("C", "Bảo vệ nền liên tục", "VPN tunnel do bạn bật · thông báo thường trực.", "✓ Đang chạy", Tone.OK)
            RowDivider()
            Level("D", "Đang bị giới hạn", "• Tối ưu pin của hãng đang hạn chế chạy nền\n• Chưa cấp quyền quét Bluetooth", "! Limited · Delayed", Tone.WARN)
        }
        SCard(bg = Color(0xFFFFF8EE), border = Color(0xFFF2C58F)) {
            Text("Khoảng không có giám sát nền", fontWeight = FontWeight.SemiBold, color = WarnInk)
            Text("02:10 – 07:05 hôm nay · ứng dụng đã bị dừng (force-stop). Không có dữ liệu cho khoảng này; trạng thái đã được đồng bộ lại khi bạn mở app.", fontSize = 13.sp, color = Muted)
        }
        SCard {
            Text("Hướng dẫn pin theo hãng máy", fontWeight = FontWeight.SemiBold, color = Ink)
            Note("Nếu muốn giảm trễ, bạn có thể cho phép ứng dụng chạy nền trong cài đặt pin. Ứng dụng không tự thay đổi hay lách các giới hạn này.")
            SecondaryButton("Mở cài đặt tối ưu pin", { openSettings(ctx, AndroidSettings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) }, Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun Level(tag: String, title: String, desc: String, status: String, tone: Tone) {
    Row(Modifier.padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.size(28.dp).clip(RoundedCornerShape(8.dp)).background(if (tone == Tone.WARN) Tone.WARN.fg else NavyDeep), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text(tag, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = Ink)
            Text(desc, fontSize = 12.sp, color = Muted, lineHeight = 17.sp)
            Pill(status, tone)
        }
    }
}

@Composable
fun NotifPrefsScreen(back: () -> Unit, prefs: Prefs) {
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    val notif = remember(tick) { notificationState(ctx, prefs) }
    val channels = remember { mutableStateMapOf("crit" to true, "wl" to true, "st" to true, "id" to true, "mt" to false) }
    var preview by remember { mutableStateOf("hide") }
    var quiet by remember { mutableStateOf(true) }
    var coalesce by remember { mutableStateOf(true) }
    Screen(stringResource(R.string.notif_prefs), onBack = back) {
        SCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Quyền thông báo", fontWeight = FontWeight.SemiBold, color = Ink)
                    Text("Nếu tắt, cảnh báo vẫn được lưu trong Security Center", fontSize = 12.sp, color = Muted)
                }
                Pill(notif.label, notif.tone)
            }
            if (notif != PState.GRANTED) SecondaryButton("Mở cài đặt thông báo", { openAppDetails(ctx) }, Modifier.fillMaxWidth())
        }
        SectionLabel("Kênh thông báo")
        SCard(spacing = 0.dp, padding = PaddingValues(16.dp, 2.dp)) {
            listOf(
                Triple("crit", "Bảo mật khẩn cấp", "Mất VPN ở tuyến tài chính, dấu hiệu nghiêm trọng có bằng chứng"),
                Triple("wl", "Rủi ro không dây", "Wi-Fi đổi bất thường, ghép đôi Bluetooth lạ"),
                Triple("st", "Trạng thái bảo vệ", "VPN hoạt động, bảo vệ bị giới hạn, mất quyền"),
                Triple("id", "Danh tính & tài khoản", "Rò rỉ mới · ẩn chi tiết trên màn hình khóa"),
                Triple("mt", "Bảo trì", "Đồng bộ xong, kiểm tra định kỳ"),
            ).forEachIndexed { i, (k, t, d) ->
                if (i > 0) RowDivider()
                ToggleRow(t, d, channels[k] == true) { channels[k] = it }
            }
        }
        Note("Mỗi kênh cũng quản lý được trong Cài đặt Android. Ứng dụng không tạo kênh mới để vượt qua lựa chọn tắt của bạn.")
        SectionLabel("Nội dung trên màn hình khóa")
        val options = listOf(
            Triple("hide", "Ẩn chi tiết (mặc định)", "Mở ứng dụng để xem chi tiết."),
            Triple("summary", "Tóm tắt", "AP và DNS thay đổi trong phiên hiện tại. Chưa thể xác minh mạng."),
            Triple("full", "Đầy đủ", "Mạng “Cafe_Free”: AP và DNS thay đổi lúc 09:31. Chưa thể xác minh mạng."),
        )
        SCard(spacing = 0.dp, padding = PaddingValues(8.dp, 2.dp)) {
            options.forEach { (k, l, _) ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = preview == k, onClick = { preview = k }, colors = RadioButtonDefaults.colors(selectedColor = Primary))
                    Text(l, fontSize = 14.sp, color = Ink)
                }
            }
        }
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFF1B2333)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Xem trước trên màn hình khóa", color = Color(0xFFAEB8C8), fontSize = 11.sp)
            Text("Wi-Fi có thay đổi bất thường", color = Color.White, fontWeight = FontWeight.Bold)
            Text(options.first { it.first == preview }.third, color = Color(0xFFD5DCE7), fontSize = 13.sp)
        }
        SectionLabel("Giờ yên lặng & gộp cảnh báo")
        SCard(spacing = 0.dp, padding = PaddingValues(16.dp, 2.dp)) {
            ToggleRow("Giờ yên lặng", "22:00 – 07:00 · cảnh báo vào Security Center", quiet) { quiet = it }
            RowDivider()
            ToggleRow("Gộp cảnh báo cùng nguyên nhân", "Một thông báo tóm tắt cho sự kiện lặp trong cùng phiên", coalesce) { coalesce = it }
            RowDivider()
            Kv("Giới hạn tần suất", "3 / 15 phút mỗi kênh")
        }
        SCard(bg = Tone.BAD.bg, border = Color(0xFFF0B7B1)) {
            Text("Chính sách cảnh báo khẩn cấp", fontWeight = FontWeight.SemiBold, color = Color(0xFF7A1912))
            Text("Vẫn hiển thị trong giờ yên lặng, không bị thời gian chờ che mất sự cố mới, nhưng không phát âm thanh lặp liên tục.", fontSize = 12.sp, color = Color(0xFF4A1410))
        }
    }
}
