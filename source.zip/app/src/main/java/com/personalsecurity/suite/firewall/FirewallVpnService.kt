package com.personalsecurity.suite.firewall

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.system.OsConstants
import com.personalsecurity.suite.vpn.VpnController
import com.personalsecurity.suite.vpn.VpnStatus
import com.personalsecurity.suite.vpn.WireGuardManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.FileInputStream
import java.io.IOException
import java.net.Inet6Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.UUID

/** OFF / STARTING / PROTECTED / DEGRADED / ERROR – không bao giờ báo PROTECTED chỉ vì người dùng bật công tắc. */
sealed class FirewallStatus {
    data object Off : FirewallStatus()
    data object Starting : FirewallStatus()
    data class Protected(val allowedApps: Int, val since: Long, val leakTest: LeakTestResult?) : FirewallStatus()
    data class Degraded(val reason: String) : FirewallStatus()
    data class Error(val reason: String) : FirewallStatus()
}

data class LeakTestResult(val ipv4Blocked: Boolean, val ipv6Blocked: Boolean, val dnsBlocked: Boolean, val at: Long) {
    val passed get() = ipv4Blocked && ipv6Blocked && dnsBlocked
}

data class BlockEvent(
    val at: Long,
    val uid: Int,
    val app: String,
    val protocol: String,
    val destination: String,
    val port: Int,
    val reason: String, // NOT_ALLOWED | UNKNOWN_OWNER | UID_UNSUPPORTED
)

object FirewallController {
    private val _status = MutableStateFlow<FirewallStatus>(FirewallStatus.Off)
    val status: StateFlow<FirewallStatus> = _status.asStateFlow()
    private val _events = MutableStateFlow<List<BlockEvent>>(emptyList())
    val events: StateFlow<List<BlockEvent>> = _events.asStateFlow()

    internal fun update(s: FirewallStatus) { _status.value = s }

    internal fun addEvent(e: BlockEvent) {
        _events.value = (listOf(e) + _events.value).take(MAX_EVENTS)
    }

    fun clearEvents() { _events.value = emptyList() }

    fun isRunning() = _status.value is FirewallStatus.Protected || _status.value is FirewallStatus.Starting || _status.value is FirewallStatus.Degraded

    /**
     * Một danh sách chặn, hai service thay phiên:
     *  - WireGuard đang chạy → WireGuard thực thi (IncludedApplications = app được phép; cần Lockdown để chặn hẳn).
     *  - WireGuard không chạy → FirewallVpnService thực thi (Default-Deny theo định tuyến, đã xác minh).
     */
    fun enable(ctx: Context) {
        FirewallPolicy.setEnabled(ctx, true)
        when (VpnController.status.value) {
            is VpnStatus.Protected, is VpnStatus.Connecting -> VpnController.reconnect(ctx)
            else -> start(ctx)
        }
    }

    fun disable(ctx: Context) {
        FirewallPolicy.setEnabled(ctx, false)
        if (isRunning()) stop(ctx)
        if (VpnController.status.value is VpnStatus.Protected) VpnController.reconnect(ctx)
    }

    /** Gọi khi danh sách thay đổi: áp ngay cho service đang thực thi. */
    fun policyChanged(ctx: Context) {
        when {
            isRunning() -> reload(ctx)
            FirewallPolicy.enabled(ctx) && VpnController.status.value is VpnStatus.Protected -> VpnController.reconnect(ctx)
        }
    }

    /** Lượt của firewall cục bộ: khi WireGuard tắt / lỗi / bị dừng mà danh sách vẫn đang bật. */
    fun resumeIfEnabled(ctx: Context) {
        if (!FirewallPolicy.enabled(ctx) || isRunning()) return
        val vs = VpnController.status.value
        if (vs is VpnStatus.Protected || vs is VpnStatus.Connecting) return
        if (VpnService.prepare(ctx) != null) {
            update(FirewallStatus.Error("Danh sách chặn đang bật nhưng ứng dụng không còn quyền VPN."))
            return
        }
        try {
            start(ctx)
        } catch (e: Exception) {
            update(FirewallStatus.Error("Không tự bật lại được firewall khi ứng dụng chạy nền. Mở ứng dụng để bật lại."))
            FirewallNotifier.interrupted(ctx)
        }
    }

    fun start(ctx: Context) = send(ctx, FirewallVpnService.ACTION_START)
    fun stop(ctx: Context) = send(ctx, FirewallVpnService.ACTION_STOP)
    fun reload(ctx: Context) { if (isRunning()) send(ctx, FirewallVpnService.ACTION_RELOAD) }
    fun runLeakTest(ctx: Context) { if (isRunning()) send(ctx, FirewallVpnService.ACTION_LEAK_TEST) }

    private fun send(ctx: Context, action: String) {
        ctx.startService(Intent(ctx, FirewallVpnService::class.java).setAction(action))
    }

    private const val MAX_EVENTS = 300
}

/**
 * PR-FW01 PoC – Default-Deny ở tầng định tuyến:
 *  - TUN nhận toàn bộ 0.0.0.0/0 và ::/0, DNS trỏ vào địa chỉ trong TUN.
 *  - App ĐƯỢC PHÉP được loại khỏi VPN (addDisallowedApplication) → đi mạng thật, Android thực thi theo UID.
 *  - Mọi app khác (kể cả app mới, UID không xác định) bị định tuyến vào TUN; packet chỉ được đọc để ghi
 *    nhật ký rồi bỏ — không có đường chuyển tiếp nào cho lưu lượng bị chặn.
 */
class FirewallVpnService : VpnService() {
    companion object {
        const val ACTION_START = "com.personalsecurity.suite.firewall.START"
        const val ACTION_STOP = "com.personalsecurity.suite.firewall.STOP"
        const val ACTION_RELOAD = "com.personalsecurity.suite.firewall.RELOAD"
        const val ACTION_LEAK_TEST = "com.personalsecurity.suite.firewall.LEAK_TEST"

        private const val TUN_V4 = "10.111.222.1"
        private const val TUN_DNS_V4 = "10.111.222.2"
        private const val TUN_V6 = "fd00:7f:7f::1"
        private const val TUN_DNS_V6 = "fd00:7f:7f::2"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var tun: ParcelFileDescriptor? = null
    @Volatile private var readerGeneration = 0
    @Volatile private var lastLeak: LeakTestResult? = null
    @Volatile private var since = 0L
    private val seenFlows = object : LinkedHashMap<String, Long>(512, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Long>?) = size > 512
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { shutdown(FirewallStatus.Off); return START_NOT_STICKY }
            ACTION_RELOAD -> scope.launch { establish(includeSelf = false, reason = "reload") }
            ACTION_LEAK_TEST -> scope.launch { leakTest() }
            else -> {
                FirewallController.update(FirewallStatus.Starting)
                scope.launch {
                    // Android chỉ cho một VPN hoạt động: hạ tunnel WireGuard trước khi bật firewall.
                    if (WireGuardManager.isRunning(this@FirewallVpnService)) {
                        VpnController.disconnect(this@FirewallVpnService)
                        delay(800)
                    }
                    establish(includeSelf = false, reason = "start")
                }
            }
        }
        return START_NOT_STICKY
    }

    /** includeSelf = true: KHÔNG miễn trừ app này → dùng cho kiểm tra rò rỉ từ chính tiến trình của mình. */
    private fun establish(includeSelf: Boolean, reason: String): Boolean {
        if (prepare(this) != null) {
            FirewallController.update(FirewallStatus.Error("Chưa có quyền VPN."))
            return false
        }
        FirewallPolicy.prune(this)
        val allowed = FirewallPolicy.allowed(this) + FirewallPolicy.SYSTEM_EXCEPTIONS.keys
        val b = Builder()
            .setSession("PSS Firewall")
            .setMtu(1500)
            .addAddress(TUN_V4, 32)
            .addAddress(TUN_V6, 128)
            .addRoute("0.0.0.0", 0)
            .addRoute("::", 0)
            .addDnsServer(TUN_DNS_V4)
            .addDnsServer(TUN_DNS_V6)
            .setBlocking(true)
        if (Build.VERSION.SDK_INT >= 29) b.setMetered(false)
        var applied = 0
        for (pkg in allowed) {
            try {
                b.addDisallowedApplication(pkg); applied++
            } catch (_: PackageManager.NameNotFoundException) {
            }
        }
        if (!includeSelf) b.addDisallowedApplication(packageName)

        val newTun = try { b.establish() } catch (e: Exception) { null }
        if (newTun == null) {
            // Không tạo được TUN: không được báo đang bảo vệ.
            shutdown(FirewallStatus.Error("Không tạo được giao diện TUN ($reason). Quyền VPN có thể đã bị thu hồi."))
            return false
        }
        val old = tun
        tun = newTun
        val gen = ++readerGeneration
        try { old?.close() } catch (_: IOException) {}
        startReader(newTun, gen)
        if (since == 0L) since = System.currentTimeMillis()
        val leak = lastLeak
        FirewallController.update(
            if (leak != null && !leak.passed) FirewallStatus.Degraded("Kiểm tra rò rỉ thất bại – không bảo đảm Default-Deny.")
            else FirewallStatus.Protected(applied, since, leak),
        )
        FirewallNotifier.protected(this)
        return true
    }

    private fun startReader(fd: ParcelFileDescriptor, gen: Int) {
        scope.launch {
            val input = FileInputStream(fd.fileDescriptor)
            val buf = ByteArray(32767)
            while (gen == readerGeneration) {
                val n = try { input.read(buf) } catch (e: IOException) { break }
                if (n <= 0) continue
                try { inspect(buf, n) } catch (_: Exception) { /* packet hỏng: vẫn bị bỏ */ }
                // Không ghi gì trở lại TUN: mọi packet đến đây đều bị loại bỏ.
            }
        }
    }

    /** Đọc header để ghi nhật ký theo flow (không theo từng packet). */
    private fun inspect(p: ByteArray, n: Int) {
        val version = (p[0].toInt() shr 4) and 0xF
        val proto: Int
        val src: InetAddress
        val dst: InetAddress
        val l4: Int
        when (version) {
            4 -> {
                if (n < 20) return
                val ihl = (p[0].toInt() and 0xF) * 4
                proto = p[9].toInt() and 0xFF
                src = InetAddress.getByAddress(p.copyOfRange(12, 16))
                dst = InetAddress.getByAddress(p.copyOfRange(16, 20))
                l4 = ihl
            }
            6 -> {
                if (n < 40) return
                proto = p[6].toInt() and 0xFF // chưa duyệt extension header (P1)
                src = InetAddress.getByAddress(p.copyOfRange(8, 24))
                dst = InetAddress.getByAddress(p.copyOfRange(24, 40))
                l4 = 40
            }
            else -> return
        }
        val protoName = when (proto) { 6 -> "TCP"; 17 -> "UDP"; 1 -> "ICMP"; 58 -> "ICMPv6"; else -> "IP/$proto" }
        val isTcpUdp = proto == 6 || proto == 17
        val sport = if (isTcpUdp && n >= l4 + 4) ((p[l4].toInt() and 0xFF) shl 8) or (p[l4 + 1].toInt() and 0xFF) else 0
        val dport = if (isTcpUdp && n >= l4 + 4) ((p[l4 + 2].toInt() and 0xFF) shl 8) or (p[l4 + 3].toInt() and 0xFF) else 0
        val key = "$proto|${src.hostAddress}|$sport|${dst.hostAddress}|$dport"
        val now = System.currentTimeMillis()
        synchronized(seenFlows) {
            val prev = seenFlows[key]
            if (prev != null && now - prev < 60_000) return
            seenFlows[key] = now
        }
        var uid = -1
        var reason = "UNKNOWN_OWNER"
        if (isTcpUdp && Build.VERSION.SDK_INT >= 29) {
            val cm = getSystemService(ConnectivityManager::class.java)
            uid = try {
                cm.getConnectionOwnerUid(if (proto == 6) OsConstants.IPPROTO_TCP else OsConstants.IPPROTO_UDP,
                    InetSocketAddress(src, sport), InetSocketAddress(dst, dport))
            } catch (_: Exception) { -1 }
            if (uid >= 0) reason = "NOT_ALLOWED"
        } else if (isTcpUdp) {
            reason = "UID_UNSUPPORTED"
        }
        val dest = if (dst is Inet6Address) "[${dst.hostAddress}]" else dst.hostAddress ?: "?"
        val isDns = dport == 53 && (dst.hostAddress == TUN_DNS_V4 || dst.hostAddress == TUN_DNS_V6)
        FirewallController.addEvent(
            BlockEvent(now, uid, if (uid >= 0) AppCatalog.labelForUid(packageManager, uid) else "Không xác định",
                if (isDns) "DNS" else protoName, dest, dport, reason),
        )
    }

    /**
     * Tạm thời KHÔNG miễn trừ chính app này, rồi thử kết nối IPv4, IPv6 và phân giải DNS.
     * Firewall đúng thì cả ba phải thất bại. Sau đó khôi phục cấu hình bình thường.
     */
    private suspend fun leakTest() {
        if (!establish(includeSelf = true, reason = "leak-test")) return
        delay(800)
        val v4 = !canConnect("1.1.1.1", 443)
        val v6 = !canConnect("2606:4700:4700::1111", 443)
        val dns = withContext(Dispatchers.IO) {
            runCatching { InetAddress.getAllByName("pss-leaktest-${UUID.randomUUID().toString().take(8)}.example.com") }.isFailure
        }
        lastLeak = LeakTestResult(v4, v6, dns, System.currentTimeMillis())
        establish(includeSelf = false, reason = "after-leak-test")
    }

    private suspend fun canConnect(host: String, port: Int): Boolean = withContext(Dispatchers.IO) {
        try {
            Socket().use { it.connect(InetSocketAddress(InetAddress.getByName(host), port), 3000) }
            true
        } catch (_: Exception) {
            false
        }
    }

    override fun onRevoke() {
        shutdown(FirewallStatus.Error("Android đã thu hồi quyền VPN hoặc một VPN khác vừa được bật. Firewall không còn bảo vệ."))
        FirewallNotifier.interrupted(this)
        super.onRevoke()
    }

    override fun onDestroy() {
        if (FirewallController.isRunning()) {
            FirewallController.update(FirewallStatus.Error("Dịch vụ firewall đã dừng."))
            FirewallNotifier.interrupted(this)
        }
        readerGeneration++
        try { tun?.close() } catch (_: IOException) {}
        tun = null
        scope.cancel()
        super.onDestroy()
    }

    private fun shutdown(status: FirewallStatus) {
        readerGeneration++
        try { tun?.close() } catch (_: IOException) {}
        tun = null
        since = 0L
        FirewallController.update(status)
        if (status is FirewallStatus.Off) FirewallNotifier.clear(this)
        stopSelf()
    }
}
