package com.personalsecurity.suite.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.personalsecurity.suite.R

val Bg = Color(0xFFF4F6F8)
val Ink = Color(0xFF0E1726)
val Muted = Color(0xFF556070)
val Line = Color(0xFFE2E6EB)
val Hairline = Color(0xFFEEF0F3)
val Primary = Color(0xFF1748C9)
val Navy = Color(0xFF0E2A6B)
val NavyDeep = Color(0xFF071A4A)
val SoftBlue = Color(0xFFC9D6F5)
val Danger = Color(0xFFA1231B)
val WarnInk = Color(0xFF6B3300)

/** Trạng thái luôn đi kèm chữ, không chỉ dựa vào màu. */
enum class Tone(val bg: Color, val fg: Color, val outline: Color? = null) {
    OK(Color(0xFFE2F0FB), Color(0xFF0B4F8A)),
    WARN(Color(0xFFFFF0DD), Color(0xFF8A4100)),
    BAD(Color(0xFFFCE8E6), Color(0xFFA1231B)),
    NEUTRAL(Color(0xFFEEF0F3), Color(0xFF4A5463)),
    PERM(Color(0xFFEDE7FB), Color(0xFF4B2A9A)),
    UNKNOWN(Color.White, Color(0xFF4A5463), Color(0xFF8E98A6)),
}

private val SuiteColors: ColorScheme = lightColorScheme(
    primary = Primary,
    onPrimary = Color.White,
    background = Bg,
    onBackground = Ink,
    surface = Color.White,
    onSurface = Ink,
    secondaryContainer = Color(0xFFE2F0FB),
    onSecondaryContainer = Navy,
)

@Composable
fun SuiteTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = SuiteColors, content = content)
}

@Composable
fun Pill(text: String, tone: Tone, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(50)
    var m = modifier.clip(shape).background(tone.bg)
    tone.outline?.let { m = m.border(1.5.dp, it, shape) }
    Box(m.padding(horizontal = 10.dp, vertical = 3.dp)) {
        Text(text, color = tone.fg, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(),
        modifier = modifier.padding(top = 4.dp, start = 4.dp),
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 0.5.sp,
        color = Muted,
    )
}

@Composable
fun SCard(
    modifier: Modifier = Modifier,
    bg: Color = Color.White,
    border: Color = Line,
    padding: PaddingValues = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
    spacing: Dp = 8.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(16.dp)
    var m = modifier.fillMaxWidth().clip(shape).background(bg).border(1.dp, border, shape)
    if (onClick != null) m = m.clickable(role = Role.Button, onClick = onClick)
    Column(m.padding(padding), verticalArrangement = Arrangement.spacedBy(spacing), content = content)
}

@Composable
fun Note(text: String, modifier: Modifier = Modifier, color: Color = Muted) {
    Text(text, modifier = modifier.padding(horizontal = 4.dp), fontSize = 12.sp, lineHeight = 17.sp, color = color)
}

@Composable
fun Body(text: String, color: Color = Ink, size: Int = 14) {
    Text(text, fontSize = size.sp, lineHeight = (size + 6).sp, color = color)
}

@Composable
fun Kv(k: String, v: String, tone: Tone? = null) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 36.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(k, Modifier.weight(1f), fontSize = 13.sp, color = Muted)
        if (tone != null) Pill(v, tone) else Text(v, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Ink, textAlign = TextAlign.End)
    }
}

@Composable
fun ItemRow(
    title: String,
    subtitle: String? = null,
    onClick: (() -> Unit)? = null,
    leading: (@Composable () -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
) {
    var m = Modifier.fillMaxWidth().heightIn(min = 56.dp)
    if (onClick != null) m = m.clickable(role = Role.Button, onClick = onClick)
    Row(m.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        leading?.invoke()
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Ink)
            if (subtitle != null) Text(subtitle, fontSize = 12.sp, lineHeight = 16.sp, color = Muted)
        }
        when {
            trailing != null -> trailing()
            onClick != null -> Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = Muted)
        }
    }
}

@Composable
fun RowDivider() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(Hairline))
}

@Composable
fun ToggleRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    ItemRow(title, subtitle, trailing = {
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = Primary),
        )
    })
}

@Composable
fun DemoBanner() {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Tone.WARN.bg).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(stringResource(R.string.demo_banner), color = WarnInk, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun PrimaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, color: Color = Primary, enabled: Boolean = true) {
    val shape = RoundedCornerShape(12.dp)
    var m = modifier.heightIn(min = 48.dp).clip(shape).background(if (enabled) color else Color(0xFFB9C0CA))
    if (enabled) m = m.clickable(role = Role.Button, onClick = onClick)
    Box(m.padding(horizontal = 16.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun SecondaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier.heightIn(min = 48.dp).clip(shape).background(Color.White).border(1.dp, Color(0xFFC9D0D8), shape)
            .clickable(role = Role.Button, onClick = onClick).padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.heightIn(min = 36.dp).clip(RoundedCornerShape(50))
            .background(if (selected) Navy else Color(0xFFE6E9EE))
            .clickable(role = Role.Tab, onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = if (selected) Color.White else Color(0xFF33404F), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun ScoreBar(fraction: Float, color: Color = Primary, track: Color = Color(0xFFE6E9EE)) {
    Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(track)) {
        Box(Modifier.fillMaxWidth(fraction.coerceIn(0f, 1f)).height(6.dp).clip(RoundedCornerShape(3.dp)).background(color))
    }
}

/** Khung màn hình chi tiết: thanh tiêu đề + nội dung cuộn. */
@Composable
fun Screen(
    title: String,
    onBack: (() -> Unit)?,
    subtitle: String? = null,
    demo: Boolean = true,
    actions: @Composable RowScope.() -> Unit = {},
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(
            Modifier.fillMaxWidth().padding(start = if (onBack != null) 4.dp else 20.dp, end = 8.dp, top = 8.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (onBack != null) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back), tint = Ink)
                }
            }
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
                if (subtitle != null) Text(subtitle, fontSize = 12.sp, color = Muted)
            }
            actions()
        }
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (demo) DemoBanner()
            content()
            Spacer(Modifier.size(24.dp))
        }
    }
}
