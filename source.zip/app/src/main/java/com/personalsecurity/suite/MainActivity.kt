package com.personalsecurity.suite

import android.os.Bundle
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.personalsecurity.suite.ui.Bg
import com.personalsecurity.suite.ui.Primary
import com.personalsecurity.suite.ui.SuiteTheme
import com.personalsecurity.suite.ui.Tone
import com.personalsecurity.suite.ui.screens.BgProtectionScreen
import com.personalsecurity.suite.ui.screens.BtDeviceScreen
import com.personalsecurity.suite.ui.screens.DashboardScreen
import com.personalsecurity.suite.ui.screens.DeviceCareScreen
import com.personalsecurity.suite.ui.screens.FirewallScreen
import com.personalsecurity.suite.ui.screens.IdentityScreen
import com.personalsecurity.suite.ui.screens.IpTrustScreen
import com.personalsecurity.suite.ui.screens.LanguageScreen
import com.personalsecurity.suite.ui.screens.NotifPrefsScreen
import com.personalsecurity.suite.ui.screens.OnbDeniedScreen
import com.personalsecurity.suite.ui.screens.OnbVpnScreen
import com.personalsecurity.suite.ui.screens.PermissionsScreen
import com.personalsecurity.suite.ui.screens.PrivacyScreen
import com.personalsecurity.suite.ui.screens.SecurityCenterScreen
import com.personalsecurity.suite.ui.screens.SettingsScreen
import com.personalsecurity.suite.ui.screens.VaultScreen
import com.personalsecurity.suite.ui.screens.VpnBlockedScreen
import com.personalsecurity.suite.ui.screens.VpnScreen
import com.personalsecurity.suite.ui.screens.VpnConnectionScreen
import com.personalsecurity.suite.ui.screens.VpnConfigScreen
import com.personalsecurity.suite.vpn.VpnController
import com.personalsecurity.suite.firewall.FirewallController
import com.personalsecurity.suite.ui.screens.WelcomeScreen
import com.personalsecurity.suite.ui.screens.WifiSessionScreen
import com.personalsecurity.suite.ui.screens.WirelessScreen

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!BuildConfig.MULTI_LANGUAGE && !AppCompatDelegate.getApplicationLocales().isEmpty) {
            // Giai đoạn thử nghiệm: bỏ lựa chọn ngôn ngữ cũ (nếu có), APK chỉ chứa tiếng Việt.
            AppCompatDelegate.setApplicationLocales(LocaleListCompat.getEmptyLocaleList())
        }
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(android.graphics.Color.WHITE, android.graphics.Color.WHITE),
        )
        setContent { SuiteTheme { SuiteApp() } }
    }
}

private data class Tab(val route: String, val label: @Composable () -> String, val icon: ImageVector)

@Composable
fun SuiteApp() {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx.applicationContext) }
    var demo by remember { mutableStateOf(prefs.demo) }
    val tick = rememberResumeTick()
    LaunchedEffect(tick) {
        VpnController.refresh(ctx, prefs)
        FirewallController.resumeIfEnabled(ctx) // danh sách chặn bật mà không service nào chạy → firewall nhận lượt
    }
    val start = remember { if (prefs.onboarded) "dashboard" else "welcome" }
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route

    val tabs = listOf(
        Tab("dashboard", { stringResource(R.string.nav_overview) }, Icons.Filled.Shield),
        Tab("vpn", { "VPN" }, Icons.Filled.VpnKey),
        Tab("firewall", { stringResource(R.string.nav_firewall) }, Icons.Filled.Security),
        Tab("identity", { stringResource(R.string.nav_identity) }, Icons.Filled.Person),
        Tab("vault", { stringResource(R.string.nav_passwords) }, Icons.Filled.Key),
    )
    val go: (String) -> Unit = { nav.navigate(it) { launchSingleTop = true } }
    val back: () -> Unit = { nav.popBackStack() }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            if (tabs.any { it.route == route }) {
                NavigationBar(containerColor = Color.White) {
                    tabs.forEach { t ->
                        NavigationBarItem(
                            selected = route == t.route,
                            onClick = {
                                nav.navigate(t.route) {
                                    popUpTo("dashboard") { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(t.icon, contentDescription = null) },
                            label = { Text(t.label(), fontSize = 11.sp, maxLines = 1) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Primary,
                                selectedTextColor = Primary,
                                indicatorColor = Tone.OK.bg,
                            ),
                        )
                    }
                }
            }
        },
    ) { pad ->
        NavHost(
            navController = nav,
            startDestination = start,
            modifier = Modifier.padding(pad),
        ) {
            composable("welcome") {
                WelcomeScreen(onStart = {
                    prefs.onboarded = true
                    nav.navigate("dashboard") { popUpTo("welcome") { inclusive = true } }
                })
            }
            composable("onb_vpn") {
                OnbVpnScreen(
                    prefs = prefs,
                    onClose = back,
                    onGranted = { nav.navigate("vpn_connect") { popUpTo("onb_vpn") { inclusive = true } } },
                    onDenied = { nav.navigate("onb_denied") { popUpTo("onb_vpn") { inclusive = true } } },
                )
            }
            composable("onb_denied") { OnbDeniedScreen(onRetry = { nav.navigate("onb_vpn") { popUpTo("onb_denied") { inclusive = true } } }, onSkip = back) }
            composable("dashboard") { DashboardScreen(demo = demo, go = go) }
            composable("vpn") { VpnScreen(go = go) }
            composable("vpn_connect") { VpnConnectionScreen(back, go) }
            composable("vpn_config") { VpnConfigScreen(back, go) }
            composable("ip_trust") { IpTrustScreen(back) }
            composable("vpn_blocked") { VpnBlockedScreen(back, go) }
            composable("firewall") { FirewallScreen() }
            composable("privacy") { PrivacyScreen(back) }
            composable("wireless") { WirelessScreen(back, go) }
            composable("wifi_session") { WifiSessionScreen(back) }
            composable("bt_device") { BtDeviceScreen(back) }
            composable("device_care") { DeviceCareScreen(back) }
            composable("identity") { IdentityScreen() }
            composable("vault") { VaultScreen() }
            composable("security_center") { SecurityCenterScreen(back, go) }
            composable("settings") {
                SettingsScreen(back, go, demo = demo, onDemoChange = { demo = it; prefs.demo = it })
            }
            composable("language") { LanguageScreen(back) }
            composable("permissions") { PermissionsScreen(back, go, prefs) }
            composable("bg_protection") { BgProtectionScreen(back) }
            composable("notif_prefs") { NotifPrefsScreen(back, prefs) }
        }
    }
}
