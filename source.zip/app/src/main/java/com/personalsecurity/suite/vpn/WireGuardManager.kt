package com.personalsecurity.suite.vpn

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.personalsecurity.suite.BuildConfig
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.Inet6Address
import java.net.URL
import javax.net.ssl.HttpsURLConnection

/**
 * Bọc thư viện com.wireguard.android:tunnel. GoBackend tự chạy GoBackend.VpnService (userspace, không cần root),
 * protect() socket tới peer, tạo TUN bằng VpnService.Builder và chuyển tiếp gói tin.
 * Mọi lời gọi setState là blocking: chỉ gọi ngoài main thread.
 */
object WireGuardManager {
    /** Tên tunnel: tối đa 15 ký tự [a-zA-Z0-9_=+.-]. */
    private const val TUNNEL_NAME = "pss0"

    /** Điểm kiểm tra IP đầu ra qua tunnel. Bản phát hành nên dùng endpoint của backend riêng. */
    val EXIT_IP_CHECK_URL: String = BuildConfig.EXIT_IP_CHECK_URL

    @Volatile private var backend: GoBackend? = null
    @Volatile private var userStopping = false
    @Volatile private var appCtx: Context? = null

    private val tunnel = object : Tunnel {
        override fun getName(): String = TUNNEL_NAME
        override fun onStateChange(newState: Tunnel.State) {
            // GoBackend.VpnService bị hủy (onRevoke, VPN khác bật, hệ thống dừng) → báo DOWN.
            if (newState == Tunnel.State.DOWN && !userStopping) appCtx?.let { VpnController.onTunnelDown(it) }
        }
    }

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        // Hệ thống khởi động VPN khi bật Always-on: kết nối lại theo đúng quy trình kiểm tra.
        GoBackend.setAlwaysOnCallback { appCtx?.let { VpnController.connect(it) } }
    }

    private fun backend(ctx: Context): GoBackend =
        backend ?: synchronized(this) {
            backend ?: GoBackend(ctx.applicationContext).also {
                appCtx = ctx.applicationContext
                backend = it
            }
        }

    fun isRunning(ctx: Context): Boolean = runCatching { backend(ctx).runningTunnelNames.contains(TUNNEL_NAME) }.getOrDefault(false)

    fun up(ctx: Context, config: Config) {
        userStopping = false
        backend(ctx).setState(tunnel, Tunnel.State.UP, config)
    }

    fun down(ctx: Context) {
        userStopping = true
        runCatching { backend(ctx).setState(tunnel, Tunnel.State.DOWN, null) }
    }

    /** Thời điểm handshake gần nhất với peer (0 nếu chưa có). */
    fun lastHandshakeMillis(ctx: Context, config: Config): Long {
        val stats = runCatching { backend(ctx).getStatistics(tunnel) }.getOrNull() ?: return 0L
        return config.peers.maxOfOrNull { stats.peer(it.publicKey)?.latestHandshakeEpochMillis() ?: 0L } ?: 0L
    }

    /** Gọi một yêu cầu HTTPS qua mạng mặc định (lúc này là VPN) để tạo lưu lượng và đọc IP đầu ra. */
    suspend fun fetchExitIp(): String? = withContext(Dispatchers.IO) {
        try {
            val c = URL(EXIT_IP_CHECK_URL).openConnection() as HttpsURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.useCaches = false
            try {
                c.inputStream.bufferedReader().use { r ->
                    r.lineSequence().firstOrNull { it.startsWith("ip=") }?.removePrefix("ip=")?.trim()
                }
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Mạng vật lý hiện tại có IPv6 toàn cục không (nếu có mà tunnel không định tuyến IPv6 → rò rỉ). */
    @Suppress("DEPRECATION")
    fun underlyingHasIpv6(ctx: Context): Boolean {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        return cm.allNetworks.any { n ->
            val caps = cm.getNetworkCapabilities(n) ?: return@any false
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return@any false
            cm.getLinkProperties(n)?.linkAddresses?.any { la ->
                val a = la.address
                a is Inet6Address && !a.isLinkLocalAddress && !a.isLoopbackAddress && !a.isSiteLocalAddress
            } == true
        }
    }

    /** Android đã ghi nhận mạng VPN và DNS của nó. */
    @Suppress("DEPRECATION")
    fun vpnNetworkDnsCount(ctx: Context): Int {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val n = cm.allNetworks.firstOrNull { cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true } ?: return -1
        return cm.getLinkProperties(n)?.dnsServers?.size ?: 0
    }
}
