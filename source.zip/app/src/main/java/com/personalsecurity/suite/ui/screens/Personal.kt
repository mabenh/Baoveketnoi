package com.personalsecurity.suite.ui.screens

import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PersistableBundle
import android.os.StatFs
import android.view.WindowManager
import android.provider.Settings as AndroidSettings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.personalsecurity.suite.findActivity
import com.personalsecurity.suite.openSettings
import com.personalsecurity.suite.ui.Body
import com.personalsecurity.suite.ui.Chip
import com.personalsecurity.suite.ui.Ink
import com.personalsecurity.suite.ui.ItemRow
import com.personalsecurity.suite.ui.Kv
import com.personalsecurity.suite.ui.Muted
import com.personalsecurity.suite.ui.Navy
import com.personalsecurity.suite.ui.Note
import com.personalsecurity.suite.ui.Pill
import com.personalsecurity.suite.ui.Primary
import com.personalsecurity.suite.ui.PrimaryButton
import com.personalsecurity.suite.ui.RowDivider
import com.personalsecurity.suite.ui.SCard
import com.personalsecurity.suite.ui.ScoreBar
import com.personalsecurity.suite.ui.Screen
import com.personalsecurity.suite.ui.SecondaryButton
import com.personalsecurity.suite.ui.SectionLabel
import com.personalsecurity.suite.ui.Tone
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.security.SecureRandom

// ---------------- Device Care (bộ nhớ và pin là dữ liệu thật) ----------------

@Composable
fun DeviceCareScreen(back: () -> Unit) {
    val ctx = LocalContext.current
    val stat = remember { StatFs(Environment.getDataDirectory().path) }
    val total = stat.totalBytes / 1_000_000_000.0
    val free = stat.availableBytes / 1_000_000_000.0
    val battery = remember { ctx.getSystemService(BatteryManager::class.java).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) }
    Screen("Device Care", onBack = back, demo = false) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SCard(Modifier.weight(1f)) {
                SectionLabel("Bộ nhớ")
                Text("%.0f / %.0f GB".format(total - free, total), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
                ScoreBar(((total - free) / total).toFloat())
                Text("Còn %.1f GB trống".format(free), fontSize = 12.sp, color = Muted)
            }
            SCard(Modifier.weight(1f)) {
                SectionLabel("Pin")
                Text(if (battery in 0..100) "$battery%" else "Không đọc được", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
                ScoreBar((battery.coerceIn(0, 100)) / 100f)
                Text("Theo dữ liệu Android", fontSize = 12.sp, color = Muted)
            }
        }
        Note("Bộ nhớ và pin là số liệu thật đọc từ Android. Danh sách bên dưới là dữ liệu minh họa.")
        SectionLabel("Ứng dụng cần chú ý · minh họa")
        SCard(spacing = 0.dp, padding = PaddingValues(14.dp, 2.dp)) {
            ItemRow("Đèn pin Pro", "Có quyền Trợ năng + hiển thị trên app khác", trailing = { Pill("Rủi ro cao", Tone.BAD) })
            RowDivider()
            ItemRow("Quét mã QR", "Truy cập vị trí khi chạy nền", trailing = { Pill("Xem lại", Tone.WARN) })
            RowDivider()
            ItemRow("Mua sắm M", "Dùng 18% pin nền trong 24 giờ", trailing = { Pill("Pin bất thường", Tone.WARN) })
            RowDivider()
            ItemRow("5 app ít dùng", "Không mở trong 60 ngày", trailing = { Pill("Gợi ý", Tone.NEUTRAL) })
        }
        SCard {
            Text("Bạn tự quyết trong Cài đặt Android", fontWeight = FontWeight.SemiBold, color = Ink)
            Note("Ứng dụng không tự dừng tiến trình app khác. Mở đúng trang cài đặt để bạn thao tác:")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SecondaryButton("Trợ năng", { openSettings(ctx, AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS) }, Modifier.weight(1f))
                SecondaryButton("Tối ưu pin", { openSettings(ctx, AndroidSettings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) }, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SecondaryButton("Usage Access", { openSettings(ctx, AndroidSettings.ACTION_USAGE_ACCESS_SETTINGS) }, Modifier.weight(1f))
                SecondaryButton("Ứng dụng", { openSettings(ctx, AndroidSettings.ACTION_APPLICATION_SETTINGS) }, Modifier.weight(1f))
            }
        }
    }
}

// ---------------- Identity Center ----------------

@Composable
fun IdentityScreen() {
    val steps = listOf(
        "Đổi mật khẩu tại trang chính thức của Diễn đàn X",
        "Đổi mật khẩu email chính nếu từng dùng lại",
        "Bật MFA hoặc passkey cho email và ngân hàng",
        "Đăng xuất các phiên đăng nhập cũ",
        "Kiểm tra email / số điện thoại khôi phục",
    )
    val done = remember { mutableStateListOf(true, false, false, false, false) }
    Screen("Identity Center", onBack = null) {
        SCard(spacing = 0.dp, padding = PaddingValues(16.dp, 2.dp)) {
            ItemRow("minh.t•••@gmail.com", "Đã xác minh · theo dõi hằng ngày", trailing = { Pill("● 2 sự cố", Tone.BAD) })
            RowDivider()
            ItemRow("minh@cong•••.vn", "Đã xác minh · kiểm tra 08:00", trailing = { Pill("✓ Không thấy", Tone.OK) })
        }
        SCard(border = Color(0xFFF0B7B1)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Diễn đàn X — rò rỉ 03/2024", Modifier.weight(1f), fontWeight = FontWeight.Bold, color = Ink); Pill("Mới", Tone.BAD)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Pill("Email", Tone.NEUTRAL); Pill("Mật khẩu (đã băm)", Tone.NEUTRAL); Pill("SĐT", Tone.NEUTRAL) }
            Note("Nguồn: Have I Been Pwned · phát hiện 08:00. Email có trong rò rỉ không có nghĩa tài khoản đang bị chiếm.")
        }
        SCard(spacing = 4.dp) {
            Row { SectionLabel("Việc cần làm", Modifier.weight(1f)); Text("${done.count { it }}/5 xong", fontSize = 12.sp, color = Muted) }
            steps.forEachIndexed { i, s ->
                ItemRow(s, null, onClick = { done[i] = !done[i] }, leading = {
                    Box(
                        Modifier.size(22.dp).clip(RoundedCornerShape(6.dp)).background(if (done[i]) Primary else Tone.NEUTRAL.bg),
                        contentAlignment = Alignment.Center,
                    ) { if (done[i]) Text("✓", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                }, trailing = {})
            }
        }
        SCard {
            Text("Tài khoản mạng xã hội", fontWeight = FontWeight.SemiBold, color = Ink)
            Note("3 tài khoản tự khai báo. Ứng dụng không yêu cầu mật khẩu, không thu thập cookie/session; chỉ mở trang bảo mật chính thức.")
        }
    }
}

// ---------------- Password Vault (UI demo, không lưu dữ liệu) ----------------

private const val CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#\$%^&*-_=+?"

private fun generatePassword(len: Int): String {
    val rnd = SecureRandom()
    return buildString { repeat(len) { append(CHARS[rnd.nextInt(CHARS.length)]) } }
}

@Composable
fun VaultScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var unlocked by remember { mutableStateOf(false) }
    var master by remember { mutableStateOf("") }
    var len by remember { mutableStateOf(24) }
    var pw by remember { mutableStateOf(generatePassword(24)) }
    var copied by remember { mutableStateOf(false) }

    // Tự khóa khi app xuống nền; chặn chụp màn hình khi kho đang mở.
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_STOP) { unlocked = false; master = "" } }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    DisposableEffect(unlocked) {
        val window = ctx.findActivity()?.window
        if (unlocked) window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }

    if (!unlocked) {
        Screen("Kho mật khẩu", onBack = null) {
            Pill("Beta nội bộ · chờ audit mật mã độc lập", Tone.WARN)
            Column(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.size(88.dp).clip(RoundedCornerShape(26.dp)).background(Navy), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Lock, null, tint = Color.White, modifier = Modifier.size(40.dp))
                }
                Text("Kho mật khẩu đã khóa", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text("Bản prototype chỉ minh họa giao diện: không lưu, không mã hóa và không đồng bộ dữ liệu. Không nhập mật khẩu thật.", fontSize = 13.sp, color = Muted, textAlign = TextAlign.Center)
            }
            OutlinedTextField(
                value = master, onValueChange = { master = it },
                label = { Text("Mật khẩu chủ (demo)") },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true, modifier = Modifier.fillMaxWidth(),
            )
            PrimaryButton("Mở khóa", { unlocked = true }, Modifier.fillMaxWidth(), enabled = master.isNotEmpty())
            Note("Không có quản trị viên nào khôi phục được kho thay bạn. Mất cả mật khẩu chủ và Recovery Key đồng nghĩa mất dữ liệu.")
        }
    } else {
        Screen("Kho mật khẩu", onBack = null, subtitle = "Đang mở · tự khóa khi rời ứng dụng", actions = {
            IconButton(onClick = { unlocked = false; master = "" }) { Icon(Icons.Filled.Lock, "Khóa", tint = Ink) }
        }) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(Triple("1", "Bị lộ", Tone.BAD), Triple("2", "Yếu", Tone.WARN), Triple("1", "Dùng lại", Tone.WARN)).forEach { (n, l, t) ->
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(t.bg).padding(10.dp)) {
                        Text(n, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = t.fg); Text(l, fontSize = 12.sp, color = t.fg)
                    }
                }
            }
            SCard(spacing = 0.dp, padding = PaddingValues(14.dp, 2.dp)) {
                ItemRow("Diễn đàn X", "minh.t•••@gmail.com", trailing = { Pill("Bị lộ", Tone.BAD) }); RowDivider()
                ItemRow("Email cá nhân", "passkey", trailing = { Pill("Mạnh", Tone.OK) }); RowDivider()
                ItemRow("Ngân hàng A", "0912•••456", trailing = { Pill("Mạnh", Tone.OK) }); RowDivider()
                ItemRow("Mua sắm M", "dùng lại ở 1 nơi", trailing = { Pill("Dùng lại", Tone.WARN) })
            }
            SCard(spacing = 10.dp) {
                Row { SectionLabel("Tạo mật khẩu (CSPRNG)", Modifier.weight(1f)); Text("$len ký tự", fontSize = 12.sp, color = Muted) }
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color(0xFFF4F6F8)).padding(12.dp)) {
                    Text(pw, fontFamily = FontFamily.Monospace, fontSize = 14.sp, color = Ink)
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(16, 24, 32, 64).forEach { n -> Chip("$n", n == len) { len = n; pw = generatePassword(n) } }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SecondaryButton("Tạo lại", { pw = generatePassword(len) }, Modifier.weight(1f))
                    SecondaryButton(if (copied) "Đã chép · xoá sau 30s" else "Sao chép", {
                        val cm = ctx.getSystemService(ClipboardManager::class.java)
                        val clip = ClipData.newPlainText("password", pw)
                        if (Build.VERSION.SDK_INT >= 33) {
                            clip.description.extras = PersistableBundle().apply { putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true) }
                        }
                        cm.setPrimaryClip(clip)
                        copied = true
                        scope.launch {
                            delay(30_000)
                            if (Build.VERSION.SDK_INT >= 28) cm.clearPrimaryClip() else cm.setPrimaryClip(ClipData.newPlainText("", ""))
                            copied = false
                        }
                    }, Modifier.weight(1f))
                }
            }
            Note("Màn hình kho chặn chụp ảnh màn hình (FLAG_SECURE). Kho thật chỉ phát hành sau khi audit mật mã độc lập (Argon2id, AEAD, zero-knowledge).")
        }
    }
}

// ---------------- Security Center / Notification Center ----------------

private data class Alert(val time: String, val title: String, val detail: String, val sev: Pair<String, Tone>, val st: Pair<String, Tone>, val key: String)

@Composable
fun SecurityCenterScreen(back: () -> Unit, go: (String) -> Unit) {
    var filter by remember { mutableStateOf("all") }
    val crit = "Khẩn cấp" to Tone.BAD
    val high = "Cao" to Tone.BAD
    val mid = "Trung bình" to Tone.WARN
    val info = "Thông tin" to Tone.NEUTRAL
    val open = "Mở" to Tone.PERM
    val all = listOf(
        Alert("10:23", "Tuyến tài chính bị chặn", "VN-STATIC-01 không phản hồi · đã chặn theo chính sách", crit, open, "open"),
        Alert("09:31", "Wi-Fi có thay đổi bất thường ×2", "AP + DNS đổi cùng phiên · độ chắc chắn trung bình", mid, "Đã xem" to Tone.NEUTRAL, "ack"),
        Alert("09:12", "Ghép đôi Bluetooth lạ", "“BT-7F21” · chờ bạn xác nhận", mid, "Đã vuốt bỏ · chưa khắc phục" to Tone.WARN, "dismissed"),
        Alert("08:47", "Giám sát bị giới hạn", "Quyền quét Bluetooth chưa được cấp", info, "Đã thao tác · đang kiểm tra" to Tone.PERM, "verifying"),
        Alert("08:00", "Email xuất hiện trong rò rỉ mới", "Nguồn: Have I Been Pwned · Diễn đàn X", high, open, "open"),
        Alert("Hôm qua", "Gateway SG-01 rời pool ưu tiên", "Uy tín IP dưới ngưỡng · thay bằng SG-03", info, "✓ Đã xử lý" to Tone.OK, "resolved"),
    )
    val list = all.filter {
        when (filter) {
            "open" -> it.key != "resolved"
            "high" -> it.sev == crit || it.sev == high
            "dismissed" -> it.key == "dismissed"
            "resolved" -> it.key == "resolved"
            else -> true
        }
    }
    Screen("Security Center", onBack = back, actions = {
        IconButton(onClick = { go("notif_prefs") }) { Icon(Icons.Filled.Tune, "Tùy chọn thông báo", tint = Ink) }
    }) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SCard(Modifier.weight(1f), padding = PaddingValues(12.dp, 10.dp), spacing = 2.dp) { Text("Dịch vụ", fontSize = 11.sp, color = Muted); Text("✓ Hoạt động · 09:40", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Ink) }
            SCard(Modifier.weight(1f), padding = PaddingValues(12.dp, 10.dp), spacing = 2.dp) { Text("Gửi thông báo", fontSize = 11.sp, color = Muted); Text("✓ Bật · 4/5 kênh", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Ink) }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("all" to "Tất cả", "open" to "Chưa xử lý", "high" to "Mức cao", "dismissed" to "Đã vuốt bỏ", "resolved" to "Đã xử lý").forEach { (k, l) ->
                Chip(l, filter == k) { filter = k }
            }
        }
        SCard(spacing = 0.dp, padding = PaddingValues(14.dp, 2.dp)) {
            if (list.isEmpty()) Text("Không có cảnh báo trong bộ lọc này.", Modifier.padding(20.dp), color = Muted)
            list.forEachIndexed { i, a ->
                if (i > 0) RowDivider()
                Row(Modifier.padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(a.time, Modifier.size(width = 52.dp, height = 18.dp), fontSize = 11.sp, color = Muted)
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(a.title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Ink)
                        Text(a.detail, fontSize = 12.sp, color = Muted)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { Pill(a.sev.first, a.sev.second); Pill(a.st.first, a.st.second) }
                    }
                }
            }
        }
        Note("Vuốt bỏ thông báo không có nghĩa là đã khắc phục. Chỉ “Đã xử lý” khi hệ thống kiểm tra lại có bằng chứng. Không lưu URL, DNS query hay nội dung lưu lượng.")
        Spacer(Modifier.size(4.dp))
    }
}
