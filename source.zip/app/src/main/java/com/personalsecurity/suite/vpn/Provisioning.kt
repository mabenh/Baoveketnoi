package com.personalsecurity.suite.vpn

import android.content.Context
import com.personalsecurity.suite.BuildConfig
import com.wireguard.crypto.KeyPair
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.Signature
import java.security.spec.X509EncodedKeySpec
import java.time.Instant
import java.util.Base64
import javax.net.ssl.HttpsURLConnection

/**
 * Nhận cấu hình WireGuard từ Provisioning API (backend/API.md).
 * - Cặp khóa Curve25519 sinh trên máy; chỉ PublicKey rời thiết bị.
 * - Response phải có chữ ký ECDSA P-256 hợp lệ theo khóa công khai GHIM lúc build
 *   (BuildConfig.CONFIG_SIGNING_PUBLIC_KEY), đúng nonce và device_id của request này.
 * - PrivateKey được chèn vào cấu hình tại máy rồi mã hóa bằng Android Keystore (ConfigStore).
 */
object Provisioning {
    sealed class Result {
        data class Ok(val peerId: String, val ipv4: String, val expiresAt: String) : Result()
        data class Error(val code: String, val message: String) : Result()
    }

    private const val PREFS = "provisioning"
    private val rnd = SecureRandom()

    private fun randomToken(bytes: Int): String {
        val b = ByteArray(bytes).also { rnd.nextBytes(it) }
        return Base64.getUrlEncoder().withoutPadding().encodeToString(b)
    }

    /** ID ngẫu nhiên theo lượt cài đặt — không dùng model, IMEI hay serial. */
    fun deviceId(ctx: Context): String {
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return sp.getString("device_id", null) ?: randomToken(16).also { sp.edit().putString("device_id", it).apply() }
    }

    fun savedBaseUrl(ctx: Context): String = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("base_url", "") ?: ""

    fun hasPinnedKey(): Boolean = BuildConfig.CONFIG_SIGNING_PUBLIC_KEY.isNotBlank()

    private fun sha256Hex(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

    private fun verifySignature(json: JSONObject, configText: String): Boolean {
        val msg = listOf(
            "PSS-WG-PROVISION-v1",
            json.getString("peer_id"), json.getString("device_id"), json.getString("nonce"),
            json.getString("issued_at"), json.getString("expires_at"), sha256Hex(configText),
        ).joinToString("\n").toByteArray(Charsets.UTF_8)
        return try {
            val pub = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(Base64.getDecoder().decode(BuildConfig.CONFIG_SIGNING_PUBLIC_KEY)))
            Signature.getInstance("SHA256withECDSA").run {
                initVerify(pub)
                update(msg)
                verify(Base64.getDecoder().decode(json.getString("signature")))
            }
        } catch (e: Exception) {
            false
        }
    }

    private fun httpMessage(code: Int, apiCode: String?): String = when (apiCode) {
        "unauthorized" -> "Phiên đăng nhập không hợp lệ hoặc đã hết hạn."
        "account_locked" -> "Tài khoản đang bị khóa."
        "vpn_not_entitled" -> "Tài khoản không có quyền VPN hoặc gói đã hết hạn."
        "device_limit_reached" -> "Tài khoản đã đủ số thiết bị. Gỡ thiết bị cũ rồi thử lại."
        "public_key_in_use" -> "Khóa đã được dùng ở nơi khác. Thử lại để tạo khóa mới."
        "rate_limited" -> "Quá nhiều yêu cầu. Thử lại sau."
        "gateway_unavailable", "pool_exhausted" -> "Máy chủ VPN tạm thời không sẵn sàng. Thử lại sau."
        else -> "Máy chủ trả lỗi HTTP $code."
    }

    suspend fun provision(ctx: Context, baseUrl: String, accessToken: String): Result = withContext(Dispatchers.IO) {
        val url = baseUrl.trim().trimEnd('/')
        if (!url.startsWith("https://")) return@withContext Result.Error("insecure_url", "Chỉ chấp nhận địa chỉ https://.")
        if (!hasPinnedKey()) return@withContext Result.Error("no_signing_key", "Bản build chưa ghim khóa xác minh cấu hình (CONFIG_SIGNING_PUBLIC_KEY).")
        if (accessToken.isBlank()) return@withContext Result.Error("no_token", "Thiếu access token.")
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("base_url", url).apply()

        val deviceId = deviceId(ctx)
        val keyPair = KeyPair() // sinh trên máy
        val nonce = randomToken(24)
        val body = JSONObject()
            .put("device_id", deviceId)
            .put("client_public_key", keyPair.publicKey.toBase64())
            .put("nonce", nonce)
            .toString()

        val conn = try {
            URL("$url/api/v1/vpn/provision").openConnection() as HttpsURLConnection
        } catch (e: Exception) {
            return@withContext Result.Error("bad_url", "Địa chỉ máy chủ không hợp lệ.")
        }
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 10_000
            conn.readTimeout = 15_000
            conn.useCaches = false
            conn.doOutput = true
            conn.setRequestProperty("Authorization", "Bearer ${accessToken.trim()}")
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Accept", "application/json")
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code != 200) {
                val apiCode = runCatching { JSONObject(text).getJSONObject("error").getString("code") }.getOrNull()
                return@withContext Result.Error(apiCode ?: "http_$code", httpMessage(code, apiCode))
            }
            val json = JSONObject(text)
            val configText = json.getString("config_text")
            if (json.getString("nonce") != nonce || json.getString("device_id") != deviceId) {
                return@withContext Result.Error("replay_or_mismatch", "Phản hồi không khớp với yêu cầu (nonce/device_id). Đã từ chối.")
            }
            if (!verifySignature(json, configText)) {
                return@withContext Result.Error("bad_signature", "Chữ ký cấu hình không hợp lệ. Đã từ chối cấu hình.")
            }
            if (Instant.parse(json.getString("expires_at")).isBefore(Instant.now())) {
                return@withContext Result.Error("expired", "Cấu hình đã hết hạn.")
            }
            if (configText.contains("PrivateKey", ignoreCase = true) || !configText.contains("[Interface]\n")) {
                return@withContext Result.Error("bad_config", "Cấu hình từ máy chủ không đúng định dạng mong đợi.")
            }
            val full = configText.replaceFirst("[Interface]\n", "[Interface]\nPrivateKey = ${keyPair.privateKey.toBase64()}\n")
            ConfigStore.save(ctx, full) // parse + mã hóa Keystore
            Result.Ok(json.getString("peer_id"), json.getString("ipv4"), json.getString("expires_at"))
        } catch (e: Exception) {
            Result.Error("network_error", "Không kết nối được máy chủ (${e.javaClass.simpleName}).")
        } finally {
            conn.disconnect()
        }
    }
}
