package com.personalsecurity.suite.vpn

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.personalsecurity.suite.MainActivity
import com.personalsecurity.suite.R

/**
 * Thông báo trạng thái VPN. Nội dung không chứa IP, SSID, email hay tên tài khoản (an toàn trên màn hình khóa).
 * Nút trong thông báo chỉ mở ứng dụng, không thực thi thao tác nhạy cảm.
 */
object StatusNotifier {
    private const val CH_STATUS = "protection_status"
    private const val CH_CRITICAL = "critical_security"
    private const val ID = 1001

    private fun ensureChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_STATUS, "Trạng thái bảo vệ", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_CRITICAL, "Bảo mật khẩn cấp", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun post(ctx: Context, channel: String, title: String, text: String, ongoing: Boolean) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return // Không có quyền: trạng thái vẫn hiển thị trong app.
        ensureChannels(ctx)
        val open = PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_stat_shield)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(ongoing)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(ID, n)
        } catch (_: SecurityException) {
        }
    }

    fun connecting(ctx: Context) = post(ctx, CH_STATUS, "Đang kết nối VPN", "Chưa được bảo vệ cho tới khi kiểm tra kết nối đạt.", true)
    fun protected(ctx: Context) = post(ctx, CH_STATUS, "VPN protection đang hoạt động", "Mở ứng dụng để xem chi tiết.", true)
    fun failed(ctx: Context) = post(ctx, CH_STATUS, "Không thể kết nối VPN", "Lưu lượng không đi qua VPN. Mở ứng dụng để xem nguyên nhân.", false)
    fun interrupted(ctx: Context, reason: InterruptReason) =
        post(ctx, CH_CRITICAL, "Bảo vệ VPN bị gián đoạn", if (reason == InterruptReason.REVOKED) "Quyền VPN đã thay đổi. Mở ứng dụng để kiểm tra." else "Tuyến bảo vệ không còn hoạt động. Mở ứng dụng để kiểm tra.", false)

    fun clear(ctx: Context) = NotificationManagerCompat.from(ctx).cancel(ID)
}
