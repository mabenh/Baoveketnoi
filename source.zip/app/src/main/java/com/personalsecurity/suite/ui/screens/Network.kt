package com.personalsecurity.suite.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.provider.Settings as AndroidSettings
import com.personalsecurity.suite.BuildConfig
import com.personalsecurity.suite.R
import com.personalsecurity.suite.vpn.ConfigStore
import com.personalsecurity.suite.vpn.VpnController
import com.personalsecurity.suite.vpn.VpnStatus
import com.personalsecurity.suite.vpn.endpointText
import androidx.compose.runtime.collectAsState
import com.personalsecurity.suite.openSettings
import com.personalsecurity.suite.rememberNetState
import com.personalsecurity.suite.ui.Bg
import com.personalsecurity.suite.ui.Body
import com.personalsecurity.suite.ui.DemoBanner
import com.personalsecurity.suite.ui.Ink
import com.personalsecurity.suite.ui.ItemRow
import com.personalsecurity.suite.ui.Kv
import com.personalsecurity.suite.ui.Muted
import com.personalsecurity.suite.ui.Navy
import com.personalsecurity.suite.ui.Note
import com.personalsecurity.suite.ui.Pill
import com.personalsecurity.suite.ui.Primary
import com.personalsecurity.suite.ui.PrimaryButton
import com.personalsecurity.suite.ui.RowDivider
import com.personalsecurity.suite.ui.SCard
import com.personalsecurity.suite.ui.ScoreBar
import com.personalsecurity.suite.ui.Screen
import com.personalsecurity.suite.ui.SecondaryButton
import com.personalsecurity.suite.ui.SectionLabel
import com.personalsecurity.suite.ui.SoftBlue
import com.personalsecurity.suite.ui.Tone
import com.personalsecurity.suite.ui.WarnInk

// ---------------- Tổng quan ----------------

@Composable
private fun Tile(title: String, status: String, tone: Tone, modifier: Modifier, onClick: () -> Unit) {
    SCard(modifier = modifier.heightIn(min = 84.dp), padding = androidx.compose.foundation.layout.PaddingValues(14.dp, 12.dp), onClick = onClick) {
        Text(title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Ink)
        Pill(status, tone)
    }
}

@Composable
fun DashboardScreen(demo: Boolean, go: (String) -> Unit) {
    val net = rememberNetState()
    Column(
        Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp, start = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Image(painterResource(R.drawable.logo), null, Modifier.size(26.dp).clip(RoundedCornerShape(7.dp)), contentScale = ContentScale.Crop)
                    Text("PERSONAL SECURITY SUITE", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Muted, letterSpacing = 0.5.sp)
                }
                Text(stringResource(R.string.nav_overview), fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ink)
            }
            IconButton(onClick = { go("settings") }) { Icon(Icons.Filled.Settings, stringResource(R.string.settings), tint = Ink) }
            Box {
                IconButton(onClick = { go("security_center") }) { Icon(Icons.Filled.Notifications, stringResource(R.string.security_center), tint = Ink) }
                if (demo) Box(Modifier.align(Alignment.TopEnd).padding(6.dp).size(16.dp).clip(RoundedCornerShape(8.dp)).background(Tone.BAD.fg), contentAlignment = Alignment.Center) {
                    Text("2", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (demo) {
            DemoBanner()
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Navy).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(Icons.Filled.Shield, null, tint = Color.White, modifier = Modifier.size(32.dp))
                    Column {
                        Text("VPN đang hoạt động", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text("${BuildConfig.GATEWAY_ID} · ${BuildConfig.GATEWAY_REGION}", color = SoftBlue, fontSize = 13.sp)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("DNS" to "Qua tunnel", "IPv6" to "Đã chặn", "IP công khai" to "203.0.113.24").forEach { (k, v) ->
                        Column(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(Color.White.copy(alpha = 0.08f)).padding(8.dp)) {
                            Text(k, color = SoftBlue, fontSize = 11.sp); Text(v, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Box(
                    Modifier.fillMaxWidth().heightIn(min = 44.dp).clip(RoundedCornerShape(12.dp)).background(Color.White).clickable(role = Role.Button) { go("vpn") },
                    contentAlignment = Alignment.Center,
                ) { Text("Quản lý tuyến kết nối", color = Navy, fontWeight = FontWeight.SemiBold) }
            }
            SCard(bg = Color(0xFFFFF8EE), border = Color(0xFFF2C58F), onClick = { go("wireless") }) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(Icons.Filled.Warning, null, tint = Tone.WARN.fg)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Cần chú ý: Wi-Fi “Cafe_Free” là mạng mở", color = WarnInk, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text("Lưu lượng hiện vẫn đi qua VPN. Tránh tắt VPN khi đăng nhập tài khoản quan trọng.", color = Muted, fontSize = 13.sp)
                    }
                }
            }
        } else {
            // Chế độ thực: chỉ hiển thị những gì đọc được từ Android, không suy diễn an toàn.
            VpnStatusCard(go)
            Note("Mạng hiện tại: ${net.type}${if (net.connected && !net.validated) " · chưa xác thực Internet" else ""}${if (net.vpn) " · Android báo có VPN đang hoạt động" else ""}.")
        }

        SectionLabel("Các lớp bảo vệ")
        val unk = stringResource(R.string.status_unknown)
        val tiles = if (demo) listOf(
            Triple("Tường lửa", "✓ 4 app bị chặn" to Tone.OK, "firewall"),
            Triple("Wi-Fi & Bluetooth", "! Cần chú ý" to Tone.WARN, "wireless"),
            Triple("Danh tính", "● 2 sự cố rò rỉ" to Tone.BAD, "identity"),
            Triple("Kho mật khẩu", "Đã khóa" to Tone.NEUTRAL, "vault"),
            Triple("Privacy Mode", "Đang tắt" to Tone.NEUTRAL, "privacy"),
            Triple("Thiết bị", "Chưa kiểm tra" to Tone.UNKNOWN, "device_care"),
        ) else listOf(
            Triple("Tường lửa", stringResource(R.string.status_permission_required) to Tone.PERM, "firewall"),
            Triple("Wi-Fi & Bluetooth", unk to Tone.UNKNOWN, "wireless"),
            Triple("Danh tính", unk to Tone.UNKNOWN, "identity"),
            Triple("Kho mật khẩu", "Đã khóa" to Tone.NEUTRAL, "vault"),
            Triple("Privacy Mode", stringResource(R.string.status_limited) to Tone.WARN, "privacy"),
            Triple("Thiết bị", "Xem dữ liệu thật" to Tone.NEUTRAL, "device_care"),
        )
        tiles.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { (t, s, r) -> Tile(t, s.first, s.second, Modifier.weight(1f)) { go(r) } }
            }
        }
        Note("Giám sát theo sự kiện hệ thống, không phải 24/7 tuyệt đối. Mỗi lớp chỉ hiển thị trạng thái đã kiểm chứng.")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SecondaryButton("Chạy nền", { go("bg_protection") }, Modifier.weight(1f))
            SecondaryButton("Security Center", { go("security_center") }, Modifier.weight(1f))
        }
        Spacer(Modifier.size(16.dp))
    }
}

// ---------------- VPN ----------------

@Composable
fun VpnScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    val st = VpnController.status.collectAsState().value
    val cfg = remember(st) { ConfigStore.load(ctx) }
    Screen("VPN", onBack = null, demo = false) {
        VpnStatusCard(go)
        SectionLabel("Máy chủ")
        SCard(spacing = 2.dp) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("${BuildConfig.GATEWAY_REGION}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Text("${BuildConfig.GATEWAY_ID} · WireGuard", fontSize = 12.sp, color = Muted)
                }
                Pill("Máy chủ duy nhất", Tone.NEUTRAL)
            }
            Kv("Endpoint", cfg?.endpointText() ?: "Chưa có cấu hình")
            Kv("IP đầu ra", (st as? VpnStatus.Protected)?.exitIp ?: "Chưa xác minh")
            Note("Giai đoạn thử nghiệm chỉ có một máy chủ tại ${BuildConfig.GATEWAY_REGION}: không chọn vùng, không tự chuyển máy chủ. Mất kết nối thì báo gián đoạn, không chuyển sang tuyến khác.")
        }
        SectionLabel("Chống rò rỉ")
        SCard(spacing = 0.dp, padding = androidx.compose.foundation.layout.PaddingValues(16.dp, 4.dp)) {
            val p = st as? VpnStatus.Protected
            Kv("DNS", p?.dns ?: "Chưa xác minh", if (p != null) Tone.OK else Tone.UNKNOWN)
            Kv("IPv6", p?.ipv6 ?: "Chưa xác minh", if (p != null) Tone.OK else Tone.UNKNOWN)
            RowDivider()
            ItemRow("Kill Switch (Always-on & Lockdown)", "Bật “Luôn bật VPN” và “Chặn kết nối không có VPN” trong Cài đặt Android", onClick = { openSettings(ctx, AndroidSettings.ACTION_VPN_SETTINGS) })
        }
        Note("Ngân hàng có thể yêu cầu xác minh hoặc từ chối IP VPN. Khi đó hãy ngắt VPN cho giao dịch; ứng dụng không né hệ thống chống gian lận.")
    }
}

@Composable
private fun RouteRow(title: String, sub: String, status: String, tone: Tone, highlight: Boolean) {
    val shape = RoundedCornerShape(12.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(if (highlight) Color(0xFFF3F7FF) else Color.White)
            .border(1.dp, if (highlight) Primary else Color(0xFFE2E6EB), shape).padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Ink)
            Text(sub, fontSize = 12.sp, color = Muted, lineHeight = 16.sp)
        }
        Pill(status, tone)
    }
}

@Composable
fun VpnBlockedScreen(back: () -> Unit, go: (String) -> Unit) {
    Screen("Tuyến tài chính", onBack = back) {
        SCard(bg = Tone.BAD.bg, border = Color(0xFFF0B7B1), spacing = 10.dp) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(Icons.Filled.Block, null, tint = Tone.BAD.fg, modifier = Modifier.size(32.dp))
                Text("Đã chặn lưu lượng tuyến tài chính", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF7A1912))
            }
            Body("Gateway VN-STATIC-01 không phản hồi lúc 10:23. Để không đổi IP giữa phiên giao dịch và không lộ IP thật, ứng dụng đã chặn kết nối thay vì tự chuyển tuyến.", Color(0xFF4A1410))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Ngân hàng A", "Ví điện tử B", "Chứng khoán C").forEach { Pill(it, Tone.NEUTRAL) }
            }
            Note("Các app khác vẫn đi qua tuyến chung (SG-03).", color = Color(0xFF4A1410))
        }
        SectionLabel("Bạn muốn làm gì?")
        PrimaryButton("Thử kết nối lại VN-STATIC-01", back, Modifier.fillMaxWidth())
        SecondaryButton("Giữ chặn và chờ", back, Modifier.fillMaxWidth())
        SCard(onClick = {}) {
            Text("Tạm dùng tuyến động", fontWeight = FontWeight.SemiBold, color = Ink)
            Text("IP sẽ thay đổi; ngân hàng có thể yêu cầu xác minh lại. Cần bạn xác nhận lần nữa.", fontSize = 13.sp, color = Muted)
        }
        SCard(onClick = {}) {
            Text("Kết nối trực tiếp", fontWeight = FontWeight.SemiBold, color = Ink)
            Text("Dịch vụ đích sẽ thấy IP thật của bạn. Chỉ áp dụng cho 3 app trên đến khi bạn tắt.", fontSize = 13.sp, color = Muted)
        }
        Note("Sự kiện được ghi vào Security Center, không kèm URL hay nội dung giao dịch.")
    }
}

// ---------------- IP Trust Details ----------------

private data class Part(val name: String, val score: Int, val max: Int, val desc: String, val delta: String, val src: String, val conf: String, val stale: Boolean)

@Composable
fun IpTrustScreen(back: () -> Unit) {
    val parts = listOf(
        Part("Blacklist & Abuse Reputation", 25, 25, "Kiểm tra IP có liên quan đến spam, lừa đảo hoặc lạm dụng.", "Không bị trừ điểm · không có trong 3 danh sách", "3 danh sách blacklist/abuse · 12 phút trước", "Cao", false),
        Part("Nhà cung cấp IP", 19, 20, "Đánh giá độ minh bạch và uy tín của nhà cung cấp.", "−1 · chưa có báo cáo kiểm toán năm nay", "hồ sơ nhà cung cấp · 14 ngày trước", "Trung bình", true),
        Part("Độ ổn định Gateway", 14, 15, "Theo dõi uptime, độ trễ và tỷ lệ mất gói.", "−1 · độ trễ cao hơn 18% so với trung bình 24 giờ", "health monitor nội bộ · 2 phút trước", "Cao", false),
        Part("Geo & ASN", 14, 15, "Đánh giá tính nhất quán về vị trí và mạng định tuyến.", "−1 · 1/3 cơ sở dữ liệu ghi vị trí khác", "3 cơ sở dữ liệu geo/ASN · 1 ngày trước", "Trung bình", false),
        Part("Proxy / VPN Classification", 13, 15, "Xác định IP có bị nhận diện là VPN, proxy hoặc datacenter.", "−2 · được phân loại datacenter", "4 dịch vụ phân loại · 3 giờ trước", "Trung bình", false),
        Part("Gateway Security", 9, 10, "Đánh giá tình trạng cập nhật, cấu hình và giám sát gateway.", "−1 · bản vá hệ điều hành chờ áp dụng (≤ 7 ngày)", "kiểm tra cấu hình nội bộ · 6 giờ trước", "Cao", false),
    )
    Screen("IP Trust Details", onBack = back, subtitle = "VPN › IP Trust › Thành phần") {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Navy).padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Pill("Ví dụ minh họa – không phải kết quả kiểm tra thực", Tone.WARN)
            Row(verticalAlignment = Alignment.Bottom) {
                Text("94", color = Color.White, fontSize = 52.sp, fontWeight = FontWeight.Bold)
                Text(" /100 · IP Trust Score", color = SoftBlue, fontSize = 16.sp, modifier = Modifier.padding(bottom = 10.dp))
            }
            Text("✓ Đủ điều kiện sử dụng · pool ưu tiên", color = Color.White, fontWeight = FontWeight.SemiBold)
            Text("Đánh giá lúc 09:38 · dữ liệu 3 phút tuổi · độ tin cậy tổng: Cao", color = SoftBlue, fontSize = 12.sp)
            ScoreBar(0.94f, color = Color(0xFF5FE0C8), track = Color.White.copy(alpha = 0.2f))
            Text("Ngưỡng: <60 loại · 60–79 không dùng cho tài chính · 80–89 có điều kiện · 90+ ưu tiên. Cờ loại trừ nghiêm trọng luôn thắng điểm tổng.", color = SoftBlue, fontSize = 12.sp, lineHeight = 17.sp)
        }
        SCard {
            SectionLabel("Điều kiện loại trừ nghiêm trọng")
            Kv("Blacklist nghiêm trọng", "✓ Không có", Tone.OK)
            Kv("Gateway có dấu hiệu bị xâm nhập", "✓ Không có", Tone.OK)
            Kv("Nguồn IP không minh bạch", "✓ Không có", Tone.OK)
            Note("Chỉ cần một mục “Có”, IP bị loại khỏi mọi tuyến — kể cả khi điểm tổng là 99.")
        }
        SCard {
            SectionLabel("Phù hợp để dùng cho")
            Kv("Duyệt web, mạng xã hội", "✓ Phù hợp", Tone.OK)
            Kv("Ngân hàng & thanh toán (IP động)", "✕ Không", Tone.BAD)
            Note("Tuyến tài chính chỉ dùng IP tĩnh/dedicated. Không cam kết ngân hàng chấp nhận IP VPN/datacenter.")
        }
        SectionLabel("Các thành phần đánh giá")
        parts.forEach { p ->
            SCard(spacing = 6.dp) {
                Row { Text(p.name, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = Ink); Text("${p.score}/${p.max}", fontWeight = FontWeight.Bold, color = Ink) }
                ScoreBar(p.score.toFloat() / p.max)
                Text(p.desc, fontSize = 12.sp, color = Muted)
                Text(p.delta, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = if (p.score == p.max) Tone.OK.fg else Tone.WARN.fg)
                Text("Trọng số ${p.max}% · độ tin cậy dữ liệu: ${p.conf}", fontSize = 11.sp, color = Muted)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Nguồn: ${p.src}", Modifier.weight(1f), fontSize = 11.sp, color = Muted)
                    Pill(if (p.stale) "! Dữ liệu cũ" else "Mới", if (p.stale) Tone.WARN else Tone.OK)
                }
            }
        }
        SectionLabel("Thông tin bổ sung")
        SCard(spacing = 0.dp) {
            Kv("Loại IP", "Dynamic (dedicated static / shared static / dynamic)")
            Kv("Gateway", "SG-03 · WireGuard")
            Kv("ASN & vị trí định tuyến", "AS64500 · Singapore")
            Kv("Kiểm tra gần nhất", "09:38 hôm nay")
        }
        SCard(spacing = 0.dp) {
            SectionLabel("Lịch sử điểm · 7 ngày")
            Kv("23/11", "94 · +2 độ trễ ổn định lại")
            Kv("20/11", "92 · −3 độ trễ tăng")
            Kv("17/11", "95 · điểm khởi đầu kỳ")
        }
        Note("Điểm số thật phải lấy từ IP Trust Engine. Nếu nguồn lỗi hoặc dữ liệu quá cũ, hiển thị Unknown/Stale thay vì giữ nhãn xanh cũ.")
    }
}
