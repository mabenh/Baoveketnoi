package com.personalsecurity.suite.ui.screens

import android.app.Activity
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.os.LocaleListCompat
import com.personalsecurity.suite.Prefs
import com.personalsecurity.suite.BuildConfig
import com.personalsecurity.suite.R
import com.personalsecurity.suite.vpn.VpnController
import com.personalsecurity.suite.ui.Ink
import com.personalsecurity.suite.ui.Muted
import com.personalsecurity.suite.ui.NavyDeep
import com.personalsecurity.suite.ui.Note
import com.personalsecurity.suite.ui.Pill
import com.personalsecurity.suite.ui.Primary
import com.personalsecurity.suite.ui.PrimaryButton
import com.personalsecurity.suite.ui.RowDivider
import com.personalsecurity.suite.ui.SCard
import com.personalsecurity.suite.ui.SecondaryButton
import com.personalsecurity.suite.ui.SectionLabel
import com.personalsecurity.suite.ui.SoftBlue
import com.personalsecurity.suite.ui.Tone
import com.personalsecurity.suite.ui.Bg

data class Lang(val tag: String, val native: String, val vi: String)

/** 13 ngôn ngữ được hỗ trợ. Tag rỗng = theo ngôn ngữ hệ thống. */
val LANGS = listOf(
    Lang("vi", "Tiếng Việt", "Tiếng Việt"),
    Lang("en", "English", "Tiếng Anh"),
    Lang("zh-CN", "简体中文", "Tiếng Trung"),
    Lang("ja", "日本語", "Tiếng Nhật"),
    Lang("ko", "한국어", "Tiếng Hàn"),
    Lang("th", "ไทย", "Tiếng Thái"),
    Lang("in", "Bahasa Indonesia", "Tiếng Indonesia"),
    Lang("es", "Español", "Tiếng Tây Ban Nha"),
    Lang("fr", "Français", "Tiếng Pháp"),
    Lang("de", "Deutsch", "Tiếng Đức"),
    Lang("pt-BR", "Português (Brasil)", "Tiếng Bồ Đào Nha"),
    Lang("ru", "Русский", "Tiếng Nga"),
    Lang("ar", "العربية", "Tiếng Ả Rập"),
)

fun currentLangTag(): String {
    val loc = AppCompatDelegate.getApplicationLocales()[0] ?: return ""
    return if (loc.language == "in" || loc.language == "id") "in" else loc.toLanguageTag()
}

fun applyLang(tag: String) {
    AppCompatDelegate.setApplicationLocales(
        if (tag.isEmpty()) LocaleListCompat.getEmptyLocaleList() else LocaleListCompat.forLanguageTags(tag),
    )
}

@Composable
fun LanguageOptions(onPicked: () -> Unit = {}) {
    val current = currentLangTag()
    val all = listOf(Lang("", stringResource(R.string.language_system), "")) + LANGS
    Column {
        all.forEachIndexed { i, l ->
            if (i > 0) RowDivider()
            Row(
                Modifier.fillMaxWidth().heightIn(min = 48.dp)
                    .clickable(role = Role.RadioButton) { applyLang(l.tag); onPicked() },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RadioButton(selected = current == l.tag, onClick = null, colors = RadioButtonDefaults.colors(selectedColor = Primary))
                Spacer(Modifier.size(8.dp))
                Text(l.native, Modifier.weight(1f), fontSize = 14.sp, color = Ink)
                if (l.vi.isNotEmpty()) Text(l.vi, fontSize = 12.sp, color = Muted)
            }
        }
    }
}

@Composable
fun WelcomeScreen(onStart: () -> Unit) {
    var showLang by remember { mutableStateOf(false) }
    val current = currentLangTag()
    val langName = LANGS.firstOrNull { it.tag == current }?.native ?: stringResource(R.string.language_system)
    Column(
        Modifier.fillMaxSize().background(NavyDeep).verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        if (BuildConfig.MULTI_LANGUAGE) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Row(
                Modifier.heightIn(min = 44.dp).clip(RoundedCornerShape(50))
                    .border(1.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(50))
                    .clickable(role = Role.Button) { showLang = true }.padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Icon(Icons.Filled.Language, contentDescription = stringResource(R.string.language), tint = Color.White)
                Text(langName, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.size(12.dp))
        Image(
            painterResource(R.drawable.logo), contentDescription = "Logo",
            modifier = Modifier.size(148.dp).clip(RoundedCornerShape(34.dp)), contentScale = ContentScale.Crop,
        )
        Text("PERSONAL SECURITY SUITE", color = Color(0xFF9FB4EA), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp)
        Text(stringResource(R.string.welcome_title), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, lineHeight = 34.sp)
        Text(stringResource(R.string.welcome_body), color = SoftBlue, fontSize = 15.sp, lineHeight = 24.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.size(24.dp))
        Box(
            Modifier.fillMaxWidth().heightIn(min = 52.dp).clip(RoundedCornerShape(14.dp)).background(Color.White)
                .clickable(role = Role.Button, onClick = onStart),
            contentAlignment = Alignment.Center,
        ) {
            Text(stringResource(R.string.welcome_cta), color = NavyDeep, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        Text(stringResource(R.string.welcome_note), color = Color(0xFF9FB4EA), fontSize = 12.sp, textAlign = TextAlign.Center)
    }
    if (showLang) {
        AlertDialog(
            onDismissRequest = { showLang = false },
            confirmButton = { TextButton(onClick = { showLang = false }) { Text("OK") } },
            title = { Text("${stringResource(R.string.language)} · Language") },
            text = { Column(Modifier.verticalScroll(rememberScrollState())) { LanguageOptions { showLang = false } } },
        )
    }
}

@Composable
fun OnbVpnScreen(prefs: Prefs, onClose: () -> Unit, onGranted: () -> Unit, onDenied: () -> Unit) {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val ok = r.resultCode == Activity.RESULT_OK
        VpnController.onPermissionResult(ok)
        if (ok) {
            prefs.markSeenGranted("vpn")
            VpnController.connect(ctx) // Bước 6: nhận kết quả và khởi chạy VPN Service
            onGranted()
        } else {
            onDenied() // Không tự động hỏi lại.
        }
    }
    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onClose) { Text("Để sau", color = Ink) }
            Spacer(Modifier.weight(1f))
            Pill("Chưa được cấp quyền", Tone.PERM)
        }
        Box(Modifier.size(56.dp).clip(RoundedCornerShape(16.dp)).background(Tone.OK.bg), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Public, null, tint = Primary)
        }
        Text("Bảo vệ kết nối Internet", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("VPN giúp bảo vệ lưu lượng mạng theo cấu hình của ứng dụng.", fontSize = 15.sp, lineHeight = 23.sp, color = Color(0xFF33404F))
        SCard(spacing = 10.dp) {
            SectionLabel("Trước khi kết nối")
            listOf(
                "Thiết lập một kết nối VPN trên thiết bị.",
                "Định tuyến lưu lượng qua máy chủ VPN tại ${BuildConfig.GATEWAY_REGION}.",
                "Firewall và IP Trust dùng chung kết nối này.",
                "Android sẽ hiển thị hộp thoại xác nhận quyền VPN.",
            ).forEach {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Pill("✓", Tone.OK); Text(it, fontSize = 14.sp, color = Ink) }
            }
        }
        SCard(spacing = 10.dp) {
            SectionLabel("VPN không có nghĩa là")
            listOf("Ứng dụng được phép đọc nội dung mọi tin nhắn.", "Ứng dụng được phép xem mật khẩu ngân hàng.", "Kết nối được bảo vệ tuyệt đối trong mọi trường hợp.").forEach {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Pill("✕", Tone.NEUTRAL); Text(it, fontSize = 14.sp, color = Ink) }
            }
        }
        Note("Cấp quyền chưa phải là đã được bảo vệ: ứng dụng chỉ báo Protected sau khi tunnel tới máy chủ được thiết lập và kiểm tra đạt.")
        PrimaryButton("Cho phép và kết nối VPN", onClick = {
            prefs.markRequested("vpn")
            val intent = VpnService.prepare(ctx) // Bước 2: kiểm tra quyền
            if (intent == null) {
                VpnController.connect(ctx)
                onGranted()
            } else {
                launcher.launch(intent) // Bước 3–4: mở hộp thoại hệ thống
            }
        }, modifier = Modifier.fillMaxWidth())
        SecondaryButton("Để sau", onClick = onClose, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
fun OnbDeniedScreen(onRetry: () -> Unit, onSkip: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Spacer(Modifier.size(12.dp))
        Box(Modifier.size(56.dp).clip(RoundedCornerShape(16.dp)).background(Tone.PERM.bg), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Lock, null, tint = Tone.PERM.fg)
        }
        Text("VPN chưa được cấp quyền", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("Bạn đã chọn không cấp quyền VPN. Ứng dụng sẽ không tự hỏi lại. Khi cần, mở VPN › Thiết lập VPN, hoặc Cài đặt › Quyền & trạng thái để bật lại.", fontSize = 15.sp, lineHeight = 23.sp, color = Color(0xFF33404F))
        SectionLabel("Bị giới hạn khi không có VPN")
        SCard(spacing = 4.dp) {
            listOf("VPN & IP Trust", "Tường lửa ứng dụng", "Bảo vệ DNS / IPv6", "Privacy Mode – lớp IP công khai").forEachIndexed { i, s ->
                if (i > 0) RowDivider()
                Row(Modifier.fillMaxWidth().heightIn(min = 44.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(s, Modifier.weight(1f), fontSize = 14.sp, color = Ink); Pill(stringResource(R.string.status_permission_required), Tone.PERM)
                }
            }
        }
        SectionLabel("Vẫn hoạt động")
        SCard(spacing = 4.dp) {
            listOf("Identity Center" to Tone.OK, "Kho mật khẩu" to Tone.OK, "Device Care, đánh giá Wi-Fi" to Tone.NEUTRAL).forEachIndexed { i, (s, t) ->
                if (i > 0) RowDivider()
                Row(Modifier.fillMaxWidth().heightIn(min = 44.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(s, Modifier.weight(1f), fontSize = 14.sp, color = Ink); Pill(if (t == Tone.OK) "✓ Dùng được" else "Một phần", t)
                }
            }
        }
        PrimaryButton("Thử lại", onRetry, Modifier.fillMaxWidth())
        SecondaryButton("Tiếp tục không dùng VPN", onSkip, Modifier.fillMaxWidth())
    }
}
