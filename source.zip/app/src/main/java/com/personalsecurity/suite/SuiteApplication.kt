package com.personalsecurity.suite

import android.app.Application
import com.personalsecurity.suite.vpn.WireGuardManager

class SuiteApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Đăng ký sớm để Always-on VPN (do hệ thống khởi động) đi đúng quy trình kết nối + kiểm tra.
        WireGuardManager.init(this)
    }
}
