package com.personalsecurity.suite.ui.screens

import android.content.Context
import android.provider.Settings as AndroidSettings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.personalsecurity.suite.BuildConfig
import com.personalsecurity.suite.openSettings
import com.personalsecurity.suite.ui.Body
import com.personalsecurity.suite.ui.Ink
import com.personalsecurity.suite.ui.Kv
import com.personalsecurity.suite.ui.Muted
import com.personalsecurity.suite.ui.Note
import com.personalsecurity.suite.ui.Pill
import com.personalsecurity.suite.ui.Primary
import com.personalsecurity.suite.ui.PrimaryButton
import com.personalsecurity.suite.ui.SCard
import com.personalsecurity.suite.ui.Screen
import com.personalsecurity.suite.ui.SecondaryButton
import com.personalsecurity.suite.ui.SectionLabel
import com.personalsecurity.suite.ui.Tone
import com.personalsecurity.suite.vpn.ConfigStore
import com.personalsecurity.suite.vpn.ConnectStep
import com.personalsecurity.suite.vpn.VpnController
import com.personalsecurity.suite.vpn.VpnStatus
import java.text.DateFormat
import java.util.Date

/** Điểm vào duy nhất cho nút "Bật VPN": có quyền thì kết nối, chưa có thì qua màn giải thích. */
fun startVpnFlow(ctx: Context, go: (String) -> Unit) {
    if (VpnController.hasPermission(ctx)) {
        VpnController.connect(ctx)
        go("vpn_connect")
    } else {
        go("onb_vpn")
    }
}

private fun time(ms: Long): String = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(ms))

/** Nhãn + màu cho từng trạng thái. Chỉ Protected dùng màu "được bảo vệ". */
fun statusLabel(s: VpnStatus): Pair<String, Tone> = when (s) {
    VpnStatus.NotPermitted -> "Chưa được cấp quyền" to Tone.PERM
    VpnStatus.PermissionDenied -> "Đã từ chối quyền VPN" to Tone.PERM
    VpnStatus.Ready -> "Chưa kết nối" to Tone.BAD
    is VpnStatus.Connecting -> "Đang kết nối · chưa được bảo vệ" to Tone.NEUTRAL
    is VpnStatus.Protected -> "✓ Protected" to Tone.OK
    is VpnStatus.Failed -> "✕ Kết nối thất bại" to Tone.BAD
    is VpnStatus.Interrupted -> "✕ Bảo vệ bị gián đoạn" to Tone.BAD
}

/** Thẻ trạng thái VPN thật, dùng ở Tổng quan và màn VPN. */
@Composable
fun VpnStatusCard(go: (String) -> Unit) {
    val ctx = LocalContext.current
    val s = VpnController.status.collectAsState().value // biến thường để smart cast trong when
    val (label, tone) = statusLabel(s)
    SCard(bg = if (s is VpnStatus.Protected) Tone.OK.bg else Color.White, spacing = 10.dp, onClick = { go("vpn_connect") }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("VPN Protection", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Ink)
                Text("Máy chủ ${BuildConfig.GATEWAY_ID} · ${BuildConfig.GATEWAY_REGION}", fontSize = 12.sp, color = Muted)
            }
            Pill(label, tone)
        }
        when (s) {
            is VpnStatus.Protected -> {
                Kv("Gateway", s.gateway); Kv("IP đầu ra", s.exitIp); Kv("Kiểm tra lúc", time(s.verifiedAt))
                if (s.appFilter != null) Kv("Danh sách chặn", "${s.appFilter} app qua VPN · cần Lockdown", Tone.WARN)
                SecondaryButton("Ngắt kết nối", { VpnController.disconnect(ctx) }, Modifier.fillMaxWidth())
            }
            is VpnStatus.Connecting -> Body("Bước ${s.step.ordinal + 1}/8 · ${s.step.title}", Muted, 13)
            else -> {
                Body("VPN giúp bảo vệ lưu lượng mạng theo cấu hình của ứng dụng.", Muted, 13)
                PrimaryButton("Bật VPN", { startVpnFlow(ctx, go) }, Modifier.fillMaxWidth())
            }
        }
        SecondaryButton(if (ConfigStore.exists(ctx)) "Cấu hình WireGuard" else "Nhập cấu hình WireGuard", { go("vpn_config") }, Modifier.fillMaxWidth())
    }
}

@Composable
private fun StepRow(step: ConnectStep, state: Int) {
    // state: 0 chưa tới, 1 đang chạy, 2 xong, 3 lỗi
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.size(26.dp), contentAlignment = Alignment.Center) {
            when (state) {
                1 -> CircularProgressIndicator(Modifier.size(20.dp), color = Primary, strokeWidth = 2.dp)
                else -> Box(
                    Modifier.size(22.dp).clip(CircleShape).background(
                        when (state) { 2 -> Primary; 3 -> Tone.BAD.fg; else -> Color(0xFFE6E9EE) },
                    ),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        when (state) { 2 -> "✓"; 3 -> "✕"; else -> "${step.ordinal + 1}" },
                        color = if (state == 0) Muted else Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
        Column(Modifier.weight(1f)) {
            Text(step.title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = if (state == 0) Muted else Ink)
            Text(step.detail, fontSize = 12.sp, color = Muted, lineHeight = 16.sp)
        }
    }
}

@Composable
private fun LifecycleCard(current: ConnectStep?, failedAt: ConnectStep?, allDone: Boolean) {
    SCard(spacing = 12.dp) {
        SectionLabel("VPN Connection Lifecycle")
        ConnectStep.entries.forEach { st ->
            val state = when {
                allDone -> 2
                failedAt != null -> when { st.ordinal < failedAt.ordinal -> 2; st == failedAt -> 3; else -> 0 }
                current != null -> when { st.ordinal < current.ordinal -> 2; st == current -> 1; else -> 0 }
                else -> 0
            }
            StepRow(st, state)
        }
    }
}

/** Connecting / Protected / Connection Failed / Protection Interrupted — trạng thái thật từ VpnController + WireGuard GoBackend. */
@Composable
fun VpnConnectionScreen(back: () -> Unit, go: (String) -> Unit) {
    val ctx = LocalContext.current
    val s by VpnController.status.collectAsState()
    Screen("VPN Protection", onBack = back, demo = false) {
        when (val st = s) {
            is VpnStatus.Connecting -> {
                SCard(spacing = 8.dp) {
                    Pill("Đang kết nối · chưa được bảo vệ", Tone.NEUTRAL)
                    Body("Đang xác thực máy chủ và thiết lập tunnel. Trạng thái chỉ chuyển sang Protected khi mọi kiểm tra bắt buộc thành công.", Muted, 13)
                }
                LifecycleCard(st.step, null, false)
                SecondaryButton("Hủy", { VpnController.disconnect(ctx) }, Modifier.fillMaxWidth())
            }
            is VpnStatus.Protected -> {
                SCard(bg = Tone.OK.bg, border = Tone.OK.fg.copy(alpha = 0.3f), spacing = 4.dp) {
                    Pill("✓ Protected", Tone.OK)
                    Text("VPN đã kết nối và kiểm tra đạt", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Kv("Gateway", st.gateway); Kv("IP đầu ra", st.exitIp); Kv("DNS", st.dns); Kv("IPv6", st.ipv6)
                    Kv("Kiểm tra lúc", time(st.verifiedAt))
                }
                LifecycleCard(null, null, true)
                SecondaryButton("Ngắt kết nối", { VpnController.disconnect(ctx) }, Modifier.fillMaxWidth())
            }
            is VpnStatus.Failed -> {
                SCard(bg = Tone.BAD.bg, border = Color(0xFFF0B7B1), spacing = 6.dp) {
                    Pill("✕ Kết nối thất bại", Tone.BAD)
                    Text("Lưu lượng hiện KHÔNG đi qua VPN", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color(0xFF7A1912))
                    Body(st.message, Color(0xFF4A1410), 13)
                    Kv("Bước lỗi", "${st.step.ordinal + 1}/8 · ${st.step.title}")
                    Kv("Mã lỗi", st.code)
                    Kv("Lúc", time(st.at))
                }
                LifecycleCard(null, st.step, false)
                if (st.code in CONFIG_CODES) {
                    PrimaryButton("Sửa cấu hình WireGuard", { go("vpn_config") }, Modifier.fillMaxWidth())
                    SecondaryButton("Thử lại", { startVpnFlow(ctx, go) }, Modifier.fillMaxWidth())
                } else {
                    PrimaryButton("Thử lại", { startVpnFlow(ctx, go) }, Modifier.fillMaxWidth())
                }
                Note("Ứng dụng không tự thử lại liên tục và không tự chuyển sang tuyến kém an toàn.")
            }
            is VpnStatus.Interrupted -> {
                SCard(bg = Tone.BAD.bg, border = Color(0xFFF0B7B1), spacing = 6.dp) {
                    Pill("✕ Bảo vệ bị gián đoạn", Tone.BAD)
                    Text("VPN không còn bảo vệ kết nối", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color(0xFF7A1912))
                    Body(st.reason.label, Color(0xFF4A1410), 13)
                    Kv("Lúc", time(st.at))
                }
                PrimaryButton("Kết nối lại", { startVpnFlow(ctx, go) }, Modifier.fillMaxWidth())
                SecondaryButton("Bật Always-on & chặn khi mất VPN", { openSettings(ctx, AndroidSettings.ACTION_VPN_SETTINGS) }, Modifier.fillMaxWidth())
                Note("Kill Switch toàn hệ thống dùng chế độ Always-on + “Chặn kết nối không qua VPN” trong Cài đặt Android.")
            }
            VpnStatus.Ready -> {
                SCard(spacing = 6.dp) {
                    Pill("Đã có quyền · chưa kết nối", Tone.BAD)
                    Body("Cấp quyền VPN không đồng nghĩa với kết nối thành công. Bấm kết nối để thiết lập tunnel.", Muted, 13)
                }
                PrimaryButton("Kết nối VPN", { startVpnFlow(ctx, go) }, Modifier.fillMaxWidth())
            }
            VpnStatus.NotPermitted, VpnStatus.PermissionDenied -> {
                SCard(spacing = 6.dp) {
                    Pill(statusLabel(st).first, Tone.PERM)
                    Body("Ứng dụng cần quyền VPN của Android trước khi có thể kết nối.", Muted, 13)
                }
                PrimaryButton("Thiết lập VPN", { go("onb_vpn") }, Modifier.fillMaxWidth())
            }
        }
    }
}

private val CONFIG_CODES = setOf("GATEWAY_NOT_CONFIGURED", "CONFIG_INVALID", "SPLIT_TUNNEL", "NO_DNS", "IPV6_LEAK", "UNEXPECTED_GATEWAY")
