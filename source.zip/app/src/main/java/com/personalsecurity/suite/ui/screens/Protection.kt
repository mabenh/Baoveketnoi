package com.personalsecurity.suite.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.provider.Settings as AndroidSettings
import com.personalsecurity.suite.R
import com.personalsecurity.suite.openSettings
import com.personalsecurity.suite.ui.Body
import com.personalsecurity.suite.ui.Chip
import com.personalsecurity.suite.ui.Ink
import com.personalsecurity.suite.ui.ItemRow
import com.personalsecurity.suite.ui.Kv
import com.personalsecurity.suite.ui.Muted
import com.personalsecurity.suite.ui.Note
import com.personalsecurity.suite.ui.Pill
import com.personalsecurity.suite.ui.Primary
import com.personalsecurity.suite.ui.PrimaryButton
import com.personalsecurity.suite.ui.RowDivider
import com.personalsecurity.suite.ui.SCard
import com.personalsecurity.suite.ui.Screen
import com.personalsecurity.suite.ui.SecondaryButton
import com.personalsecurity.suite.ui.SectionLabel
import com.personalsecurity.suite.ui.ToggleRow
import com.personalsecurity.suite.ui.Tone
import com.personalsecurity.suite.ui.WarnInk

// ---------------- Tường lửa ----------------

private data class FwApp(val id: String, val initial: String, val name: String, val note: String, val essential: Boolean = false)

@Composable
private fun NetToggle(label: String, blocked: Boolean, onClick: () -> Unit) {
    val tone = if (blocked) Tone.BAD else Tone.NEUTRAL
    Column(
        Modifier.width(56.dp).heightIn(min = 44.dp).clip(RoundedCornerShape(10.dp)).background(tone.bg)
            .clickable(role = Role.Switch, onClick = onClick).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(label, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = tone.fg)
        Text(if (blocked) "Chặn" else "Mở", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = tone.fg)
    }
}

@Composable
fun FirewallDemoScreen() {
    var allowMode by remember { mutableStateOf(false) }
    val apps = remember {
        listOf(
            FwApp("g", "G", "Trò chơi X", "Bị chặn trên dữ liệu di động"),
            FwApp("s", "S", "Mạng xã hội Y", "Theo lịch 23:00–06:00"),
            FwApp("v", "V", "Video Z", "Bị chặn trên cả hai mạng"),
            FwApp("b", "B", "Trình duyệt", "Được phép"),
            FwApp("n", "N", "Ngân hàng A", "Tuyến tài chính · không chặn", essential = true),
            FwApp("p", "Đ", "Điện thoại & SMS", "Thành phần hệ thống", essential = true),
        )
    }
    val wifi = remember { mutableStateMapOf("v" to true) }
    val data = remember { mutableStateMapOf("g" to true, "v" to true) }
    Screen("Tường lửa ứng dụng", onBack = null, actions = { Pill("✓ Đang lọc", Tone.OK) }) {
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFFE6E9EE)).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf(false to "Chặn chọn lọc", true to "Chỉ cho phép").forEach { (mode, label) ->
                val sel = allowMode == mode
                Box(
                    Modifier.weight(1f).heightIn(min = 40.dp).clip(RoundedCornerShape(10.dp)).background(if (sel) Color.White else Color.Transparent)
                        .clickable(role = Role.Tab) { allowMode = mode },
                    contentAlignment = Alignment.Center,
                ) { Text(label, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = if (sel) Ink else Muted) }
            }
        }
        Note(if (allowMode) "Chỉ app bạn cho phép mới có Internet. App thiết yếu luôn được giữ." else "Mọi app có Internet, trừ các app bạn chặn.")
        SCard(spacing = 0.dp, padding = PaddingValues(12.dp, 4.dp)) {
            apps.forEachIndexed { i, a ->
                if (i > 0) RowDivider()
                Row(Modifier.fillMaxWidth().heightIn(min = 60.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(Tone.NEUTRAL.bg), contentAlignment = Alignment.Center) {
                        Text(a.initial, fontWeight = FontWeight.Bold, color = Color(0xFF33404F))
                    }
                    Column(Modifier.weight(1f)) {
                        Text(a.name, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Ink)
                        Text(a.note, fontSize = 12.sp, color = Muted)
                    }
                    if (a.essential) Pill("Thiết yếu", Tone.NEUTRAL) else {
                        NetToggle("Wi-Fi", wifi[a.id] == true) { wifi[a.id] = wifi[a.id] != true }
                        NetToggle("Dữ liệu", data[a.id] == true) { data[a.id] = data[a.id] != true }
                    }
                }
            }
        }
        SCard {
            Text("Lịch mạng: 23:00 – 06:00", fontWeight = FontWeight.SemiBold, color = Ink)
            Text("Chặn app giải trí. Luôn cho phép: cuộc gọi, SMS, báo thức, ngân hàng, authenticator.", fontSize = 13.sp, color = Muted)
        }
        Note("Tường lửa chỉ kiểm soát lưu lượng mạng qua VPN cục bộ — không dừng tiến trình hay xoá ứng dụng chạy nền. Bản prototype chưa áp dụng chính sách thật.")
    }
}

// ---------------- Privacy Mode ----------------

@Composable
fun PrivacyScreen(back: () -> Unit) {
    val ctx = LocalContext.current
    val on = remember { mutableStateMapOf("ip" to true, "dns" to true, "v6" to true, "lan" to false) }
    var applied by remember { mutableStateOf(false) }
    Screen("Privacy Mode", onBack = back) {
        Note("Một bộ cấu hình riêng tư áp dụng cùng lúc — không phải chế độ tàng hình. Từng lớp hiển thị rõ điều app làm được và điều Android tự quản lý.")
        SCard(spacing = 0.dp, padding = PaddingValues(16.dp, 4.dp)) {
            listOf(
                Triple("ip", "IP công khai", "✓ Qua VPN" to "Kết nối trực tiếp"),
                Triple("dns", "DNS", "✓ Qua tunnel" to "Có thể rò rỉ"),
                Triple("v6", "IPv6", "⊘ Chặn rõ ràng" to "Ngoài tunnel"),
                Triple("lan", "Truy cập LAN", "Hạn chế" to "Cho phép"),
            ).forEach { (k, name, labels) ->
                val v = on[k] == true
                ItemRow(name, null, trailing = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill(if (v) labels.first else labels.second, if (v) Tone.OK else if (k == "lan") Tone.NEUTRAL else Tone.WARN)
                        Switch(v, { on[k] = it; applied = false }, colors = SwitchDefaults.colors(checkedTrackColor = Primary))
                    }
                })
                RowDivider()
            }
            Kv("Wi-Fi metadata", "Do Android quản lý · MAC ngẫu nhiên", Tone.NEUTRAL)
            RowDivider()
            ItemRow("Bluetooth", "Đang hiển thị · cần bạn xác nhận", onClick = { openSettings(ctx, AndroidSettings.ACTION_BLUETOOTH_SETTINGS) })
            RowDivider()
            Kv("Hotspot", "Đang tắt", Tone.OK)
        }
        PrimaryButton(if (applied) "✓ Đã áp dụng Privacy Mode" else "Áp dụng Privacy Mode", { applied = true }, Modifier.fillMaxWidth(), color = if (applied) Tone.OK.fg else Primary)
        Note("VPN che IP công khai với website đích; không che IP LAN, MAC hay mọi tín hiệu Bluetooth.")
    }
}

// ---------------- Wireless ----------------

@Composable
fun WirelessScreen(back: () -> Unit, go: (String) -> Unit) {
    Screen("Wireless", onBack = back) {
        SCard(onClick = { go("bg_protection") }) {
            Text("Giám sát theo sự kiện hệ thống", fontWeight = FontWeight.SemiBold, color = Ink, fontSize = 13.sp)
            Text("Mức A · kiểm tra cuối 09:41 · không phải 24/7 tuyệt đối", fontSize = 12.sp, color = Muted)
        }
        SectionLabel("Wi-Fi Trust · phiên hiện tại")
        SCard(spacing = 6.dp) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Cafe_Free", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Text("Phiên từ 09:05 · 36 phút · chưa được bạn xác nhận", fontSize = 12.sp, color = Muted)
                }
                Text("58/100", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Pill("Rủi ro cao (50–74)", Tone.BAD); Pill("Chắc chắn: Trung bình", Tone.NEUTRAL) }
            Kv("Mã hóa & xác thực", "0/20 · Mạng mở")
            Kv("Danh tính AP", "14/20 · BSSID đổi 09:31")
            Kv("DNS & định tuyến", "9/15 · DNS đổi 09:31")
            Kv("Captive portal", "8/15")
            Kv("Gateway · Ổn định · Lịch sử", "15 · 8 · 4")
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color(0xFFFFF8EE)).padding(10.dp)) {
                Text("AP và DNS cùng thay đổi trong một phiên. Chưa đủ bằng chứng để kết luận Evil Twin — tránh giao dịch nhạy cảm nếu tắt VPN.", fontSize = 12.sp, color = WarnInk, lineHeight = 17.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PrimaryButton("Chi tiết phiên", { go("wifi_session") }, Modifier.weight(1f))
                SecondaryButton("Đánh dấu tin cậy", {}, Modifier.weight(1f))
            }
        }
        SectionLabel("Bluetooth Trust")
        SCard(spacing = 0.dp, padding = PaddingValues(14.dp, 2.dp)) {
            ItemRow("Tai nghe của tôi", "Đã ghép đôi · bạn xác nhận 12/10", trailing = { Pill("Trusted", Tone.OK) })
            RowDivider()
            ItemRow("Đồng hồ thông minh", "Đã thấy 4 lần · chưa xác minh", trailing = { Pill("Known", Tone.NEUTRAL) })
            RowDivider()
            ItemRow("“BT-7F21”", "Ghép đôi 09:12 · bạn không khởi tạo?", onClick = { go("bt_device") }, trailing = { Pill("! Suspicious", Tone.WARN) })
            RowDivider()
            ItemRow("Thiết bị BLE lân cận", "Chưa cấp quyền quét Bluetooth", onClick = { go("permissions") }, trailing = { Pill(stringResource(R.string.status_limited), Tone.PERM) })
        }
        SectionLabel("Hotspot")
        SCard { Kv("Đang tắt", "Tắt", Tone.NEUTRAL); Note("Danh sách thiết bị kết nối chỉ khi API/thiết bị cho phép.") }
        Note("Điểm là heuristic có phiên bản; thiếu dữ liệu sẽ hiện Unknown/Limited, không mặc định an toàn. Thiết bị BLE quảng bá gần đó không đồng nghĩa đã kết nối hay đang tấn công.")
    }
}

@Composable
fun WifiSessionScreen(back: () -> Unit) {
    Screen("Chi tiết phiên Wi-Fi", onBack = back, subtitle = "Cafe_Free · phiên #a3f9 · đánh giá v1.3") {
        SCard(spacing = 2.dp) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("58/100", Modifier.weight(1f), fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Ink); Pill("Rủi ro cao", Tone.BAD)
            }
            Kv("Bắt đầu phiên", "09:05 · 36 phút"); Kv("Đánh giá lúc", "09:41 · dữ liệu mới"); Kv("Độ chắc chắn", "Trung bình")
        }
        SCard(bg = Color(0xFFFFF8EE), border = Color(0xFFF2C58F), spacing = 2.dp) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Pill("! Tương quan", Tone.WARN); Text("AP và DNS đổi trong cùng phiên", fontWeight = FontWeight.SemiBold, color = WarnInk, fontSize = 14.sp)
            }
            SectionLabel("Bằng chứng")
            Kv("BSSID", "••:3A → ••:7C"); Kv("DNS server", "Đã thay đổi (fingerprint)"); Kv("Gateway", "Không đổi"); Kv("Cửa sổ", "16 giây · rule WT-02 v1.3")
            Note("Không kết luận Evil Twin: BSSID mới có thể do roaming hoặc mạng mesh.")
        }
        SectionLabel("Dòng thời gian")
        SCard {
            listOf(
                "09:05:12" to "Kết nối Cafe_Free · mạng mở (Open)",
                "09:05:40" to "Phát hiện captive portal",
                "09:06:55" to "Portal hoàn tất · VPN kết nối lại qua Wi-Fi",
                "09:31:04" to "BSSID thay đổi (cùng SSID)",
                "09:31:20" to "DNS server thay đổi",
                "09:31:21" to "Tạo cảnh báo · kênh Wireless Risk · gộp 2 sự kiện",
                "09:41:00" to "Kiểm tra lại: VPN, DNS qua tunnel vẫn hoạt động",
            ).forEach { (t, e) ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(t, Modifier.width(64.dp), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF33404F))
                    Text(e, fontSize = 13.sp, color = if (t.startsWith("09:31:0") || t == "09:31:20") WarnInk else Ink)
                }
            }
        }
        SectionLabel("Đánh giá theo tiêu chí")
        SCard(spacing = 0.dp) {
            listOf("Mã hóa & xác thực" to "0 / 20", "Danh tính AP & nhất quán" to "14 / 20", "Gateway / DHCP" to "15 / 15", "DNS & định tuyến" to "9 / 15",
                "Captive portal / giả mạo" to "8 / 15", "Ổn định phiên" to "8 / 10", "Lịch sử & xác minh" to "4 / 5").forEach { (k, v) -> Kv(k, v) }
        }
        SectionLabel("Khuyến nghị")
        SCard {
            Body("1. Giữ VPN bật trong suốt phiên này.\n2. Tránh giao dịch ngân hàng nếu phải tắt VPN.\n3. Nếu nghi ngờ, quên mạng và kết nối lại sau khi hỏi nhân viên tên mạng đúng.", size = 13)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SecondaryButton("Không tin cậy mạng", {}, Modifier.weight(1f)); SecondaryButton("Ngắt Wi-Fi", {}, Modifier.weight(1f))
            }
        }
        Note("SSID/BSSID, gateway và DNS được lưu dưới dạng fingerprint có salt. Không ghi URL, nội dung gói tin hay vị trí chi tiết.")
    }
}

@Composable
fun BtDeviceScreen(back: () -> Unit) {
    val ctx = LocalContext.current
    val classes = listOf("Trusted" to Tone.OK, "Known" to Tone.NEUTRAL, "Unknown" to Tone.UNKNOWN, "Suspicious" to Tone.WARN, "Blocked" to Tone.BAD)
    var cls by remember { mutableStateOf("Suspicious") }
    val explain = mapOf(
        "Trusted" to "Bạn đã xác nhận thiết bị này. Cảnh báo sẽ xuất hiện lại nếu hành vi thay đổi.",
        "Known" to "Đã thấy trước đây nhưng chưa được bạn xác minh.",
        "Unknown" to "Chưa đủ dữ liệu để đánh giá. Không mặc định an toàn.",
        "Suspicious" to "Ghép đôi mới lúc 09:12 và kết nối lại 2 lần trong 8 phút. Nếu bạn không khởi tạo, hãy hủy ghép đôi trong Cài đặt Android.",
        "Blocked" to "Bạn đã từ chối thiết bị này. Ứng dụng sẽ cảnh báo nếu nó kết nối lại.",
    )
    Screen("“BT-7F21”", onBack = back, subtitle = "Thiết bị âm thanh (theo hệ thống báo) · đánh giá v1.3") {
        SCard(spacing = 10.dp) {
            Row { Pill(cls, classes.first { it.first == cls }.second); Text("  Chắc chắn: Trung bình", fontSize = 12.sp, color = Muted) }
            Body(explain[cls] ?: "")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                classes.forEach { (c, _) ->
                    Box(
                        Modifier.weight(1f).heightIn(min = 44.dp).clip(RoundedCornerShape(10.dp))
                            .background(if (c == cls) Color.White else Color(0xFFE6E9EE))
                            .clickable(role = Role.Tab) { cls = c },
                        contentAlignment = Alignment.Center,
                    ) { Text(c, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = if (c == cls) Ink else Muted, textAlign = TextAlign.Center) }
                }
            }
            Note("Trusted và Blocked do bạn đặt; Known/Unknown/Suspicious do hệ thống đánh giá.")
        }
        SectionLabel("Lịch sử ghép đôi & kết nối")
        SCard(spacing = 0.dp) {
            Kv("09:12 hôm nay", "Yêu cầu ghép đôi mới"); Kv("09:12", "Ghép đôi thành công"); Kv("09:14 – 09:16", "Kết nối · 2 phút"); Kv("09:19 – 09:20", "Kết nối lại · 1 phút")
        }
        SectionLabel("Tiêu chí đánh giá")
        SCard(spacing = 0.dp) {
            Kv("Pairing / xác thực", "12 / 25"); Kv("Độ tin cậy thiết bị", "4 / 20"); Kv("Dịch vụ BLE/GATT", "Unknown · chưa khám phá", Tone.UNKNOWN)
            Kv("Hành vi kết nối", "10 / 20"); Kv("Discoverability", "8 / 10"); Kv("Lịch sử", "0 / 10")
        }
        SCard(bg = Color(0xFFF7F8FA)) {
            SectionLabel("Giới hạn dữ liệu")
            Note("Địa chỉ BLE có thể ngẫu nhiên nên fingerprint không phải định danh tuyệt đối. Ứng dụng không đọc tin nhắn, danh bạ hay dữ liệu truyền giữa các thiết bị.")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SecondaryButton("Cài đặt Bluetooth", { openSettings(ctx, AndroidSettings.ACTION_BLUETOOTH_SETTINGS) }, Modifier.weight(1f))
            PrimaryButton("Tôi nhận ra thiết bị", { cls = "Trusted" }, Modifier.weight(1f))
        }
        Note("Hủy ghép đôi thực hiện trong Cài đặt Android; ứng dụng không tự ghép đôi hay hủy ghép đôi.")
    }
}
