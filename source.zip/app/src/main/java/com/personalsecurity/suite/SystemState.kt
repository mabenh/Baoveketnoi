package com.personalsecurity.suite

import android.Manifest
import android.app.Activity
import android.app.AppOpsManager
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Process
import android.provider.Settings
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.personalsecurity.suite.ui.Tone

/** Lưu cục bộ, chỉ những gì cần cho trạng thái UI. Không lưu bí mật. */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("suite_prefs", Context.MODE_PRIVATE)

    var onboarded: Boolean
        get() = sp.getBoolean("onboarded", false)
        set(v) = sp.edit().putBoolean("onboarded", v).apply()

    var demo: Boolean
        get() = sp.getBoolean("demo", false)
        set(v) = sp.edit().putBoolean("demo", v).apply()

    fun requested(key: String) = sp.getBoolean("req_$key", false)
    fun markRequested(key: String) = sp.edit().putBoolean("req_$key", true).apply()
    fun seenGranted(key: String) = sp.getBoolean("granted_$key", false)
    fun markSeenGranted(key: String) = sp.edit().putBoolean("granted_$key", true).apply()
}

fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

fun openSettings(ctx: Context, action: String, withPackage: Boolean = false) {
    val intent = Intent(action).apply {
        if (withPackage) data = Uri.fromParts("package", ctx.packageName, null)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    try {
        ctx.startActivity(intent)
    } catch (e: Exception) {
        ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

fun openAppDetails(ctx: Context) = openSettings(ctx, Settings.ACTION_APPLICATION_DETAILS_SETTINGS, withPackage = true)

/** Tăng giá trị mỗi khi màn hình quay lại foreground, để kiểm tra lại quyền thay vì dựa vào giá trị cũ. */
@Composable
fun rememberResumeTick(): Int {
    val owner = LocalLifecycleOwner.current
    var tick by remember { mutableIntStateOf(0) }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    return tick
}

// ---------------- Mạng (dữ liệu thật) ----------------

data class NetState(val connected: Boolean, val type: String, val vpn: Boolean, val validated: Boolean)

private fun readNet(cm: ConnectivityManager): NetState {
    val n = cm.activeNetwork ?: return NetState(false, "Không có mạng", false, false)
    val c = cm.getNetworkCapabilities(n) ?: return NetState(false, "Không có mạng", false, false)
    val type = when {
        c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
        c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Dữ liệu di động"
        c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
        c.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
        else -> "Khác"
    }
    return NetState(
        connected = true,
        type = type,
        vpn = c.hasTransport(NetworkCapabilities.TRANSPORT_VPN),
        validated = c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED),
    )
}

@Composable
fun rememberNetState(): NetState {
    val ctx = LocalContext.current
    val cm = remember { ctx.getSystemService(ConnectivityManager::class.java) }
    var state by remember { mutableStateOf(readNet(cm)) }
    DisposableEffect(cm) {
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { state = readNet(cm) }
            override fun onLost(network: Network) { state = readNet(cm) }
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) { state = readNet(cm) }
        }
        cm.registerDefaultNetworkCallback(cb)
        onDispose { cm.unregisterNetworkCallback(cb) }
    }
    return state
}

// ---------------- Permission State Manager (v1.1 mục E) ----------------

enum class PState(val label: String, val tone: Tone) {
    GRANTED("Đã cấp", Tone.OK),
    NOT_ASKED("Chưa hỏi", Tone.NEUTRAL),
    DENIED("Bị từ chối", Tone.PERM),
    PERMANENTLY_DENIED("Từ chối vĩnh viễn", Tone.PERM),
    REVOKED("Đã thu hồi", Tone.BAD),
    RESTRICTED_BY_SYSTEM("Hệ thống hạn chế", Tone.WARN),
    NOT_APPLICABLE("Không áp dụng", Tone.NEUTRAL),
}

fun runtimeState(ctx: Context, prefs: Prefs, permission: String): PState {
    val granted = ContextCompat.checkSelfPermission(ctx, permission) == PackageManager.PERMISSION_GRANTED
    if (granted) {
        prefs.markSeenGranted(permission)
        return PState.GRANTED
    }
    if (prefs.seenGranted(permission)) return PState.REVOKED
    if (!prefs.requested(permission)) return PState.NOT_ASKED
    val activity = ctx.findActivity()
    return if (activity != null && activity.shouldShowRequestPermissionRationale(permission)) PState.DENIED
    else PState.PERMANENTLY_DENIED
}

fun notificationState(ctx: Context, prefs: Prefs): PState =
    if (Build.VERSION.SDK_INT >= 33) runtimeState(ctx, prefs, Manifest.permission.POST_NOTIFICATIONS)
    else if (NotificationManagerCompat.from(ctx).areNotificationsEnabled()) PState.GRANTED else PState.DENIED

fun bluetoothState(ctx: Context, prefs: Prefs, permission: String): PState =
    if (Build.VERSION.SDK_INT >= 31) runtimeState(ctx, prefs, permission) else PState.NOT_APPLICABLE

fun vpnConsentState(ctx: Context, prefs: Prefs): PState {
    val granted = VpnService.prepare(ctx) == null
    return when {
        granted -> { prefs.markSeenGranted("vpn"); PState.GRANTED }
        prefs.seenGranted("vpn") -> PState.REVOKED
        prefs.requested("vpn") -> PState.DENIED
        else -> PState.NOT_ASKED
    }
}

@Suppress("DEPRECATION")
fun usageAccessState(ctx: Context, prefs: Prefs): PState {
    val ops = ctx.getSystemService(AppOpsManager::class.java)
    val mode = if (Build.VERSION.SDK_INT >= 29) {
        ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
    } else {
        ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
    }
    return when {
        mode == AppOpsManager.MODE_ALLOWED -> { prefs.markSeenGranted("usage"); PState.GRANTED }
        prefs.seenGranted("usage") -> PState.REVOKED
        else -> PState.NOT_ASKED
    }
}
