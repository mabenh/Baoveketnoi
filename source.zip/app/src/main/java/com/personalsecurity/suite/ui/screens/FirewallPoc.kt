package com.personalsecurity.suite.ui.screens

import android.app.Activity
import android.net.VpnService
import android.provider.Settings as AndroidSettings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.personalsecurity.suite.firewall.AppCatalog
import com.personalsecurity.suite.firewall.AppEntry
import com.personalsecurity.suite.firewall.FirewallController
import com.personalsecurity.suite.firewall.FirewallPolicy
import com.personalsecurity.suite.firewall.FirewallStatus
import com.personalsecurity.suite.openSettings
import com.personalsecurity.suite.ui.Body
import com.personalsecurity.suite.ui.Chip
import com.personalsecurity.suite.ui.Ink
import com.personalsecurity.suite.ui.Kv
import com.personalsecurity.suite.ui.Muted
import com.personalsecurity.suite.ui.Note
import com.personalsecurity.suite.ui.Pill
import com.personalsecurity.suite.ui.Primary
import com.personalsecurity.suite.ui.PrimaryButton
import com.personalsecurity.suite.ui.RowDivider
import com.personalsecurity.suite.ui.SCard
import com.personalsecurity.suite.ui.Screen
import com.personalsecurity.suite.ui.SecondaryButton
import com.personalsecurity.suite.ui.Tone
import com.personalsecurity.suite.vpn.VpnController
import com.personalsecurity.suite.vpn.VpnStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

private fun t(ms: Long) = DateFormat.getTimeInstance(DateFormat.MEDIUM).format(Date(ms))

/** PR-FW01 – Technical Proof of Concept: Default-Deny Firewall. */
@Composable
fun FirewallScreen() {
    val ctx = LocalContext.current
    val status = FirewallController.status.collectAsState().value
    val events = FirewallController.events.collectAsState().value
    val vpn = VpnController.status.collectAsState().value
    var tab by remember { mutableStateOf("apps") }
    var apps by remember { mutableStateOf<List<AppEntry>?>(null) }
    var version by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { AppCatalog.load(ctx) } }
    val allowed = remember(version) { FirewallPolicy.allowed(ctx) }

    val listOn = remember(version, status) { FirewallPolicy.enabled(ctx) }
    val consent = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) { FirewallController.enable(ctx); version++ }
    }
    fun start() {
        val i = VpnService.prepare(ctx)
        if (i == null) { FirewallController.enable(ctx); version++ } else consent.launch(i)
    }

    val (label, tone) = when (status) {
        FirewallStatus.Off -> "OFF · đã tắt" to Tone.NEUTRAL
        FirewallStatus.Starting -> "STARTING · đang khởi tạo" to Tone.NEUTRAL
        is FirewallStatus.Protected -> "✓ PROTECTED" to Tone.OK
        is FirewallStatus.Degraded -> "! DEGRADED" to Tone.WARN
        is FirewallStatus.Error -> "✕ ERROR" to Tone.BAD
    }

    Screen("Firewall Default-Deny", onBack = null, demo = false, subtitle = "PR-FW01 · Proof of Concept") {
        SCard(spacing = 8.dp, bg = if (status is FirewallStatus.Protected) Tone.OK.bg else Color.White) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Trạng thái", Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Ink)
                Pill(label, tone)
            }
            when (status) {
                is FirewallStatus.Protected -> {
                    Kv("Ứng dụng được phép", "${status.allowedApps}")
                    Kv("Bật từ", t(status.since))
                    Kv("Định tuyến vào TUN", "IPv4 0.0.0.0/0 · IPv6 ::/0 · DNS")
                    val lt = status.leakTest
                    Kv("Kiểm tra rò rỉ", if (lt == null) "Chưa chạy" else if (lt.passed) "✓ Đạt lúc ${t(lt.at)}" else "✕ Không đạt", if (lt == null) Tone.UNKNOWN else if (lt.passed) Tone.OK else Tone.BAD)
                }
                is FirewallStatus.Degraded -> Body(status.reason, Tone.WARN.fg, 13)
                is FirewallStatus.Error -> Body(status.reason, Tone.BAD.fg, 13)
                FirewallStatus.Starting -> Body("Đang tạo TUN và nạp chính sách. Chưa được bảo vệ.", Muted, 13)
                FirewallStatus.Off -> Body("Khi bật: mọi ứng dụng mất Internet trừ những ứng dụng bạn cho phép bên dưới. Ứng dụng mới cài mặc định bị chặn.", Muted, 13)
            }
            if (listOn) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (FirewallController.isRunning()) SecondaryButton("Kiểm tra rò rỉ", { FirewallController.runLeakTest(ctx) }, Modifier.weight(1f))
                    SecondaryButton("Tắt danh sách chặn", { FirewallController.disable(ctx); version++ }, Modifier.weight(1f))
                }
            } else {
                PrimaryButton("Bật danh sách chặn", { start() }, Modifier.fillMaxWidth())
            }
        }

        // Một danh sách chặn – hai service thay phiên thực thi.
        val (who, whoTone, whoNote) = when {
            !listOn -> Triple("Danh sách chặn đang tắt", Tone.NEUTRAL, "Mọi ứng dụng dùng mạng bình thường.")
            vpn is VpnStatus.Protected && vpn.appFilter != null -> Triple("WireGuard · VN-HCM-01", Tone.WARN,
                "Chỉ ứng dụng được phép đi qua VPN. Ứng dụng bị chặn chỉ mất mạng khi bạn bật “Luôn bật VPN” + “Chặn kết nối không có VPN” (Lockdown) cho ứng dụng này — ứng dụng không tự kiểm chứng được Lockdown.")
            vpn is VpnStatus.Connecting -> Triple("Đang chuyển lượt sang WireGuard", Tone.NEUTRAL, "Trong lúc chuyển, chỉ Lockdown mới bảo đảm ứng dụng bị chặn không có mạng.")
            status is FirewallStatus.Protected -> Triple("Firewall cục bộ", Tone.OK, "Default-Deny theo định tuyến: ứng dụng bị chặn không có đường ra Internet.")
            FirewallController.isRunning() -> Triple("Firewall cục bộ (đang khởi tạo / suy giảm)", Tone.WARN, "Chưa bảo đảm phạm vi chặn.")
            else -> Triple("Không có service nào đang thực thi", Tone.BAD, "Danh sách chặn đang bật nhưng chưa được thực thi.")
        }
        SCard(spacing = 6.dp) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Đang thực thi danh sách", Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = Ink)
                Pill(who, whoTone)
            }
            Body(whoNote, Muted, 12)
            if (listOn && vpn is VpnStatus.Protected && vpn.appFilter != null) {
                SecondaryButton("Mở cài đặt VPN để bật Lockdown", { openSettings(ctx, AndroidSettings.ACTION_VPN_SETTINGS) }, Modifier.fillMaxWidth())
            }
            Note("WireGuard bật → WireGuard nhận lượt. WireGuard tắt, lỗi hoặc dừng → firewall cục bộ tự nhận lại lượt. Một VPN khác chiếm quyền thì không giành lại.")
        }

        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Chip("Ứng dụng", tab == "apps") { tab = "apps" }
            Chip("Nhật ký chặn (${events.size})", tab == "log") { tab = "log" }
            Chip("Hướng dẫn kiểm thử", tab == "test") { tab = "test" }
        }

        when (tab) {
            "apps" -> {
                OutlinedTextField(query, { query = it }, label = { Text("Tìm ứng dụng") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                val list = apps
                if (list == null) {
                    Body("Đang tải danh sách ứng dụng…", Muted, 13)
                } else {
                    val shown = list.filter { query.isBlank() || it.label.contains(query, true) || it.packageName.contains(query, true) }
                    Note("${allowed.size} được phép · ${list.size - allowed.count { a -> list.any { it.packageName == a } }} bị chặn. Thay đổi có hiệu lực ngay cho kết nối mới.")
                    SCard(spacing = 0.dp, padding = PaddingValues(12.dp, 2.dp)) {
                        shown.forEachIndexed { i, app ->
                            if (i > 0) RowDivider()
                            val on = app.packageName in allowed
                            Row(Modifier.fillMaxWidth().heightIn(min = 60.dp).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                val bmp = app.icon
                                if (bmp != null) Image(bmp.asImageBitmap(), null, Modifier.size(36.dp).clip(RoundedCornerShape(8.dp)))
                                else Box(Modifier.size(36.dp).clip(RoundedCornerShape(8.dp)).background(Tone.NEUTRAL.bg))
                                Column(Modifier.weight(1f)) {
                                    Text(app.label, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Ink)
                                    Text("UID ${app.uid}${if (app.isSystem) " · hệ thống" else ""}", fontSize = 11.sp, color = Muted)
                                    if (app.sharedUidWith.isNotEmpty()) Text("Chung UID với ${app.sharedUidWith.size} package – chính sách áp dụng theo UID", fontSize = 11.sp, color = Tone.WARN.fg)
                                }
                                Pill(if (on) "ALLOW" else "BLOCK", if (on) Tone.OK else Tone.BAD)
                                Switch(on, { v ->
                                    FirewallPolicy.setAllowed(ctx, app.packageName, v)
                                    version++
                                    FirewallController.policyChanged(ctx)
                                }, colors = SwitchDefaults.colors(checkedTrackColor = Primary))
                            }
                        }
                    }
                }
            }
            "log" -> {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Note("Ghi theo kết nối (không theo từng packet), chỉ lưu trong bộ nhớ, không gửi đi.", modifier = Modifier.weight(1f))
                    SecondaryButton("Xóa", { FirewallController.clearEvents() })
                }
                if (events.isEmpty()) {
                    SCard { Body("Chưa có kết nối nào bị chặn.", Muted, 13) }
                } else {
                    SCard(spacing = 0.dp, padding = PaddingValues(12.dp, 2.dp)) {
                        events.take(150).forEachIndexed { i, e ->
                            if (i > 0) RowDivider()
                            Column(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(e.app, Modifier.weight(1f), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Ink)
                                    Pill("BLOCK", Tone.BAD)
                                }
                                Text("${t(e.at)} · UID ${if (e.uid >= 0) e.uid else "?"} · ${e.protocol} → ${e.destination}:${e.port}", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Muted)
                                Text(
                                    when (e.reason) {
                                        "NOT_ALLOWED" -> "Ứng dụng chưa được cho phép"
                                        "UID_UNSUPPORTED" -> "Android < 10: không tra được UID, vẫn chặn"
                                        else -> "Không xác định chủ sở hữu → fail-closed"
                                    },
                                    fontSize = 11.sp, color = Muted,
                                )
                            }
                        }
                    }
                }
            }
            else -> {
                SCard(spacing = 6.dp) {
                    Text("Kiểm thử trên thiết bị thật", fontWeight = FontWeight.Bold, color = Ink)
                    Body(
                        "1. Bật firewall, chưa cho phép app nào → mở Chrome: không vào được web (FW-001, FW-007/008).\n" +
                            "2. Cho phép Chrome → tải lại trang: vào được (FW-002).\n" +
                            "3. Tắt Chrome trong lúc đang dùng → kết nối mới bị chặn (FW-003).\n" +
                            "4. Bấm “Kiểm tra rò rỉ”: IPv4, IPv6, DNS từ tiến trình bị chặn đều phải thất bại.\n" +
                            "5. Chuyển Wi-Fi ↔ 4G, tắt/bật máy bay: app bị chặn vẫn không có mạng (FW-005/006).\n" +
                            "6. Bật WireGuard hoặc VPN khác → firewall chuyển ERROR và có thông báo (FW-011/016).\n" +
                            "7. Bật Always-on + “Chặn kết nối không có VPN”: kiểm tra app được phép có còn mạng không (FW-019).",
                        size = 13,
                    )
                    SecondaryButton("Mở cài đặt VPN của Android", { openSettings(ctx, AndroidSettings.ACTION_VPN_SETTINGS) }, Modifier.fillMaxWidth())
                }
                Note("Chi tiết nghiên cứu và ma trận FW-001…FW-019: docs/PR-FW01.md trong mã nguồn.")
            }
        }
    }
}
