# PR-FW01 — Khả thi kỹ thuật của Default-Deny Firewall trên Android

Trạng thái: **Khả thi có điều kiện — đã có PoC trong mã nguồn, chờ kiểm thử trên thiết bị thật.**

## 1. Kết luận

- Default-Deny không cần root là khả thi bằng `VpnService`.
- **Điều chỉnh so với đề xuất ban đầu:** PoC không xây Packet Processor chuyển tiếp lưu lượng. Default-Deny được thực thi
  ở **tầng định tuyến của Android**, ít rủi ro hơn nhiều:
  1. TUN nhận toàn bộ `0.0.0.0/0` và `::/0`; DNS trỏ vào địa chỉ trong TUN.
  2. Ứng dụng **được phép** được loại khỏi VPN bằng `addDisallowedApplication()` → đi mạng thật,
     hệ điều hành tự thực thi theo UID.
  3. Mọi ứng dụng còn lại (kể cả app mới cài, UID không xác định) bị định tuyến vào TUN; packet chỉ được đọc header để
     ghi nhật ký rồi **bỏ**. Không tồn tại đường chuyển tiếp cho lưu lượng bị chặn.
- Hệ quả: không có tình huống “không tìm được UID → cho phép” (FW-010 đạt theo thiết kế); app mới mặc định bị chặn
  (FW-001 đạt theo thiết kế) mà không cần theo dõi cài đặt; chặn hoạt động cả trên Android 8–9.
  `getConnectionOwnerUid()` (Android 10+) chỉ dùng cho **nhật ký** ai bị chặn.
- Packet Processor + Connection Attribution + Policy Engine theo flow (kiến trúc ở đề xuất gốc) chỉ cần khi muốn
  chính sách theo từng kết nối (đích, cổng, mức tin cậy mạng) hoặc kết hợp với VPN từ xa trong cùng một tunnel.
  Đó là giai đoạn sau, cần userspace TCP/IP stack.

## 2. Sự thật đã đối chiếu với tài liệu Android chính thức

| Điểm | Tài liệu nói | Ảnh hưởng |
| --- | --- | --- |
| `addDisallowedApplication` | App bị loại “use networking as if the VPN wasn't running” | Dùng cho app ĐƯỢC PHÉP |
| Allowed + Disallowed cùng Builder | “may have only a set of allowed applications OR a set of disallowed ones, but not both” | Chọn mô hình disallowed |
| Không gọi cả hai | “all applications are allowed access” (đều đi qua VPN) | App chưa cho phép bị đưa vào TUN |
| Lockdown | “apps that aren't in an allowed list or in a disallowed list lose their network connection” | **Không nói rõ** app trong disallowed list có giữ mạng khi lockdown → FW-019 |
| `getConnectionOwnerUid` | API 29; chỉ TCP/UDP; người gọi phải là VPN đang hoạt động; `INVALID_UID` nếu không tìm thấy | Chỉ dùng ghi nhật ký; ICMP/khác ghi “Không xác định” |
| Foreground | API 26+ phải `startForeground()`; trang VPN **không** nêu loại FGS cho Android 14+ | PoC: `startForeground` khi < 14; ≥ 14 chỉ thông báo ongoing — chờ quyết định |

Nguồn: VpnService.Builder, VPN guide, ConnectivityManager (developer.android.com). Phần `DevicePolicyManager.setAlwaysOnVpnPackage`
(lockdownAllowlist) chưa đọc được nguyên văn — dành cho Device Owner, không thuộc phạm vi app phổ thông.

## 3. Mã nguồn PoC

| File | Vai trò |
| --- | --- |
| `firewall/FirewallVpnService.kt` | VpnService duy nhất của firewall: TUN IPv4+IPv6, DNS trong TUN, disallowed = allowlist, đọc & bỏ packet, nhật ký theo flow (cache 60 s, tối đa 512 flow), kiểm tra rò rỉ, `onRevoke` |
| `firewall/FirewallPolicy.kt` | Allowlist lưu cục bộ; tự gỡ package đã gỡ cài đặt; danh sách app qua `<queries>` (không dùng `QUERY_ALL_PACKAGES`) |
| `firewall/FirewallNotifier.kt` | Thông báo thường trực / gián đoạn |
| `ui/screens/FirewallPoc.kt` | Trạng thái OFF/STARTING/PROTECTED/DEGRADED/ERROR, công tắc từng app, nhật ký UID–đích–giao thức–quyết định, hướng dẫn kiểm thử |

**Kiểm tra rò rỉ tích hợp:** tạm thời không miễn trừ chính app → thử kết nối `1.1.1.1:443` (IPv4),
`[2606:4700:4700::1111]:443` (IPv6) và phân giải một tên miền ngẫu nhiên (DNS). Cả ba phải thất bại; nếu không,
trạng thái chuyển **DEGRADED**. Sau đó cấu hình bình thường được khôi phục.

**Ngoại lệ hệ thống:** danh sách `SYSTEM_EXCEPTIONS` đang **rỗng**. Chỉ thêm khi có kết quả kiểm thử và lý do (FW-018).
Ngoại lệ duy nhất là chính app Personal Security Suite (cần mạng để hoạt động).

## 4. Xung đột với VPN WireGuard (quyết định cần chốt)

Android chỉ cho **một** VPN hoạt động. WireGuard dùng `GoBackend.VpnService` (thư viện tự tạo TUN), firewall dùng
`FirewallVpnService`. Trong PoC hai chế độ **loại trừ nhau**: bật cái này sẽ tắt cái kia, giao diện báo rõ.

| Phương án kết hợp | Nhận định |
| --- | --- |
| A. Hai chế độ riêng (hiện tại) | Đơn giản, đúng; người dùng phải chọn bảo vệ IP hoặc chặn app |
| B. WireGuard `IncludedApplications` = allowlist + người dùng bật Lockdown | Không cần code mới, nhưng phụ thuộc hành vi lockdown chưa được tài liệu khẳng định (FW-019) và người dùng tự bật |
| C. Một VpnService: TUN → Policy Engine → wireguard-go userspace (tự build `libwg-go`, không dùng GoBackend) | Đúng kiến trúc “một service duy nhất”, nhưng cần đội networking và audit; làm sau khi PoC đạt |

Đề xuất: giữ A cho thử nghiệm, đo B trên thiết bị, lập kế hoạch C cho bản thương mại.

### 4.1 Quyết định (23/11/2026): A — một danh sách chặn, hai service thay phiên

| Tình huống | Service thực thi danh sách | Mức bảo đảm |
| --- | --- | --- |
| Danh sách bật, WireGuard tắt | `FirewallVpnService` (Default-Deny theo định tuyến) | Đã xác minh: TUN v4+v6, kiểm tra rò rỉ |
| Danh sách bật, WireGuard đang chạy | WireGuard: `IncludedApplications` = app được phép + chính app | App bị chặn đi mạng trực tiếp **trừ khi** người dùng bật Lockdown. App không đọc được trạng thái Lockdown → giao diện luôn hiện cảnh báo, không bao giờ báo “đã chặn” |
| WireGuard người dùng tắt / lỗi / dịch vụ dừng | Firewall tự nhận lại lượt (`resumeIfEnabled`) | Có khoảng chuyển giao vài trăm ms; chỉ Lockdown che được khoảng này |
| WireGuard bị VPN khác chiếm (`onRevoke`) | Không giành lại | Báo gián đoạn |
| Mở lại app sau khi tiến trình bị dừng | Firewall nhận lượt nếu danh sách đang bật | — |
| Đổi danh sách | Firewall: dựng lại TUN; WireGuard: hạ và dựng lại tunnel với `IncludedApplications` mới | — |

Mã: `FirewallController.enable/disable/policyChanged/resumeIfEnabled`, `VpnController.reconnect`, `restrictToApps()`.
Bổ sung kiểm thử: **FW-020** chuyển WireGuard → firewall (tắt VPN) và ngược lại: đo khoảng hở; **FW-021** WireGuard + danh sách bật,
Lockdown tắt: xác nhận giao diện cảnh báo đúng; Lockdown bật: app bị chặn không có mạng (gộp với FW-019).

## 5. Ma trận nghiệm thu

| ID | Kịch bản | Trạng thái PoC |
| --- | --- | --- |
| FW-001 | App mới mặc định BLOCK | Đạt theo thiết kế; cần xác nhận trên máy |
| FW-002 | Cho phép Chrome | Cần thử trên máy |
| FW-003 | Chặn Chrome khi đang dùng | Re-establish TUN ngay khi đổi công tắc; cần thử |
| FW-004 | Flow đang mở khi bị chặn | Chính sách công bố: kết nối mới bị chặn; socket đã mở có thể tồn tại tới khi đóng — cần đo |
| FW-005/006 | Chuyển Wi-Fi ↔ 4G | Route không phụ thuộc mạng nền; cần thử, đặc biệt khoảnh khắc chuyển mạng |
| FW-007/008 | IPv4 / IPv6 | Route cả hai họ; kiểm tra rò rỉ tích hợp |
| FW-009 | DNS | DNS trong TUN, bị bỏ; kiểm tra rò rỉ tích hợp. Private DNS (DoT) của hệ thống cần thử riêng |
| FW-010 | UID không xác định | Bị bỏ theo thiết kế (không có đường cho phép) |
| FW-011 | VPN bị thu hồi | `onRevoke` → ERROR + thông báo |
| FW-012 | Khởi động lại | Chưa hỗ trợ always-on cho firewall (2 VpnService trong cùng app → hành vi chọn service chưa xác định) |
| FW-013 | Mất mạng nền | Không đổi trạng thái firewall; cần thử |
| FW-014 | Nhiều package chung UID | UI cảnh báo, chính sách theo UID |
| FW-015 | Tải liên tục | Đọc-bỏ packet, cache flow giới hạn; cần đo CPU/RAM/pin |
| FW-016 | VPN app khác | → `onRevoke` → ERROR |
| FW-017 | QUIC/HTTP3 | UDP bị chặn như TCP; cần thử |
| FW-018 | Push notification | Google Play Services mặc định bị chặn → push của app được phép có thể hỏng. Cần đo và quyết định ngoại lệ có kiểm chứng |
| FW-019 | Lockdown + app được phép | Tài liệu không khẳng định; **phải đo** trước khi hướng dẫn người dùng bật lockdown |

## 6. Quyết định còn mở

1. Loại foreground service cho VPN trên Android 14+ (đối chiếu Play Console trước khi khai báo).
2. `QUERY_ALL_PACKAGES`: PoC chỉ liệt kê app có launcher + Play Services/Play Store; bản sản phẩm có cần xin quyền này không.
3. Ngoại lệ hệ thống (Play Services, DownloadManager, NTP…) sau khi đo FW-018.
4. Phương án kết hợp với WireGuard (mục 4).
5. Chính sách theo loại mạng (Wi-Fi / di động / mạng tin cậy): làm được bằng re-establish khi mạng đổi — giai đoạn 2.
