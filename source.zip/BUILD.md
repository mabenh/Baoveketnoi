# Build APK trên GitHub

## 1. Tạo repository và đẩy mã nguồn (máy tính có Git)

Giải nén `source.zip` vào một thư mục, mở terminal tại thư mục đó:

```bash
git init -b main
git add .
git commit -m "Personal Security Suite – bản thử nghiệm"
git remote add origin https://github.com/<tài-khoản>/<tên-repo>.git
git push -u origin main
```

Đẩy lên là workflow **Build APK** tự chạy (tab **Actions**).

## 2. Đặt biến cho bản build (một lần)

GitHub › repo › **Settings › Secrets and variables › Actions › Variables › New repository variable**:

| Tên | Ví dụ | Bắt buộc |
| --- | --- | --- |
| `GATEWAY_HOST` | `hcm.vpn.example.com` | Nên có (app từ chối cấu hình trỏ tới host khác) |
| `CONFIG_SIGNING_PUBLIC_KEY` | kết quả `python -m app.cli show-signing-key` | Cần cho “Nhận cấu hình từ máy chủ” |
| `PROVISIONING_BASE_URL` | `https://api.example.com` | Không |

Hoặc bằng GitHub CLI:

```bash
gh variable set GATEWAY_HOST --body "hcm.vpn.example.com"
gh variable set CONFIG_SIGNING_PUBLIC_KEY --body "<khóa SPKI base64>"
gh variable set PROVISIONING_BASE_URL --body "https://api.example.com"
```

## 3. Chạy build và tải APK

Trên web: **Actions › Build APK › Run workflow** → chờ xong → mở lần chạy → **Artifacts** → tải `PersonalSecuritySuite-debug-<số>`.

Bằng GitHub CLI:

```bash
gh workflow run "Build APK"
gh run watch
gh run download --name "PersonalSecuritySuite-debug-$(gh run list --workflow "Build APK" --limit 1 --json number --jq '.[0].number')"
```

## 4. Bản release đã ký (tùy chọn)

Tạo keystore một lần (giữ file và mật khẩu cẩn thận, không commit):

```bash
keytool -genkeypair -v -keystore release.jks -alias pss -keyalg RSA -keysize 4096 -validity 10000
```

Thêm 4 secret (Settings › Secrets and variables › Actions › **Secrets**):

```bash
base64 -w0 release.jks | gh secret set KEYSTORE_BASE64
gh secret set KEYSTORE_PASSWORD
gh secret set KEY_ALIAS --body "pss"
gh secret set KEY_PASSWORD
```

Lần chạy tiếp theo có thêm artifact `PersonalSecuritySuite-release-<số>`.

## 5. Khi build lỗi

Mở lần chạy lỗi → bước bị đỏ → copy log; hoặc tải artifact `build-reports-<số>`. Lấy log bằng CLI:

```bash
gh run view --log-failed > build-error.log
```

## Bật đa ngôn ngữ sau giai đoạn thử nghiệm

Sửa `gradle.properties`: `pss.multiLanguage=true`, commit và push.
