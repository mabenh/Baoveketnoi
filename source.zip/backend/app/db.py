import sqlite3
from contextlib import contextmanager

SCHEMA = """
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('active', 'locked', 'disabled')),
    vpn_entitled_until TEXT,               -- ISO-8601 UTC, NULL = không có quyền VPN
    max_devices INTEGER NOT NULL,
    created_at TEXT NOT NULL
);

-- Chỉ lưu SHA-256 của token, không lưu token gốc.
CREATE TABLE IF NOT EXISTS tokens (
    token_hash TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id),
    scopes TEXT NOT NULL,                  -- "vpn" | "vpn admin"
    expires_at TEXT NOT NULL,
    revoked INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
);

-- Không có cột private key: khóa riêng được sinh và giữ trên thiết bị.
CREATE TABLE IF NOT EXISTS peers (
    peer_id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id),
    device_id TEXT NOT NULL,
    public_key TEXT NOT NULL,
    ipv4 TEXT NOT NULL,
    ipv6 TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('active', 'revoked', 'expired')),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    revoked_at TEXT,
    revoke_reason TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS peers_active_device ON peers(user_id, device_id) WHERE status = 'active';
CREATE UNIQUE INDEX IF NOT EXISTS peers_active_key ON peers(public_key) WHERE status = 'active';
CREATE UNIQUE INDEX IF NOT EXISTS peers_active_ipv4 ON peers(ipv4) WHERE status = 'active';
CREATE UNIQUE INDEX IF NOT EXISTS peers_active_ipv6 ON peers(ipv6) WHERE status = 'active';

-- Audit: không chứa token, khóa, nội dung truy cập.
CREATE TABLE IF NOT EXISTS audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    actor TEXT NOT NULL,
    user_id TEXT,
    device_id TEXT,
    peer_id TEXT,
    action TEXT NOT NULL,
    result TEXT NOT NULL,
    client_ip TEXT,
    detail TEXT
);
"""


def connect(path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(path, isolation_level=None, check_same_thread=False, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db(path: str) -> None:
    conn = connect(path)
    conn.executescript(SCHEMA)
    conn.close()


@contextmanager
def transaction(conn: sqlite3.Connection):
    """BEGIN IMMEDIATE: khóa ghi ngay để cấp IP không bị trùng khi có request song song."""
    conn.execute("BEGIN IMMEDIATE")
    try:
        yield conn
        conn.execute("COMMIT")
    except BaseException:
        conn.execute("ROLLBACK")
        raise
