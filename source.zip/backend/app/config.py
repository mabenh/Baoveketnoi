import os
from dataclasses import dataclass, field


def _env(name: str, default: str) -> str:
    return os.environ.get(name, default)


@dataclass(frozen=True)
class Settings:
    db_path: str = field(default_factory=lambda: _env("PSS_DB", "pss.db"))
    # Gateway WireGuard
    wg_interface: str = field(default_factory=lambda: _env("PSS_WG_INTERFACE", "wg0"))
    wg_endpoint: str = field(default_factory=lambda: _env("PSS_WG_ENDPOINT", "hcm.vpn.example.com:51820"))
    wg_server_public_key: str = field(default_factory=lambda: _env("PSS_WG_SERVER_PUBLIC_KEY", ""))
    # Giai đoạn thử nghiệm: một gateway duy nhất ở TP.HCM, API chạy cùng máy (WgCliDriver).
    gateway_id: str = field(default_factory=lambda: _env("PSS_GATEWAY_ID", "VN-HCM-01"))
    driver: str = field(default_factory=lambda: _env("PSS_DRIVER", "wg"))  # wg | fake
    # Địa chỉ trong tunnel. .1 / ::1 dành cho gateway (resolver DNS nội bộ chạy ở đó).
    ipv4_pool: str = field(default_factory=lambda: _env("PSS_IPV4_POOL", "10.8.0.0/24"))
    ipv6_pool: str = field(default_factory=lambda: _env("PSS_IPV6_POOL", "fd42:42:42::/64"))
    dns: str = field(default_factory=lambda: _env("PSS_DNS", "10.8.0.1, fd42:42:42::1"))
    mtu: int = field(default_factory=lambda: int(_env("PSS_MTU", "1280")))
    keepalive: int = field(default_factory=lambda: int(_env("PSS_KEEPALIVE", "25")))
    # Chính sách
    peer_ttl_days: int = field(default_factory=lambda: int(_env("PSS_PEER_TTL_DAYS", "30")))
    default_max_devices: int = field(default_factory=lambda: int(_env("PSS_MAX_DEVICES", "1")))
    rate_user_per_hour: int = field(default_factory=lambda: int(_env("PSS_RATE_USER_PER_HOUR", "10")))
    rate_ip_per_hour: int = field(default_factory=lambda: int(_env("PSS_RATE_IP_PER_HOUR", "30")))
    # Khóa ký cấu hình (ECDSA P-256). File PEM quyền 0600, nên đặt trong secret manager / HSM.
    signing_key_path: str = field(default_factory=lambda: _env("PSS_SIGNING_KEY", "signing_key.pem"))
