"""Điểm vào ASGI: uvicorn app.server:app (đặt sau reverse proxy TLS 1.2+)."""
from .main import create_app

app = create_app()
