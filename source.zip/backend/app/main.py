"""WireGuard provisioning API.

Nguyên tắc:
- Thiết bị tự sinh cặp khóa WireGuard; API chỉ nhận PublicKey, không bao giờ nhận/trả PrivateKey.
- Mỗi (tài khoản, thiết bị) có tối đa một peer hoạt động, với IPv4 /32 + IPv6 /128 riêng.
- Cấu hình trả về được ký (ECDSA P-256) kèm nonce của client để chống giả mạo / phát lại.
- Thu hồi tức thì: xóa peer trên gateway rồi mới đánh dấu trong DB; audit mọi thao tác.
"""
import hashlib
import ipaddress
import re
import secrets
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

from fastapi import Depends, FastAPI, Header, Request, Response
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from . import db as dbm
from .config import Settings
from .ratelimit import SlidingWindowLimiter
from .signing import ALG, Signer, signing_message
from .wg import GatewayDriver, GatewayError, is_valid_wg_key, make_driver

DEVICE_ID_RE = re.compile(r"^[A-Za-z0-9_-]{8,64}$")
NONCE_RE = re.compile(r"^[A-Za-z0-9_-]{16,64}$")


def now() -> datetime:
    return datetime.now(timezone.utc).replace(microsecond=0)


def iso(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def parse_iso(s: str) -> datetime:
    return datetime.strptime(s, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)


class ApiError(Exception):
    def __init__(self, status: int, code: str, message: str, headers: dict | None = None):
        self.status, self.code, self.message, self.headers = status, code, message, headers or {}


# ----------------------------- Schemas -----------------------------

class ProvisionRequest(BaseModel):
    device_id: str
    client_public_key: str
    nonce: str


class ProvisionResponse(BaseModel):
    peer_id: str
    device_id: str
    ipv4: str
    ipv6: str
    issued_at: str
    expires_at: str
    nonce: str
    config_text: str  # KHÔNG có PrivateKey – app tự chèn khóa riêng của nó
    signature: str
    signature_alg: str
    key_id: str


class DeviceOut(BaseModel):
    peer_id: str
    device_id: str
    ipv4: str
    created_at: str
    expires_at: str


class LogoutRequest(BaseModel):
    device_id: str | None = None


@dataclass
class Principal:
    user_id: str
    scopes: set[str]
    token_hash: str


# ----------------------------- App factory -----------------------------

def create_app(settings: Settings | None = None, driver: GatewayDriver | None = None, signer: Signer | None = None) -> FastAPI:
    settings = settings or Settings()
    dbm.init_db(settings.db_path)
    conn = dbm.connect(settings.db_path)
    driver = driver or make_driver(settings.driver, settings.wg_interface)
    signer = signer or Signer.load_or_create(settings.signing_key_path)
    limiter = SlidingWindowLimiter()
    v4net = ipaddress.ip_network(settings.ipv4_pool)
    v6net = ipaddress.ip_network(settings.ipv6_pool)
    if not is_valid_wg_key(settings.wg_server_public_key):
        raise RuntimeError("PSS_WG_SERVER_PUBLIC_KEY chưa đặt hoặc không hợp lệ")

    app = FastAPI(title="Personal Security Suite – WireGuard Provisioning API", version="1.0.0", docs_url=None, redoc_url=None)
    app.state.settings, app.state.driver, app.state.signer, app.state.conn = settings, driver, signer, conn

    # ------------------------- error format -------------------------
    @app.exception_handler(ApiError)
    async def _api_error(_: Request, e: ApiError):
        return JSONResponse({"error": {"code": e.code, "message": e.message}}, status_code=e.status,
                            headers={"Cache-Control": "no-store", **e.headers})

    @app.exception_handler(RequestValidationError)
    async def _validation(_: Request, __: RequestValidationError):
        return JSONResponse({"error": {"code": "invalid_request", "message": "Request body không hợp lệ."}}, status_code=422)

    @app.middleware("http")
    async def _no_store(request: Request, call_next):
        resp = await call_next(request)
        resp.headers["Cache-Control"] = "no-store"
        resp.headers["X-Content-Type-Options"] = "nosniff"
        return resp

    # ------------------------- helpers -------------------------
    def audit(actor: str, action: str, result: str, request: Request | None = None, user_id=None, device_id=None, peer_id=None, detail=None):
        conn.execute(
            "INSERT INTO audit(ts, actor, user_id, device_id, peer_id, action, result, client_ip, detail) VALUES (?,?,?,?,?,?,?,?,?)",
            (iso(now()), actor, user_id, device_id, peer_id, action, result,
             request.client.host if request and request.client else None, detail),
        )

    def principal(request: Request, authorization: str | None = Header(default=None)) -> Principal:
        unauthorized = ApiError(401, "unauthorized", "Thiếu hoặc sai access token.", {"WWW-Authenticate": "Bearer"})
        if not authorization or not authorization.startswith("Bearer "):
            raise unauthorized
        token = authorization[7:].strip()
        if not token or len(token) > 512:
            raise unauthorized
        th = hashlib.sha256(token.encode()).hexdigest()
        row = conn.execute(
            "SELECT t.user_id, t.scopes, t.expires_at, t.revoked, u.status FROM tokens t JOIN users u ON u.id = t.user_id WHERE t.token_hash = ?",
            (th,),
        ).fetchone()
        if row is None or row["revoked"] or parse_iso(row["expires_at"]) <= now():
            raise unauthorized
        if row["status"] != "active":
            raise ApiError(403, "account_locked", "Tài khoản đang bị khóa hoặc vô hiệu hóa.")
        return Principal(row["user_id"], set(row["scopes"].split()), th)

    def require_vpn(p: Principal) -> sqlite3.Row:
        user = conn.execute("SELECT * FROM users WHERE id = ?", (p.user_id,)).fetchone()
        if "vpn" not in p.scopes or not user["vpn_entitled_until"] or parse_iso(user["vpn_entitled_until"]) <= now():
            raise ApiError(403, "vpn_not_entitled", "Tài khoản không có quyền sử dụng VPN hoặc gói đã hết hạn.")
        return user

    def allocate(c: sqlite3.Connection) -> tuple[str, str]:
        used = {r["ipv4"] for r in c.execute("SELECT ipv4 FROM peers WHERE status = 'active'")}
        hosts = list(v4net.hosts())
        for idx, host in enumerate(hosts):
            if idx == 0:
                continue  # .1 dành cho gateway / DNS resolver
            if f"{host}/32" not in used:
                offset = int(host) - int(v4net.network_address)
                v6 = ipaddress.IPv6Address(int(v6net.network_address) + offset)
                return f"{host}/32", f"{v6}/128"
        raise ApiError(503, "pool_exhausted", "Hết địa chỉ IP để cấp. Vui lòng thử lại sau.")

    def build_config(ipv4: str, ipv6: str) -> str:
        return (
            "[Interface]\n"
            f"Address = {ipv4}, {ipv6}\n"
            f"DNS = {settings.dns}\n"
            f"MTU = {settings.mtu}\n"
            "\n"
            "[Peer]\n"
            f"PublicKey = {settings.wg_server_public_key}\n"
            f"Endpoint = {settings.wg_endpoint}\n"
            "AllowedIPs = 0.0.0.0/0, ::/0\n"
            f"PersistentKeepalive = {settings.keepalive}\n"
        )

    def revoke_peer(c: sqlite3.Connection, row: sqlite3.Row, reason: str, status: str = "revoked") -> bool:
        """DB là nguồn sự thật: đánh dấu thu hồi trước, rồi gỡ trên gateway.
        Nếu gateway lỗi, peer vẫn bị coi là đã thu hồi và job reconcile sẽ gỡ nốt (không bao giờ thêm lại)."""
        c.execute("UPDATE peers SET status = ?, revoked_at = ?, revoke_reason = ?, updated_at = ? WHERE peer_id = ?",
                  (status, iso(now()), reason, iso(now()), row["peer_id"]))
        try:
            driver.remove_peer(row["public_key"])
            return True
        except GatewayError:
            return False

    # ------------------------- endpoints -------------------------
    @app.get("/healthz")
    def healthz():
        return {"status": "ok"}

    @app.get("/api/v1/vpn/config-signing-key")
    def signing_key():
        """Để đối chiếu khi build app. App KHÔNG được tải khóa này lúc chạy – khóa phải được ghim sẵn."""
        return {"alg": ALG, "key_id": signer.key_id, "public_key_spki_b64": signer.public_key_b64}

    @app.post("/api/v1/vpn/provision", response_model=ProvisionResponse)
    def provision(body: ProvisionRequest, request: Request, p: Principal = Depends(principal)):
        client_ip = request.client.host if request.client else "unknown"
        if not limiter.allow(f"user:{p.user_id}", settings.rate_user_per_hour) or not limiter.allow(f"ip:{client_ip}", settings.rate_ip_per_hour):
            audit(p.user_id, "provision", "rate_limited", request, p.user_id, body.device_id)
            raise ApiError(429, "rate_limited", "Quá nhiều yêu cầu cấp cấu hình. Thử lại sau.", {"Retry-After": "3600"})
        user = require_vpn(p)
        if not DEVICE_ID_RE.match(body.device_id):
            raise ApiError(422, "invalid_device_id", "device_id phải là chuỗi ngẫu nhiên 8–64 ký tự [A-Za-z0-9_-].")
        if not NONCE_RE.match(body.nonce):
            raise ApiError(422, "invalid_nonce", "nonce phải là chuỗi ngẫu nhiên 16–64 ký tự [A-Za-z0-9_-].")
        if not is_valid_wg_key(body.client_public_key):
            raise ApiError(422, "invalid_public_key", "client_public_key không phải khóa WireGuard hợp lệ (base64, 32 byte).")

        issued = now()
        expires = issued + timedelta(days=settings.peer_ttl_days)
        try:
            with dbm.transaction(conn) as c:
                existing = c.execute("SELECT * FROM peers WHERE user_id = ? AND device_id = ? AND status = 'active'",
                                     (p.user_id, body.device_id)).fetchone()
                key_owner = c.execute("SELECT peer_id FROM peers WHERE public_key = ? AND status = 'active'",
                                      (body.client_public_key,)).fetchone()
                if key_owner and (existing is None or key_owner["peer_id"] != existing["peer_id"]):
                    raise ApiError(409, "public_key_in_use", "Khóa công khai đang được dùng cho thiết bị khác.")

                if existing:
                    peer_id, ipv4, ipv6 = existing["peer_id"], existing["ipv4"], existing["ipv6"]
                    action = "renew" if existing["public_key"] == body.client_public_key else "rotate_key"
                    try:
                        if action == "rotate_key":
                            driver.remove_peer(existing["public_key"])  # khóa cũ mất hiệu lực ngay
                        driver.add_peer(body.client_public_key, [ipv4, ipv6])
                    except GatewayError:
                        raise ApiError(503, "gateway_unavailable", "Gateway WireGuard không phản hồi. Thử lại sau.")
                    c.execute("UPDATE peers SET public_key = ?, expires_at = ?, updated_at = ? WHERE peer_id = ?",
                              (body.client_public_key, iso(expires), iso(issued), peer_id))
                else:
                    active = c.execute("SELECT COUNT(*) FROM peers WHERE user_id = ? AND status = 'active'", (p.user_id,)).fetchone()[0]
                    if active >= user["max_devices"]:
                        raise ApiError(409, "device_limit_reached",
                                       "Tài khoản đã đạt số thiết bị tối đa. Gỡ thiết bị cũ trước khi đăng ký thiết bị mới.")
                    ipv4, ipv6 = allocate(c)
                    peer_id = "peer_" + secrets.token_hex(8)
                    action = "provision"
                    c.execute(
                        "INSERT INTO peers(peer_id, user_id, device_id, public_key, ipv4, ipv6, status, created_at, updated_at, expires_at) "
                        "VALUES (?,?,?,?,?,?, 'active', ?,?,?)",
                        (peer_id, p.user_id, body.device_id, body.client_public_key, ipv4, ipv6, iso(issued), iso(issued), iso(expires)),
                    )
                    try:
                        driver.add_peer(body.client_public_key, [ipv4, ipv6])
                    except GatewayError:
                        raise ApiError(503, "gateway_unavailable", "Gateway WireGuard không phản hồi. Thử lại sau.")
        except ApiError as e:
            audit(p.user_id, "provision", e.code, request, p.user_id, body.device_id)
            raise
        audit(p.user_id, action, "ok", request, p.user_id, body.device_id, peer_id)

        config_text = build_config(ipv4, ipv6)
        msg = signing_message(peer_id, body.device_id, body.nonce, iso(issued), iso(expires), config_text)
        return ProvisionResponse(
            peer_id=peer_id, device_id=body.device_id, ipv4=ipv4, ipv6=ipv6,
            issued_at=iso(issued), expires_at=iso(expires), nonce=body.nonce,
            config_text=config_text, signature=signer.sign(msg), signature_alg=ALG, key_id=signer.key_id,
        )

    @app.get("/api/v1/vpn/devices", response_model=list[DeviceOut])
    def list_devices(p: Principal = Depends(principal)):
        rows = conn.execute("SELECT * FROM peers WHERE user_id = ? AND status = 'active' ORDER BY created_at", (p.user_id,)).fetchall()
        return [DeviceOut(peer_id=r["peer_id"], device_id=r["device_id"], ipv4=r["ipv4"], created_at=r["created_at"], expires_at=r["expires_at"]) for r in rows]

    @app.delete("/api/v1/vpn/devices/{device_id}", status_code=204)
    def revoke_device(device_id: str, request: Request, p: Principal = Depends(principal)):
        with dbm.transaction(conn) as c:
            row = c.execute("SELECT * FROM peers WHERE user_id = ? AND device_id = ? AND status = 'active'", (p.user_id, device_id)).fetchone()
            if row is None:
                raise ApiError(404, "device_not_found", "Không có thiết bị đang hoạt động với device_id này.")
            done = revoke_peer(c, row, "user_revoked")
            audit(p.user_id, "revoke_device", "ok" if done else "gateway_pending", request, p.user_id, device_id, row["peer_id"])
        return Response(status_code=204 if done else 202)

    @app.post("/api/v1/auth/logout", status_code=204)
    def logout(body: LogoutRequest, request: Request, p: Principal = Depends(principal)):
        with dbm.transaction(conn) as c:
            if body.device_id:
                row = c.execute("SELECT * FROM peers WHERE user_id = ? AND device_id = ? AND status = 'active'", (p.user_id, body.device_id)).fetchone()
                if row:
                    revoke_peer(c, row, "logout")
            c.execute("UPDATE tokens SET revoked = 1 WHERE token_hash = ?", (p.token_hash,))
            audit(p.user_id, "logout", "ok", request, p.user_id, body.device_id)
        return Response(status_code=204)

    @app.post("/api/v1/admin/users/{user_id}/lock", status_code=204)
    def admin_lock(user_id: str, request: Request, p: Principal = Depends(principal)):
        if "admin" not in p.scopes:
            raise ApiError(403, "forbidden", "Thiếu quyền quản trị.")
        with dbm.transaction(conn) as c:
            if c.execute("SELECT 1 FROM users WHERE id = ?", (user_id,)).fetchone() is None:
                raise ApiError(404, "user_not_found", "Không tìm thấy người dùng.")
            done = True
            for row in c.execute("SELECT * FROM peers WHERE user_id = ? AND status = 'active'", (user_id,)).fetchall():
                done = revoke_peer(c, row, "account_locked") and done
            c.execute("UPDATE users SET status = 'locked' WHERE id = ?", (user_id,))
            c.execute("UPDATE tokens SET revoked = 1 WHERE user_id = ?", (user_id,))
            audit(p.user_id, "admin_lock", "ok" if done else "gateway_pending", request, user_id)
        return Response(status_code=204 if done else 202)

    return app


# ----------------------------- jobs (cron) -----------------------------

def sweep_expired(conn: sqlite3.Connection, driver: GatewayDriver) -> int:
    """Gỡ peer hết hạn khỏi gateway. Chạy định kỳ (cron / systemd timer)."""
    n = 0
    rows = conn.execute("SELECT * FROM peers WHERE status = 'active' AND expires_at <= ?", (iso(now()),)).fetchall()
    for row in rows:
        try:
            driver.remove_peer(row["public_key"])
        except GatewayError:
            continue  # thử lại ở lần chạy sau
        with dbm.transaction(conn) as c:
            c.execute("UPDATE peers SET status = 'expired', revoked_at = ?, revoke_reason = 'expired', updated_at = ? WHERE peer_id = ?",
                      (iso(now()), iso(now()), row["peer_id"]))
            c.execute("INSERT INTO audit(ts, actor, user_id, device_id, peer_id, action, result) VALUES (?,?,?,?,?,?,?)",
                      (iso(now()), "system", row["user_id"], row["device_id"], row["peer_id"], "expire", "ok"))
        n += 1
    return n


def reconcile(conn: sqlite3.Connection, driver: GatewayDriver) -> dict[str, int]:
    """Đồng bộ gateway với DB: gỡ peer lạ (không có trong DB), thêm lại peer hợp lệ bị thiếu."""
    active = {r["public_key"]: [r["ipv4"], r["ipv6"]] for r in conn.execute("SELECT public_key, ipv4, ipv6 FROM peers WHERE status = 'active'")}
    on_gw = driver.list_peers()
    removed = added = 0
    for key in on_gw:
        if key not in active:
            driver.remove_peer(key)
            removed += 1
    for key, ips in active.items():
        if key not in on_gw:
            driver.add_peer(key, ips)
            added += 1
    return {"removed_unknown": removed, "re_added": added}
