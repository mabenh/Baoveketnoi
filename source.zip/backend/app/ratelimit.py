import threading
import time
from collections import defaultdict, deque


class SlidingWindowLimiter:
    """Giới hạn theo cửa sổ trượt 1 giờ, trong bộ nhớ. Production nhiều instance: dùng Redis."""

    def __init__(self, window_seconds: int = 3600):
        self.window = window_seconds
        self._hits: dict[str, deque] = defaultdict(deque)
        self._lock = threading.Lock()

    def allow(self, key: str, limit: int) -> bool:
        now = time.monotonic()
        with self._lock:
            q = self._hits[key]
            while q and now - q[0] > self.window:
                q.popleft()
            if len(q) >= limit:
                return False
            q.append(now)
            return True
