"""Ký cấu hình (ECDSA P-256 / SHA-256) để app phát hiện cấu hình giả mạo hoặc bị phát lại.

Chuỗi được ký (UTF-8, phân tách bằng \\n, đúng thứ tự):
    PSS-WG-PROVISION-v1
    <peer_id>
    <device_id>
    <nonce>            # do app sinh cho từng request → chống replay
    <issued_at>
    <expires_at>
    <sha256_hex(config_text)>
App giữ khóa công khai (SPKI, base64) được ghim sẵn khi build.
"""
import base64
import hashlib
import os
import stat

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec

ALG = "ES256-DER"


def signing_message(peer_id: str, device_id: str, nonce: str, issued_at: str, expires_at: str, config_text: str) -> bytes:
    digest = hashlib.sha256(config_text.encode("utf-8")).hexdigest()
    return "\n".join(["PSS-WG-PROVISION-v1", peer_id, device_id, nonce, issued_at, expires_at, digest]).encode("utf-8")


class Signer:
    def __init__(self, key: ec.EllipticCurvePrivateKey):
        self._key = key
        spki = key.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
        self.public_key_b64 = base64.b64encode(spki).decode()
        self.key_id = hashlib.sha256(spki).hexdigest()[:16]

    @classmethod
    def load_or_create(cls, path: str) -> "Signer":
        if os.path.exists(path):
            with open(path, "rb") as f:
                key = serialization.load_pem_private_key(f.read(), password=None)
            if not isinstance(key, ec.EllipticCurvePrivateKey):
                raise ValueError("signing key must be EC P-256")
            return cls(key)
        key = ec.generate_private_key(ec.SECP256R1())
        pem = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, stat.S_IRUSR | stat.S_IWUSR)
        with os.fdopen(fd, "wb") as f:
            f.write(pem)
        return cls(key)

    def sign(self, message: bytes) -> str:
        return base64.b64encode(self._key.sign(message, ec.ECDSA(hashes.SHA256()))).decode()
