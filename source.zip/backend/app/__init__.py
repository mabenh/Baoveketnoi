"""Personal Security Suite – WireGuard provisioning API (bản tham chiếu)."""
