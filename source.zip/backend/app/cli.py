"""Công cụ quản trị: python -m app.cli <lệnh>

  init-db                                   tạo schema
  create-user <email> [--days N] [--max-devices N]
  issue-token <user_id> [--scopes "vpn"] [--hours N]   in token MỘT LẦN (chỉ lưu SHA-256)
  show-signing-key                          khóa công khai để ghim vào app (CONFIG_SIGNING_PUBLIC_KEY)
  sweep                                     gỡ peer hết hạn (chạy định kỳ)
  reconcile                                 đồng bộ gateway với DB (chạy định kỳ, ví dụ mỗi phút)
"""
import argparse
import hashlib
import secrets
import uuid
from datetime import timedelta

from . import db as dbm
from .config import Settings
from .main import iso, now, reconcile, sweep_expired
from .signing import Signer
from .wg import make_driver


def main() -> None:
    ap = argparse.ArgumentParser(prog="python -m app.cli")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("init-db")
    cu = sub.add_parser("create-user"); cu.add_argument("email"); cu.add_argument("--days", type=int, default=30); cu.add_argument("--max-devices", type=int)
    it = sub.add_parser("issue-token"); it.add_argument("user_id"); it.add_argument("--scopes", default="vpn"); it.add_argument("--hours", type=int, default=1)
    sub.add_parser("show-signing-key")
    sub.add_parser("sweep")
    sub.add_parser("reconcile")
    a = ap.parse_args()
    s = Settings()
    dbm.init_db(s.db_path)
    conn = dbm.connect(s.db_path)

    if a.cmd == "init-db":
        print("ok")
    elif a.cmd == "create-user":
        uid = "usr_" + uuid.uuid4().hex[:12]
        conn.execute("INSERT INTO users(id, email, status, vpn_entitled_until, max_devices, created_at) VALUES (?,?, 'active', ?,?,?)",
                     (uid, a.email, iso(now() + timedelta(days=a.days)), a.max_devices or s.default_max_devices, iso(now())))
        print(uid)
    elif a.cmd == "issue-token":
        token = secrets.token_urlsafe(32)
        conn.execute("INSERT INTO tokens(token_hash, user_id, scopes, expires_at, created_at) VALUES (?,?,?,?,?)",
                     (hashlib.sha256(token.encode()).hexdigest(), a.user_id, a.scopes, iso(now() + timedelta(hours=a.hours)), iso(now())))
        print(token)  # in đúng một lần, không lưu
    elif a.cmd == "show-signing-key":
        sg = Signer.load_or_create(s.signing_key_path)
        print(f"key_id={sg.key_id}\nCONFIG_SIGNING_PUBLIC_KEY={sg.public_key_b64}")
    elif a.cmd == "sweep":
        print(sweep_expired(conn, make_driver(s.driver, s.wg_interface)))
    elif a.cmd == "reconcile":
        print(reconcile(conn, make_driver(s.driver, s.wg_interface)))


if __name__ == "__main__":
    main()
