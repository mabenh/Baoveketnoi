"""Điều khiển peer trên WireGuard gateway.

Production: control plane KHÔNG nên chạy trên chính gateway. Hãy thay WgCliDriver bằng driver gọi một
gateway agent qua mTLS (cùng interface add_peer/remove_peer/list_peers). WgCliDriver dành cho lab 1 máy.
"""
import base64
import binascii
import re
import subprocess
import threading
from typing import Protocol

_B64_KEY = re.compile(r"^[A-Za-z0-9+/]{42}[AEIMQUYcgkosw048]=$")


def is_valid_wg_key(key: str) -> bool:
    """Khóa WireGuard: base64 chuẩn của đúng 32 byte, dạng canonical."""
    if not isinstance(key, str) or not _B64_KEY.match(key):
        return False
    try:
        raw = base64.b64decode(key, validate=True)
    except (binascii.Error, ValueError):
        return False
    return len(raw) == 32 and base64.b64encode(raw).decode() == key and raw != bytes(32)


class GatewayError(Exception):
    pass


class GatewayDriver(Protocol):
    def add_peer(self, public_key: str, allowed_ips: list[str]) -> None: ...
    def remove_peer(self, public_key: str) -> None: ...
    def list_peers(self) -> dict[str, list[str]]: ...


class WgCliDriver:
    """Dùng `wg set` (không qua shell, tham số đã kiểm tra). Cần CAP_NET_ADMIN."""

    def __init__(self, interface: str):
        if not re.match(r"^[A-Za-z0-9_=+.-]{1,15}$", interface):
            raise ValueError("invalid interface name")
        self.interface = interface

    def _run(self, args: list[str]) -> str:
        try:
            r = subprocess.run(["wg", *args], check=True, capture_output=True, text=True, timeout=10)
            return r.stdout
        except (subprocess.SubprocessError, OSError) as e:
            raise GatewayError(type(e).__name__) from None

    def add_peer(self, public_key: str, allowed_ips: list[str]) -> None:
        if not is_valid_wg_key(public_key):
            raise GatewayError("invalid key")
        # Phía server: AllowedIPs của peer chỉ là IP riêng của nó (/32, /128) – chống giả mạo địa chỉ nguồn.
        self._run(["set", self.interface, "peer", public_key, "allowed-ips", ",".join(allowed_ips)])

    def remove_peer(self, public_key: str) -> None:
        if not is_valid_wg_key(public_key):
            raise GatewayError("invalid key")
        self._run(["set", self.interface, "peer", public_key, "remove"])

    def list_peers(self) -> dict[str, list[str]]:
        out = self._run(["show", self.interface, "allowed-ips"])
        peers: dict[str, list[str]] = {}
        for line in out.splitlines():
            parts = line.split()
            if parts:
                peers[parts[0]] = [p for p in parts[1:] if p != "(none)"]
        return peers


class FakeDriver:
    """Driver trong bộ nhớ cho test và môi trường dev."""

    def __init__(self):
        self.peers: dict[str, list[str]] = {}
        self.fail_next = False
        self._lock = threading.Lock()

    def add_peer(self, public_key: str, allowed_ips: list[str]) -> None:
        with self._lock:
            if self.fail_next:
                self.fail_next = False
                raise GatewayError("simulated failure")
            self.peers[public_key] = list(allowed_ips)

    def remove_peer(self, public_key: str) -> None:
        with self._lock:
            self.peers.pop(public_key, None)

    def list_peers(self) -> dict[str, list[str]]:
        with self._lock:
            return dict(self.peers)


def make_driver(kind: str, interface: str) -> GatewayDriver:
    if kind == "fake":
        return FakeDriver()
    return WgCliDriver(interface)
