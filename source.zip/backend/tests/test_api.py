import base64
import hashlib
import os
from datetime import timedelta

import pytest
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, x25519
from fastapi.testclient import TestClient

from app import db as dbm
from app.config import Settings
from app.main import create_app, iso, now, reconcile, sweep_expired
from app.signing import Signer, signing_message
from app.wg import FakeDriver, is_valid_wg_key


def wg_pub() -> str:
    k = x25519.X25519PrivateKey.generate()
    return base64.b64encode(k.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)).decode()


SERVER_KEY = wg_pub()


@pytest.fixture
def env(tmp_path):
    s = Settings(db_path=str(tmp_path / "t.db"), wg_server_public_key=SERVER_KEY, driver="fake",
                 signing_key_path=str(tmp_path / "sig.pem"), wg_endpoint="vpn.test:51820", rate_user_per_hour=5)
    driver = FakeDriver()
    app = create_app(s, driver)
    client = TestClient(app)
    conn = app.state.conn

    def user(email, days=30, max_devices=1, status="active", scopes="vpn"):
        uid = "usr_" + hashlib.sha1(email.encode()).hexdigest()[:8]
        conn.execute("INSERT INTO users VALUES (?,?,?,?,?,?)", (uid, email, status, iso(now() + timedelta(days=days)) if days else None, max_devices, iso(now())))
        token = "tok-" + email
        conn.execute("INSERT INTO tokens(token_hash, user_id, scopes, expires_at, created_at) VALUES (?,?,?,?,?)",
                     (hashlib.sha256(token.encode()).hexdigest(), uid, scopes, iso(now() + timedelta(hours=1)), iso(now())))
        return uid, {"Authorization": f"Bearer {token}"}

    return s, app, client, driver, conn, user


def body(device="dev_ABCDEFGH01", key=None, nonce="n_" + "a" * 20):
    return {"device_id": device, "client_public_key": key or wg_pub(), "nonce": nonce}


def test_requires_token(env):
    _, _, client, *_ = env
    r = client.post("/api/v1/vpn/provision", json=body())
    assert r.status_code == 401 and r.headers["www-authenticate"] == "Bearer"
    assert client.post("/api/v1/vpn/provision", json=body(), headers={"Authorization": "Bearer nope"}).status_code == 401


def test_forbidden_when_locked_or_not_entitled(env):
    *_, user = env
    _, _, client, *_ = env
    _, h_locked = user("locked@x", status="locked")
    _, h_noent = user("noent@x", days=0)
    assert client.post("/api/v1/vpn/provision", json=body(), headers=h_locked).json()["error"]["code"] == "account_locked"
    r = client.post("/api/v1/vpn/provision", json=body(), headers=h_noent)
    assert r.status_code == 403 and r.json()["error"]["code"] == "vpn_not_entitled"


def test_provision_ok_signed_and_unique_ips(env):
    s, app, client, driver, conn, user = env
    _, h1 = user("a@x"); _, h2 = user("b@x")
    k1 = wg_pub()
    r1 = client.post("/api/v1/vpn/provision", json=body(key=k1), headers=h1)
    r2 = client.post("/api/v1/vpn/provision", json=body(device="dev_OTHER0002"), headers=h2)
    assert r1.status_code == 200 and r2.status_code == 200
    j1, j2 = r1.json(), r2.json()
    assert j1["ipv4"] != j2["ipv4"] and j1["ipv6"] != j2["ipv6"]
    assert j1["ipv4"] == "10.8.0.2/32"  # .1 dành cho gateway
    assert "PrivateKey" not in j1["config_text"]
    assert "AllowedIPs = 0.0.0.0/0, ::/0" in j1["config_text"]
    assert f"PublicKey = {SERVER_KEY}" in j1["config_text"]
    assert driver.peers[k1] == [j1["ipv4"], j1["ipv6"]]  # peer xuất hiện trên gateway với /32 + /128
    assert r1.headers["cache-control"] == "no-store"
    # Chữ ký xác minh được bằng khóa công khai ghim sẵn
    pub = serialization.load_der_public_key(base64.b64decode(app.state.signer.public_key_b64))
    msg = signing_message(j1["peer_id"], j1["device_id"], j1["nonce"], j1["issued_at"], j1["expires_at"], j1["config_text"])
    pub.verify(base64.b64decode(j1["signature"]), msg, ec.ECDSA(hashes.SHA256()))
    # Cấu hình bị sửa → chữ ký sai
    bad = signing_message(j1["peer_id"], j1["device_id"], j1["nonce"], j1["issued_at"], j1["expires_at"], j1["config_text"] + "x")
    with pytest.raises(Exception):
        pub.verify(base64.b64decode(j1["signature"]), bad, ec.ECDSA(hashes.SHA256()))
    # Không có private key nào trong DB
    cols = [r[1] for r in conn.execute("PRAGMA table_info(peers)")]
    assert not any("private" in c for c in cols)


def test_rotate_key_keeps_ip_and_removes_old_key(env):
    _, _, client, driver, _, user = env
    _, h = user("a@x")
    k1, k2 = wg_pub(), wg_pub()
    j1 = client.post("/api/v1/vpn/provision", json=body(key=k1), headers=h).json()
    j2 = client.post("/api/v1/vpn/provision", json=body(key=k2), headers=h).json()
    assert j1["peer_id"] == j2["peer_id"] and j1["ipv4"] == j2["ipv4"]
    assert k1 not in driver.peers and k2 in driver.peers


def test_device_limit_and_revoke(env):
    _, _, client, driver, conn, user = env
    _, h = user("a@x", max_devices=1)
    k1 = wg_pub()
    assert client.post("/api/v1/vpn/provision", json=body(key=k1), headers=h).status_code == 200
    r = client.post("/api/v1/vpn/provision", json=body(device="dev_SECOND0001"), headers=h)
    assert r.status_code == 409 and r.json()["error"]["code"] == "device_limit_reached"
    assert client.delete("/api/v1/vpn/devices/dev_ABCDEFGH01", headers=h).status_code == 204
    assert k1 not in driver.peers
    assert client.post("/api/v1/vpn/provision", json=body(device="dev_SECOND0001"), headers=h).status_code == 200
    actions = [r["action"] + ":" + r["result"] for r in conn.execute("SELECT action, result FROM audit")]
    assert "provision:device_limit_reached" in actions and "revoke_device:ok" in actions


def test_public_key_reuse_rejected(env):
    _, _, client, _, _, user = env
    _, h1 = user("a@x"); _, h2 = user("b@x")
    k = wg_pub()
    assert client.post("/api/v1/vpn/provision", json=body(key=k), headers=h1).status_code == 200
    r = client.post("/api/v1/vpn/provision", json=body(key=k, device="dev_OTHER0002"), headers=h2)
    assert r.status_code == 409 and r.json()["error"]["code"] == "public_key_in_use"


@pytest.mark.parametrize("field,value,code", [
    ("client_public_key", "not-a-key", "invalid_public_key"),
    ("client_public_key", base64.b64encode(bytes(32)).decode(), "invalid_public_key"),
    ("device_id", "x", "invalid_device_id"),
    ("nonce", "short", "invalid_nonce"),
])
def test_input_validation(env, field, value, code):
    _, _, client, _, _, user = env
    _, h = user("a@x")
    b = body(); b[field] = value
    r = client.post("/api/v1/vpn/provision", json=b, headers=h)
    assert r.status_code == 422 and r.json()["error"]["code"] == code


def test_rate_limit(env):
    _, _, client, _, _, user = env
    _, h = user("a@x")
    codes = [client.post("/api/v1/vpn/provision", json=body(), headers=h).status_code for _ in range(6)]
    assert codes[:5] == [200] * 5 and codes[5] == 429


def test_gateway_failure_rolls_back(env):
    _, _, client, driver, conn, user = env
    _, h = user("a@x")
    driver.fail_next = True
    r = client.post("/api/v1/vpn/provision", json=body(), headers=h)
    assert r.status_code == 503 and r.json()["error"]["code"] == "gateway_unavailable"
    assert conn.execute("SELECT COUNT(*) FROM peers").fetchone()[0] == 0


def test_admin_lock_revokes_everything(env):
    _, _, client, driver, _, user = env
    uid, h = user("a@x")
    _, h_admin = user("admin@x", scopes="vpn admin")
    k = wg_pub()
    client.post("/api/v1/vpn/provision", json=body(key=k), headers=h)
    assert client.post(f"/api/v1/admin/users/{uid}/lock", headers=h).status_code == 403
    assert client.post(f"/api/v1/admin/users/{uid}/lock", headers=h_admin).status_code == 204
    assert k not in driver.peers
    assert client.post("/api/v1/vpn/provision", json=body(), headers=h).status_code == 401  # token đã bị thu hồi


def test_logout_revokes_device_and_token(env):
    _, _, client, driver, _, user = env
    _, h = user("a@x")
    k = wg_pub()
    client.post("/api/v1/vpn/provision", json=body(key=k), headers=h)
    assert client.post("/api/v1/auth/logout", json={"device_id": "dev_ABCDEFGH01"}, headers=h).status_code == 204
    assert k not in driver.peers
    assert client.get("/api/v1/vpn/devices", headers=h).status_code == 401


def test_sweep_and_reconcile(env):
    _, _, client, driver, conn, user = env
    _, h = user("a@x")
    k = wg_pub()
    client.post("/api/v1/vpn/provision", json=body(key=k), headers=h)
    conn.execute("UPDATE peers SET expires_at = ?", (iso(now() - timedelta(seconds=1)),))
    assert sweep_expired(conn, driver) == 1 and k not in driver.peers
    rogue = wg_pub()
    driver.peers[rogue] = ["10.8.0.99/32"]
    assert reconcile(conn, driver)["removed_unknown"] == 1 and rogue not in driver.peers


def test_key_validator():
    assert is_valid_wg_key(wg_pub())
    assert not is_valid_wg_key("A" * 44)
    assert not is_valid_wg_key(base64.b64encode(os.urandom(31)).decode())
