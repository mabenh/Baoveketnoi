# API cấp cấu hình WireGuard – Personal Security Suite

Bản tham chiếu: `backend/app` (FastAPI + SQLite), 16 test trong `backend/tests`. Đặc tả máy đọc: `backend/openapi.json`.

## 1. Nguyên tắc

| Nguyên tắc | Cách thực hiện |
| --- | --- |
| Không bao giờ để lộ `PrivateKey` | Thiết bị tự sinh cặp khóa Curve25519, chỉ gửi `PublicKey`. API **không nhận và không trả** private key; DB không có cột private key. App chèn khóa riêng của nó vào cấu hình rồi mã hóa bằng Android Keystore. |
| Xác thực từng tài khoản / thiết bị | `Authorization: Bearer` (token ngắn hạn, DB chỉ lưu SHA-256). Mỗi `(user, device_id)` có tối đa **một** peer hoạt động; `max_devices` mặc định 1. |
| Cấp IP/peer có kiểm soát | Cấp `IPv4 /32` + `IPv6 /128` riêng, trong transaction `BEGIN IMMEDIATE` và unique index → không trùng khi gọi song song. `.1` dành cho gateway/DNS. |
| Cấu hình không thể giả mạo / phát lại | Response được ký ECDSA P-256 trên chuỗi chứa `nonce` do app sinh cho từng request. App ghim khóa công khai lúc build. |
| Thu hồi tức thì, kiểm toán | DB là nguồn sự thật: đánh dấu thu hồi → gỡ trên gateway; nếu gateway lỗi trả `202` và job `reconcile` (mỗi phút) gỡ nốt, không bao giờ thêm lại. Audit mọi thao tác, kể cả thất bại; không ghi token/khóa. |
| Không đánh dấu an toàn khi chưa chắc | Gateway lỗi khi cấp → rollback, `503`, không trả cấu hình. |

## 2. Luồng

```
App                                   Provisioning API                 WireGuard gateway
 │ sinh KeyPair (chỉ trên máy)              │                                  │
 │ nonce = random 24 byte                   │                                  │
 │ POST /vpn/provision ───────────────────► │ xác thực token, trạng thái TK,  │
 │   {device_id, client_public_key, nonce}  │ quyền VPN, hạn mức, rate limit   │
 │                                          │ cấp IP (txn) ── wg set peer ───► │ peer + allowed-ips /32,/128
 │ ◄──────────── 200 {config_text, sig...}  │ audit                            │
 │ xác minh chữ ký + nonce + device_id      │                                  │
 │ chèn PrivateKey → Config.parse           │                                  │
 │ mã hóa (Keystore) → lưu                  │                                  │
 │ GoBackend.setState(UP) ─────────────────────────────────── handshake ─────► │
```

## 3. Endpoint

Mọi lỗi có dạng `{"error": {"code": "...", "message": "..."}}`; mọi response có `Cache-Control: no-store`.

### `POST /api/v1/vpn/provision`
Cấp mới, gia hạn (cùng khóa) hoặc xoay khóa (khóa mới, **giữ IP**, khóa cũ bị gỡ ngay).

Request
```json
{
  "device_id": "q3Vt0bK9xL2mP8sN1wR4yA",
  "client_public_key": "BASE64_CLIENT_PUBLIC_KEY_32_BYTES=",
  "nonce": "7fJ2kQ9wLx0aB3cD5eF6gH8i"
}
```
- `device_id`: ID ngẫu nhiên do app sinh khi cài (8–64 ký tự `[A-Za-z0-9_-]`). **Không** dùng tên model / IMEI / số serial.
- `client_public_key`: base64 chuẩn của đúng 32 byte, khác 0.
- `nonce`: ngẫu nhiên 16–64 ký tự, mới cho mỗi request.

Response `200`
```json
{
  "peer_id": "peer_3f9a1c2b7d4e5f60",
  "device_id": "q3Vt0bK9xL2mP8sN1wR4yA",
  "ipv4": "10.8.0.15/32",
  "ipv6": "fd42:42:42::f/128",
  "issued_at": "2026-11-23T13:50:00Z",
  "expires_at": "2026-12-23T13:50:00Z",
  "nonce": "7fJ2kQ9wLx0aB3cD5eF6gH8i",
  "config_text": "[Interface]\nAddress = 10.8.0.15/32, fd42:42:42::f/128\nDNS = 10.8.0.1, fd42:42:42::1\nMTU = 1280\n\n[Peer]\nPublicKey = BASE64_SERVER_PUBLIC_KEY=\nEndpoint = vpn.example.com:51820\nAllowedIPs = 0.0.0.0/0, ::/0\nPersistentKeepalive = 25\n",
  "signature": "MEUCIQ...",
  "signature_alg": "ES256-DER",
  "key_id": "a1b2c3d4e5f60718"
}
```

Chuỗi được ký (UTF-8, nối bằng `\n`):
```
PSS-WG-PROVISION-v1
<peer_id>
<device_id>
<nonce>
<issued_at>
<expires_at>
<sha256_hex(config_text)>
```

| Mã | `error.code` | Khi nào |
| --- | --- | --- |
| 401 | `unauthorized` | Thiếu / sai / hết hạn / đã thu hồi token (`WWW-Authenticate: Bearer`) |
| 403 | `account_locked` | Tài khoản bị khóa / vô hiệu hóa |
| 403 | `vpn_not_entitled` | Không có scope `vpn` hoặc gói VPN hết hạn |
| 409 | `device_limit_reached` | Đã đủ số thiết bị – phải gỡ thiết bị cũ |
| 409 | `public_key_in_use` | Khóa công khai đang thuộc peer khác |
| 422 | `invalid_public_key` / `invalid_device_id` / `invalid_nonce` / `invalid_request` | Dữ liệu sai định dạng |
| 429 | `rate_limited` | Vượt 10 lần/giờ/tài khoản hoặc 30 lần/giờ/IP (`Retry-After`) |
| 503 | `gateway_unavailable` / `pool_exhausted` | Gateway lỗi (đã rollback) / hết IP |

### `GET /api/v1/vpn/devices`
Danh sách thiết bị đang hoạt động của tài khoản: `peer_id, device_id, ipv4, created_at, expires_at`.

### `DELETE /api/v1/vpn/devices/{device_id}`
Thu hồi peer của thiết bị. `204` đã gỡ trên gateway; `202` đã thu hồi trong DB, gateway đang chờ reconcile; `404 device_not_found`.

### `POST /api/v1/auth/logout`
Body `{"device_id": "..."}` (tùy chọn). Thu hồi token hiện tại và peer của thiết bị đó.

### `POST /api/v1/admin/users/{user_id}/lock`
Scope `admin` (tài khoản quản trị bắt buộc MFA ở hệ thống đăng nhập). Khóa tài khoản, thu hồi **mọi** peer và token. `204` / `202` / `403 forbidden` / `404 user_not_found`.

### `GET /api/v1/vpn/config-signing-key`
Chỉ để đối chiếu khi build. App **không** được tải khóa này lúc chạy.

## 4. Kiểm tra nghiệm thu

| Kịch bản | Kết quả đạt | Test |
| --- | --- | --- |
| Không token / token sai | `401` | `test_requires_token` |
| Tài khoản khóa / hết quyền VPN | `403 account_locked` / `vpn_not_entitled` | `test_forbidden_when_locked_or_not_entitled` |
| Tài khoản hợp lệ | `200`, IP riêng, peer xuất hiện trên gateway (`wg show wg0 allowed-ips`), chữ ký đúng, không có `PrivateKey` | `test_provision_ok_signed_and_unique_ips` |
| Xoay khóa | Giữ IP, khóa cũ bị gỡ | `test_rotate_key_keeps_ip_and_removes_old_key` |
| Thiết bị thứ 2 khi giới hạn 1 | `409`, gỡ thiết bị cũ rồi đăng ký được | `test_device_limit_and_revoke` |
| Dùng lại khóa công khai | `409` | `test_public_key_reuse_rejected` |
| Spam cấp cấu hình | `429` | `test_rate_limit` |
| Gateway lỗi | `503`, không có peer trong DB | `test_gateway_failure_rolls_back` |
| Admin khóa tài khoản | Peer bị gỡ, token mất hiệu lực | `test_admin_lock_revokes_everything` |
| Đăng xuất | Peer + token bị thu hồi | `test_logout_revokes_device_and_token` |
| Hết hạn / peer lạ trên gateway | Bị gỡ | `test_sweep_and_reconcile` |

Chạy: `cd backend && pip install -r requirements.txt && python -m pytest -q`

## 5. Giai đoạn thử nghiệm: một máy chủ tại TP.HCM

| Hạng mục | Cấu hình |
| --- | --- |
| Gateway | `VN-HCM-01`, một VPS/máy chủ tại TP.HCM, `wg0` UDP 51820, Endpoint ví dụ `hcm.vpn.example.com:51820` |
| API | Chạy cùng máy với gateway, sau Caddy/nginx (TLS 1.2+); dùng `WgCliDriver` (`PSS_DRIVER=wg`) |
| Địa chỉ | `10.8.0.0/24` + `fd42:42:42::/64` → tối đa 253 thiết bị, đủ cho thử nghiệm |
| DNS | Resolver trên `10.8.0.1` (Unbound/dnsmasq, tắt log truy vấn) |
| App | `GATEWAY_HOST=hcm.vpn.example.com`: app từ chối mọi cấu hình có Endpoint khác (`UNEXPECTED_GATEWAY`); không có chọn vùng, không tự chuyển máy chủ |
| Sao lưu | DB `pss.db` + khóa ký cấu hình; private key của gateway chỉ nằm trên gateway |

Khi mở rộng nhiều vùng: tách control plane khỏi gateway (agent mTLS), thêm `gateway_id` vào DB/peer và vào chuỗi ký (`PSS-WG-PROVISION-v2`).

## 6. Triển khai

1. Gateway: `deploy/wg0.conf.example`, `deploy/nftables.conf.example` (cô lập client, chặn dải nội bộ/metadata, chặn SMTP), resolver DNS nội bộ trên `10.8.0.1` **không log truy vấn**.
2. API sau reverse proxy TLS 1.2+ (HSTS), không mở trực tiếp cổng uvicorn ra Internet:
   ```
   PSS_WG_SERVER_PUBLIC_KEY=... PSS_WG_ENDPOINT=vpn.example.com:51820 uvicorn app.server:app --host 127.0.0.1 --port 8080
   ```
3. Khóa ký: `python -m app.cli show-signing-key` → đưa `CONFIG_SIGNING_PUBLIC_KEY` vào GitHub Actions (biến/secret) để build app. Khóa riêng (PEM 0600) nên chuyển vào secret manager/HSM.
4. Timer: `reconcile` mỗi phút, `sweep` mỗi giờ (`deploy/pss-maintenance.timer.example`).
5. Thử nhanh: `python -m app.cli create-user test@example.com` → `python -m app.cli issue-token <user_id>`.

## 7. Việc còn lại trước khi phát hành

- Thay token tĩnh bằng hệ thống đăng nhập thật (OAuth2/OIDC, refresh token rotation, MFA/passkey).
- Control plane tách khỏi gateway: thay `WgCliDriver` bằng gateway agent qua mTLS; nhiều gateway theo vùng.
- Rate limit dùng Redis khi chạy nhiều instance; PostgreSQL thay SQLite.
- Cân nhắc Play Integrity / Key Attestation để gắn `device_id` với thiết bị thật.
- Xoay khóa ký cấu hình: hỗ trợ nhiều `key_id` trong app trước khi xoay.
- Pentest API và gateway theo mục 16 hồ sơ.
