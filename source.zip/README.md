# Personal Security Suite – Android prototype

> **Giai đoạn thử nghiệm:** một máy chủ WireGuard duy nhất **VN-HCM-01 (TP. Hồ Chí Minh)**, giao diện chỉ tiếng Việt.
> - Biến GitHub Actions (Settings › Secrets and variables › Actions › Variables): `GATEWAY_HOST` (ví dụ `hcm.vpn.example.com`),
>   `CONFIG_SIGNING_PUBLIC_KEY`, `PROVISIONING_BASE_URL`. App từ chối cấu hình trỏ tới host khác `GATEWAY_HOST`.
> - Đa ngôn ngữ: 13 bộ dịch vẫn nằm trong `res/values-*`, nhưng `pss.multiLanguage=false` (gradle.properties) nên APK chỉ
>   đóng gói tiếng Việt và ẩn mọi chỗ chọn ngôn ngữ. Bật lại: đặt `pss.multiLanguage=true`.
> - Chế độ demo mặc định **tắt**: Tổng quan hiển thị trạng thái thật.

Bản prototype giao diện dựng theo hồ sơ thiết kế v1.0 + v1.1 (Kotlin, Jetpack Compose, minSdk 26, targetSdk 35).

## Build APK trên GitHub

1. Tạo repository mới trên GitHub, giải nén `source.zip` và đẩy toàn bộ nội dung lên nhánh `main`
   (hoặc kéo thả các file vào trang repository qua **Add file › Upload files**; nhớ có cả thư mục `.github`).
2. Vào tab **Actions** → workflow **Build APK** sẽ tự chạy (hoặc bấm **Run workflow**).
3. Khi chạy xong (khoảng 5–8 phút), mở lần chạy đó → mục **Artifacts** → tải `PersonalSecuritySuite-debug`.
   File zip tải về chứa `app-debug.apk`, cài trực tiếp lên điện thoại Android 8.0 trở lên.

### Bản release đã ký (tùy chọn)

Thêm 4 secret trong **Settings › Secrets and variables › Actions**:

| Secret | Giá trị |
| --- | --- |
| `KEYSTORE_BASE64` | Nội dung file `.jks` mã hóa base64 (`base64 -w0 release.jks`) |
| `KEYSTORE_PASSWORD` | Mật khẩu keystore |
| `KEY_ALIAS` | Alias của khóa |
| `KEY_PASSWORD` | Mật khẩu khóa |

Workflow sẽ tạo thêm artifact `PersonalSecuritySuite-release`. Không bao giờ commit file keystore vào repo.

## Build trên máy

```bash
./gradlew assembleDebug
```

Cần JDK 17 và Android SDK (Android Studio Ladybug trở lên).

## VPN: WireGuard (com.wireguard.android:tunnel)

Thư viện `com.wireguard.android:tunnel:1.0.20230706` cung cấp `GoBackend` và `GoBackend.VpnService`
(wireguard-go userspace, không cần root). Dịch vụ VPN được merge tự động vào manifest.

Luồng kết nối (`vpn/VpnStatus.kt` – `VpnController.connect`):
1. **Quyền**: `VpnService.prepare()`; nếu cần thì màn giải thích → hộp thoại hệ thống (Activity Result API).
   Từ chối → `PermissionDenied`, không tự hỏi lại.
2. **Cấu hình**: giải mã `.conf` (AES-256-GCM, khóa trong Android Keystore – `vpn/ConfigStore.kt`), parse bằng
   `Config.parse`. Từ chối báo Protected nếu: thiếu Endpoint, AllowedIPs không có `0.0.0.0/0`, không có DNS,
   hoặc mạng hiện tại có IPv6 mà cấu hình không định tuyến `::/0`.
3. **Tunnel**: `GoBackend.setState(tunnel, UP, config)` (chạy ngoài main thread) – GoBackend tự `protect()`
   socket, tạo TUN và chuyển tiếp gói.
4. **Kiểm tra**: gọi HTTPS qua tunnel để đọc IP đầu ra (`WireGuardManager.EXIT_IP_CHECK_URL`), chờ handshake
   với peer (tối đa 10 giây), xác nhận Android có mạng VPN kèm DNS. Đạt hết mới chuyển **Protected**;
   lỗi thì hạ tunnel và hiện mã lỗi (`HANDSHAKE_FAILED`, `SPLIT_TUNNEL`, `IPV6_LEAK`, …).
5. **Gián đoạn**: khi `GoBackend.VpnService` bị hủy (thu hồi quyền, VPN khác, hệ thống dừng) tunnel báo
   `DOWN` → trạng thái `Interrupted` + thông báo khẩn cấp. Always-on: `GoBackend.setAlwaysOnCallback`
   đăng ký trong `SuiteApplication` để đi lại đúng quy trình kiểm tra.

Dùng thử: bật VPN → **Nhập cấu hình WireGuard** → chọn file `.conf` (hoặc dán nội dung) do gateway WireGuard
của bạn cấp → **Kết nối bằng cấu hình này**.

Lưu ý triển khai:
- `EXIT_IP_CHECK_URL` mặc định là `https://1.1.1.1/cdn-cgi/trace`; bản phát hành nên dùng endpoint của backend riêng.
- Firewall theo app: có thể dùng `IncludedApplications` / `ExcludedApplications` trong `[Interface]`
  (GoBackend áp dụng bằng `addAllowedApplication` / `addDisallowedApplication`).
- Kill Switch toàn hệ thống: Always-on + “Chặn kết nối không qua VPN” trong Cài đặt Android.
- Chưa có giám sát sức khỏe tunnel định kỳ (handshake cũ, mất peer) và chưa có nhập QR.

## Firewall Default-Deny (PR-FW01 – Proof of Concept)

Tab **Tường lửa**: bật firewall → mọi app mất Internet trừ app bạn cho phép; app mới cài mặc định bị chặn.
Thực thi ở tầng định tuyến của Android (`FirewallVpnService`): app được phép được loại khỏi VPN, mọi app khác vào TUN và
bị bỏ packet. Có nhật ký chặn (UID, đích, giao thức), kiểm tra rò rỉ IPv4/IPv6/DNS, trạng thái OFF/STARTING/PROTECTED/
DEGRADED/ERROR. Không chạy đồng thời với WireGuard. Nghiên cứu và ma trận FW-001…FW-019: `docs/PR-FW01.md`.

## Backend cấp cấu hình WireGuard (`backend/`)

Bản tham chiếu FastAPI + SQLite, đặc tả trong `backend/API.md` và `backend/openapi.json`, 16 test (`python -m pytest -q`).
- App tự sinh cặp khóa; API chỉ nhận PublicKey, cấp IPv4 /32 + IPv6 /128 riêng, thêm peer bằng `wg set`.
- Response ký ECDSA P-256 kèm nonce của app; app xác minh bằng khóa ghim lúc build rồi mới lưu.
- Thu hồi khi gỡ thiết bị / đăng xuất / admin khóa tài khoản; job `reconcile` và `sweep` giữ gateway đúng với DB.

Kết nối app với backend:
1. Trên server: `python -m app.cli show-signing-key` → lấy `CONFIG_SIGNING_PUBLIC_KEY`.
2. GitHub › Settings › Secrets and variables › Actions › **Variables**: thêm `CONFIG_SIGNING_PUBLIC_KEY`
   (và tùy chọn `PROVISIONING_BASE_URL`). Đây là khóa công khai, không phải bí mật.
3. Build lại APK. Trong app: VPN › Cấu hình WireGuard › **Nhận cấu hình từ máy chủ** (nhập URL https và access
   token thử nghiệm tạo bằng `python -m app.cli issue-token <user_id>`).

Không có khóa ghim trong bản build thì app từ chối nhận cấu hình từ máy chủ.

## Phạm vi bản prototype

Có thật, đọc từ Android:
- Loại mạng hiện tại và việc có VPN nào đang hoạt động (Tổng quan khi tắt *Chế độ demo*).
- VPN WireGuard thật qua GoBackend khi bạn nhập cấu hình `.conf` của một gateway WireGuard.
- Permission State Manager: thông báo, Bluetooth scan/connect, Usage Access, VPN consent — phát hiện
  Đã cấp / Chưa hỏi / Bị từ chối / Từ chối vĩnh viễn / Đã thu hồi, kiểm tra lại mỗi lần quay lại app.
- Bộ nhớ và pin trong Device Care; các nút mở đúng trang Cài đặt Android.
- Trình tạo mật khẩu dùng `SecureRandom`, clipboard đánh dấu nhạy cảm và tự xóa sau 30 giây,
  màn kho mật khẩu chặn chụp màn hình và tự khóa khi rời app.
- Đổi ngôn ngữ riêng cho app (13 ngôn ngữ) qua AppCompat per-app locales, hỗ trợ RTL.

Dữ liệu minh họa (có nhãn “Bản prototype · dữ liệu minh họa”):
- IP Trust, tuyến tĩnh/động, tường lửa, Wi-Fi/Bluetooth Trust Engine, breach monitor, Security Center,
  kho mật khẩu. Kho mật khẩu **không lưu và không mã hóa** dữ liệu — không nhập mật khẩu thật.

Ngôn ngữ: thanh điều hướng, trạng thái, màn chào mừng và cài đặt đã dịch 13 ngôn ngữ; nội dung chi tiết
từng màn hiện là tiếng Việt và cần chuyển vào `strings.xml` trước khi phát hành.

Theo hồ sơ, VPN, firewall và Password Vault thật chỉ được phát hành sau threat model, review mã,
crypto audit và pentest độc lập.
